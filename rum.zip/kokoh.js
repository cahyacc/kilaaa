const fs = require('fs')
const chalk = require('chalk')

// Website Api
global.APIs = {
	zenz: 'https://zenzapis.xyz',
}

// Apikey Website Api
global.APIKeys = {
	'https://zenzapis.xyz': '34932b6d06',
}

// Other
global.yaayaa = "6281238996370" // buat ngirim request nomer fitur store
global.owner = ['6281238996370']
global.ownernomer = "6281238996370"
global.premium = ['6281238996370']
global.packname = 'Sticker By'
global.author = 'Dica'
global.sessionName = 'session'
global.jumlha = '999'
global.jumhal = '100000000000000'
global.jumlah = '1000000000'
global.prefa = ['','!','.','#','&']
global.sp = ''

// Setting Mess
global.mess = {
    success: '✅Done',
    admin: 'Fitur Khusus Admin Group!',
    botAdmin: 'Bot Harus Menjadi Admin Terlebih Dahulu!',
    premime: 'Fitur Khusus Premium Kalo Mau Daftar Ketik Sewa / Chat Owner',
    owner: 'Fitur Khusus Owner Bot',
    group: 'Fitur Digunakan Hanya Untuk Group!',
    private: 'Fitur Digunakan Hanya Untuk Private Chat!',
    bot: 'Fitur Khusus Pengguna Nomor Bot',
    wait: 'Loading...',
    error: 'Error!',
    errapi: 'Error Mungkin Apikey Tidak Valid!',
    errmor: 'Error Kesalahan Sistem',
    endLimit: 'Sorry dek limit harian kamu habis !🗿\ntunggu besok jam 12.00 atau beli 5k/bulan limit unlimited',
    member: 'Yeeh so asik lu',
    jasher:`_*🔥DEGE STORE🔥*_

*VPN EXPRESS 30 DAY*
_1 Dev : 25k (Sharing)_
_5 Dev : 100k (Private)_
*GARANSI 30 HARI ADMIN ON 24JAM*

*🌟JASA GENDONG 5k/Match ALLTIER🌟*
_*NOTE: TB DARI KAMI, TINGGAL PLAY*_

*🔰PAKET RANK SAFE🔰*
*Epic > Legend* => 50k
*Epic > Mythic* => 120K
*Legend > Mythic* => 90K
*Mythic > Glory* => 350k
*Grading Full Win*=> 60K

_*• OPEN JASA SUNTIK SERVER(KONTAK GM&ADVANCE SERVER)*_
_*• OPEN PEMBUATAN AKUN SERVER ANTI KONTAK GM &ADVANCE SERVER*_
_*• OPEN JASA LOG OUT AKUN BANNED DI IOS/ANDRO*_
_*• OPEN JOKI GENDONGAN*_
_*• OPEN TUTORIAL HOST GB RANK/CL/BOT*_

*ORDER*⤵️
_http://wa.me/+6281369314151_

_*📱WA ADMIN📱*_
_+62 813-6931-4151_
_+62 812-7152-3389_
_*NOTE: NOMOR ADMIN HANYA DI ATAS SELAIN ITU FAKE!_*

*REKBER? GAS!*
_TARIK ADMIN FAMOUS_

 *🔗GRUP JB NO SHARE LINK🔗*
_OPEN JASA POST SAMPAI AKUN SOLD (FREE)_
https://chat.whatsapp.com/FaqTzIDenwMHkPJqLfuat9

*🔱GRUP GB 24 JAM🔱*

*⏬️GRUP FULL⏬️*
https://chat.whatsapp.com/InAHCGzTl2P71Oh2EaEL28
*⏬️OTW FULL⏬️*
https://chat.whatsapp.com/EX9pmOivWStK2R6rmsYzKb
*⏬️OTW FULL⏬️*
https://chat.whatsapp.com/DJJ3vtOPdd516R5xVifzI6
*⏬️OTW FULL⏬️*
https://chat.whatsapp.com/CWfeLRh2d1WHipljSSzhzZ
*⏬NEW GRUP⏬*
https://chat.whatsapp.com/Dnpu1WROdg3JqCHYykSP1Z

*☠️INFO RIPPER☠️*
_KATSKY.JK_
http://wa.me/+6283892570883`,
    jasherrr:`🔰JASA KEBUTUHAN ALL SOSMED🔰 

 [ *FOLLOWERS INSTAGRAM INDONESIA* ] 
 _*-𝗥𝗲𝗮𝗹 𝗳𝗼𝗹𝗹𝗼𝘄𝗲𝗿𝘀 ✅ |-PROSES CEPAT ✅*_ 

500 Followers : 8.000 RB
 1K  Followers : 15.000 RB
 2K  Followers : 25.000 RB
 3K  Followers : 35.000 RB
 5K  Followers : 50.000 RB

[ *LIKE INSTAGRAM REAL INDONESIA* ] 
-Non drop✅ | •proses cepat ✅
500 Like : 5.000 RB
1K   Like : 10.000 RB
2K   Like : 20.000 RB
3K   Like : 30.000 RB
5K   Like : 50.000 RB

[ *PROMO FACEBOOK FOLLOWERS]* 
-Non drop ✅ | •proses cepat✅
500 Followers:  15.000 RB
 1K  Followers : 20.000 RB
 2K  Followers : 40.000 RB
 3K  Followers : 55.000 RB
 5K  Followers : 90.000 RB

[ 𝗙𝗢𝗟𝗟𝗢𝗪𝗘𝗥𝗦 𝗧𝗜𝗞𝗧𝗢𝗞 ] 
- *_INDONESA REAL AKTIF GARANSI 30 HARI | •Proses cepat✅*_ 
500 Followers : 20.000 RB
1K   Followers : 30.000 RB
2K   Followers : 50.000 RB
3K   Followers : 70.000 RB

[ *LIKE TIKTOK REAL INDONSEIA* ] | •𝗣𝗿𝗼𝘀𝗲𝘀 𝗰𝗲𝗽𝗮𝘁 ✅
500 Followers : 15.000 RB
1k    Followers :  20.000 RB
2k    Followers :  40.000 RB
3k    Followers :  55.000 RB

[ *SUBSCRIBE YOUTUBE* ] 
 *_-NON DROP✅ | •REAL SUBS ✅|garansi 30 hari|100% bisa monet_* 
500 Subscribe: 385.000 RB
 1K Subscribe : 770.000 RB
 2K Subscribe : 1.530.000 RB
 3K Subscribe : 2.295.000 RB
 4K Subscribe : 3.050.000 RB
✅𝗥𝗘𝗔𝗗𝗬 𝗦𝗔𝗠𝗣𝗔𝗜 𝟭𝗝𝗧 𝗦𝗨𝗕𝗦𝗖𝗥𝗜𝗕𝗘

[ *TIKTOK VIEW REAL INDONESIA* ] 
-100% REAL NON DROP  ✅
500 Views : 10.000 RB
 1K Views : 15.000 RB
 2K Views : 20.000 RB
 3K Views : 30.000 RB
 
▬▬▬▬▬▬▬▬▬▬▬▬
         BUTUH LAYANAN LAINYA? 
ADMIN MELAYANI :
-SUNTIK FOLLOWERS SOSMED (FACEBOOK, INSTAGRAM,TIK TOK, YOUTUBE, TELEGRAM, TWITTER)
-SUNTIK VIEW/JAM TAYANG (FACEBOOK, INSTAGRAM,TIK TOK, YOUTUBE)
-DIAMOND ALL GAME
-PULSA 
-YT PREMIUM
-TELEGRAM
-SPOTIFY
-ONLINE SHOP ( SHOOPEE,TOKOPEDIA, BUKALAPAK)

➡️PAYMENT💸: GOPAY | DANA | BCA
BERMINAT CHAT KE KONTAK INI YA KAK`,
}

    global.limitawal = {
    premium: "Infinity",
    free: 100,
    monayawal: 1000
}
   global.rpg = {
   darahawal: 100,
   besiawal: 15,
   goldawal: 10,
   emeraldawal: 5,
   umpanawal: 5,
   potionawal: 1
}

global.limitAwal = {
 prem: 'Unlimited',
 free: 100
}
//fake
global.thumb = fs.readFileSync('./media/kilaaa.jpg')
global.faall = fs.readFileSync('./media/menu.jpg')
global.mygit = 'Kilaaa'
global.myyt = 'Kilaaa '
global.myytv = 'Kilaaa'
global.botname = 'Kilaaa'
global.akulaku = 'Kilaaa'
global.ytname = 'Kilaaa'
global.emot = {
role: '🏆',
level: '🎚️',
limit: '📊',
health: '❤️',
exp: '💫',
money: '💵',
potion: '🥤',
diamond: '💎',
common: '📦',
uncommon: '🎁',
mythic: '🗳️',
legendary: '🗃️',
pet: '🎁',
trash: '🗑',
armor: '👕',
sword: '⚔️',
wood: '🪵',
batu: '🪨',
string: '🕸️',
horse: '🐎',
cat: '🐈',
dog: '🐕',
fox: '🦊',
petFood: '🍖',
iron: '⛓️',
gold: '👑',
emerald: '💚',
budak: '🏃',
busur: '🏹',
panah: '💘',
kapak: '🪓'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
